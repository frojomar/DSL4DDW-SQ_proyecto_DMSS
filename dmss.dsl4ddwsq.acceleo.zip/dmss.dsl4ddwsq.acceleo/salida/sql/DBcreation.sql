

CREATE TABLE Pelicula (
	name String
, 	image String
, 	id_Pelicula Integer PRIMARY KEY
	,
	protagonista INTEGER
);

CREATE TABLE Director (
	name String
, 	image String
, 	nombre String
, 	apellidos String
, 	fecha_nac Integer
, 	id_Director Integer PRIMARY KEY
);

CREATE TABLE Actor (
	name String
, 	image String
, 	nombre_completo String
, 	sexo String
, 	id_Actor Integer PRIMARY KEY
);



CREATE TABLE ActorPelicula (
	Actor_key INTEGER,
	Pelicula_key INTEGER,
	PRIMARY KEY (Pelicula_key),
	FOREIGN KEY (Actor_key) REFERENCES "Actor"(id_Actor),
	FOREIGN KEY (Pelicula_key) REFERENCES "Pelicula"(id_Pelicula)
);




DROP TABLE Pelicula;

CREATE TABLE Pelicula (
	name String
, 	image String
, 	id_Pelicula Integer PRIMARY KEY
	,
	protagonista INTEGER,
	FOREIGN KEY (protagonista) REFERENCES "Actor"(id_Actor)
);




