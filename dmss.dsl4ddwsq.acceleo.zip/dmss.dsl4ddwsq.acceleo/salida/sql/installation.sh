	#!/bin/bash
	
	mkdir ~/sqlite_dbs
	cp FilmotecaUNEX.sqlite ~/sqlite_dbs/FilmotecaUNEX.sqlite
	cp DBcreation.sql ~/sqlite_dbs/DBcreation.sql
	cp orders.txt ~/sqlite_dbs/orders.txt
	cd ~/sqlite_dbs
	sudo apt-get install sqlite3 libsqlite3-dev
	sqlite3 <orders.txt
