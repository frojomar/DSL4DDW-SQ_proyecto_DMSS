package es.unex.giiis.dmss.model;


import java.util.ArrayList;
import java.util.List;

/*
Codigo generado automaticamente
No modificar

Clase generada: Actor.java

*/
public class Actor {
	//Atributos
		private String name; //Atributo name
		private String image; //Atributo image
		private String nombre_completo; //Atributo nombre_completo
		private String sexo; //Atributo sexo
		private Integer id_Actor; //Atributo id_Actor
		private List<Pelicula> protagonista_de;


	//Metodos
	//Generación de getters y setters
		public String getname(){
			return name;
		}

		public void setname(String _name){
			name= _name;
		}
		public String getimage(){
			return image;
		}

		public void setimage(String _image){
			image= _image;
		}
		public String getnombre_completo(){
			return nombre_completo;
		}

		public void setnombre_completo(String _nombre_completo){
			nombre_completo= _nombre_completo;
		}
		public String getsexo(){
			return sexo;
		}

		public void setsexo(String _sexo){
			sexo= _sexo;
		}
		public Integer getid_Actor(){
			return id_Actor;
		}

		public void setid_Actor(Integer _id_Actor){
			id_Actor= _id_Actor;
		}

		
		public List<Pelicula> getprotagonista_de(){
			return protagonista_de;
		}

		public void setprotagonista_de(List<Pelicula> _protagonista_de){
			protagonista_de= _protagonista_de;
		}


	//Constructor por defecto
	public Actor(){
				name=new String("");
				image=new String("");
				nombre_completo=new String("");
				sexo=new String("");
					id_Actor=new Integer(0);
				protagonista_de= new ArrayList<Pelicula>();
	}
	//Constructor parametrizado
	public Actor(String name, String image, String nombre_completo, String sexo, Integer id_Actor, ArrayList<Pelicula> protagonista_de ){
			this.name=name;
			this.image=image;
			this.nombre_completo=nombre_completo;
			this.sexo=sexo;
			this.id_Actor=id_Actor;
			this.protagonista_de= protagonista_de;
	}
	//Operación toString
	public String toString(){
		String result="";
			result=result.concat("name: "+this.name+" -- ");
			result=result.concat("image: "+this.image+" -- ");
			result=result.concat("nombre_completo: "+this.nombre_completo+" -- ");
			result=result.concat("sexo: "+this.sexo+" -- ");
			result=result.concat("id_Actor: "+this.id_Actor+" -- ");
			for(int i=0; i<this.protagonista_de.size();i++){
				result=result.concat("protagonista_de: "+this.protagonista_de.get(i).toString()+" -- ");
				}
		return result;
	}
}
