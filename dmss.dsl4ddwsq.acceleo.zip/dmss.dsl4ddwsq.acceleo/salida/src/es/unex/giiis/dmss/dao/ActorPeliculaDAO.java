package es.unex.giiis.dmss.dao;

import java.sql.Connection;
import java.util.List;



public interface ActorPeliculaDAO {

	public void setConnection(Connection conn);
	
	public List<Integer> getAllByActor(long id);

	public Integer get(long aPeliculaID);

	public boolean add(Integer aActorID, Integer aPeliculaID);

	public boolean delete(long aPeliculaID);

	public boolean deleteAllByActor(long id);
}
