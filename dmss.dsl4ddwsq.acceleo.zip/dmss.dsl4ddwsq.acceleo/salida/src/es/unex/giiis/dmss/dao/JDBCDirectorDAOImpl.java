
package es.unex.giiis.dmss.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import es.unex.giiis.dmss.model.Director;


public class JDBCDirectorDAOImpl implements DirectorDAO {

	private Connection conn;

	@Override
	public void setConnection(Connection conn){
		this.conn = conn;
	}
	

	@Override
	public List<Director> getAll(){
		if (conn == null) return null;
						
		ArrayList<Director> list = new ArrayList<Director>();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM Director");

			while ( rs.next() ) {
				Director element = new Director();


				element.setname(rs.getString("name"));




				element.setimage(rs.getString("image"));




				element.setnombre(rs.getString("nombre"));




				element.setapellidos(rs.getString("apellidos"));





				element.setfecha_nac(rs.getInt("fecha_nac"));




				element.setid_Director(rs.getInt("id_Director"));



							
				list.add(element);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}

	@Override
	public Director get(long id){
		if (conn == null) return null;
		
		Director element = null;		
		
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM Director WHERE id_Director="+id);			 
			if (!rs.next()) return null;

			element = new Director();


			element.setname(rs.getString("name"));




			element.setimage(rs.getString("image"));




			element.setnombre(rs.getString("nombre"));




			element.setapellidos(rs.getString("apellidos"));





			element.setfecha_nac(rs.getInt("fecha_nac"));




			element.setid_Director(rs.getInt("id_Director"));



			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return element;
	}

	@Override
	public boolean add(Director aDirector){
		boolean done = false;
		if (conn != null){
			
			Director element= aDirector;

			Statement stmt;
			try {
				stmt = conn.createStatement();
				stmt.executeUpdate("INSERT INTO Director (name, image, nombre, apellidos, fecha_nac, id_Director) VALUES('"+
									element.getname()
+"','"+									element.getimage()
+"','"+									element.getnombre()
+"','"+									element.getapellidos()
+"','"+									element.getfecha_nac()
+"','"+									element.getid_Director()
									
									+"')");
						
				done= true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return done;
	}

	@Override
	public boolean delete(long id){
		boolean done = false;
		if (conn != null){

			Statement stmt;
			try {
				stmt = conn.createStatement();
				stmt.executeUpdate("DELETE FROM Director WHERE id_Director="+id);
				done= true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return done;
	}

}

