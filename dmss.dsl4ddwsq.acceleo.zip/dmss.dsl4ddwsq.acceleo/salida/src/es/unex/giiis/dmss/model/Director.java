package es.unex.giiis.dmss.model;


import java.util.ArrayList;
import java.util.List;

/*
Codigo generado automaticamente
No modificar

Clase generada: Director.java

*/
public class Director {
	//Atributos
		private String name; //Atributo name
		private String image; //Atributo image
		private String nombre; //Atributo nombre
		private String apellidos; //Atributo apellidos
		private Integer fecha_nac; //Atributo fecha_nac
		private Integer id_Director; //Atributo id_Director


	//Metodos
	//Generación de getters y setters
		public String getname(){
			return name;
		}

		public void setname(String _name){
			name= _name;
		}
		public String getimage(){
			return image;
		}

		public void setimage(String _image){
			image= _image;
		}
		public String getnombre(){
			return nombre;
		}

		public void setnombre(String _nombre){
			nombre= _nombre;
		}
		public String getapellidos(){
			return apellidos;
		}

		public void setapellidos(String _apellidos){
			apellidos= _apellidos;
		}
		public Integer getfecha_nac(){
			return fecha_nac;
		}

		public void setfecha_nac(Integer _fecha_nac){
			fecha_nac= _fecha_nac;
		}
		public Integer getid_Director(){
			return id_Director;
		}

		public void setid_Director(Integer _id_Director){
			id_Director= _id_Director;
		}



	//Constructor por defecto
	public Director(){
				name=new String("");
				image=new String("");
				nombre=new String("");
				apellidos=new String("");
					fecha_nac=new Integer(0);
					id_Director=new Integer(0);
	}
	//Constructor parametrizado
	public Director(String name, String image, String nombre, String apellidos, Integer fecha_nac, Integer id_Director ){
			this.name=name;
			this.image=image;
			this.nombre=nombre;
			this.apellidos=apellidos;
			this.fecha_nac=fecha_nac;
			this.id_Director=id_Director;
	}
	//Operación toString
	public String toString(){
		String result="";
			result=result.concat("name: "+this.name+" -- ");
			result=result.concat("image: "+this.image+" -- ");
			result=result.concat("nombre: "+this.nombre+" -- ");
			result=result.concat("apellidos: "+this.apellidos+" -- ");
			result=result.concat("fecha_nac: "+this.fecha_nac+" -- ");
			result=result.concat("id_Director: "+this.id_Director+" -- ");
		return result;
	}
}
