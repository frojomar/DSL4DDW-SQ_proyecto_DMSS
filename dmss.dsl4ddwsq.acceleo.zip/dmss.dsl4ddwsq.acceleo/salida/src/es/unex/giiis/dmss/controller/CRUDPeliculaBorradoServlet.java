		package es.unex.giiis.dmss.controller;
		
		import java.io.FileWriter;
		import java.io.IOException;
		import java.io.PrintWriter;
		import java.util.logging.Logger;
		import java.sql.Connection;
		
		
		import javax.servlet.RequestDispatcher;
		import javax.servlet.ServletException;
		import javax.servlet.annotation.WebServlet;
		import javax.servlet.http.HttpServlet;
		import javax.servlet.http.HttpServletRequest;
		import javax.servlet.http.HttpServletResponse;
		import javax.servlet.http.HttpSession;
		
		import es.unex.giiis.dmss.dao.*;
		import es.unex.giiis.dmss.model.*;
		
		/**
		 * Servlet implementation. Automatically generated
		 */
		@WebServlet("/CRUDPeliculaBorradoServlet")
		public class CRUDPeliculaBorradoServlet extends HttpServlet {
			private static final long serialVersionUID = 1L;
			private static final Logger logger = 
					Logger.getLogger(HttpServlet.class.getName());
		       
		    /**
		     * @see HttpServlet#HttpServlet()
		     */
		    public CRUDPeliculaBorradoServlet() {
		
		        super();
		    }
		
			/**
			 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
			 */
			protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				logger.info("The request was made using GET");		
				HttpSession session = request.getSession();
		
				request.setCharacterEncoding("UTF-8");
				
				//Conexion
				Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		
				//DAO DAOobj = new DAOImpl y establecer conexion
				PeliculaDAO PeliculaDAOobj = new JDBCPeliculaDAOImpl();
				PeliculaDAOobj.setConnection(conn);
				
				//Obtener el parámetro de la request
				Integer id = Integer.parseInt(request.getParameter("id"));
		
				//Obtener entidad
				Pelicula Peliculaobj = PeliculaDAOobj.get(id);
				
				//Dejarla en la request
				request.setAttribute("Pelicula",Peliculaobj);
		
		
				RequestDispatcher view = request.getRequestDispatcher("WEB-INF/CRUDPeliculaBorrado.jsp");
				view.forward(request,response);	
			}
		
			/**
			 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
			 */
			protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {				
				request.setCharacterEncoding("UTF-8");
		
				logger.info("The request was made using POST");		
		
				
				//Obtener el parámetro de la request
				Integer id = Integer.parseInt(request.getParameter("id"));
		
				//Conexion
				Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		
				//DAO DAOobj = new DAOImpl y establecer conexion
				PeliculaDAO PeliculaDAOobj = new JDBCPeliculaDAOImpl();
				PeliculaDAOobj.setConnection(conn);
						
				//Borrar Pelicula
				PeliculaDAOobj.delete(id);
		
				//Comprobación de dependientes, para borrar entradas
		
				//COM. GENERACION:Comprobamos si existen referencias por las muchas=false de Pelicula
		
					//COM. GENERACION:Comprobamos si existe alguna referencia muchas=true referenciando a esta por la entidad Actor
					
					//vamos a eliminar tupla a la entidad dependiente ActorPelicula
		
					//DAO dependiente
					ActorPeliculaDAO ActorPeliculaDAOprotagonista_de = new JDBCActorPeliculaDAOImpl();
					ActorPeliculaDAOprotagonista_de.setConnection(conn);
		
					//eliminar tupla
					ActorPeliculaDAOprotagonista_de.delete(id);
		
		
				//COM. GENERACION:Comprobamos si existen referencias por las muchas=true de Pelicula
		
				//Redirigir
				logger.info("Borrado Pelicula");	
				response.sendRedirect("CRUDPeliculaIndiceServlet");
				
			}
		
		}
		
		
