package es.unex.giiis.dmss.dao;

import java.sql.Connection;
import java.util.List;

import es.unex.giiis.dmss.model.Director;



public interface DirectorDAO {

	public void setConnection(Connection conn);
	

	public List<Director> getAll();

	public Director get(long id);

	public boolean add(Director aDirector);

	public boolean delete(long id);

}
