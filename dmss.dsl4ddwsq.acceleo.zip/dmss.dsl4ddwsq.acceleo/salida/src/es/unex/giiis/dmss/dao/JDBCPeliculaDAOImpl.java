
package es.unex.giiis.dmss.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import es.unex.giiis.dmss.model.Pelicula;


public class JDBCPeliculaDAOImpl implements PeliculaDAO {

	private Connection conn;

	@Override
	public void setConnection(Connection conn){
		this.conn = conn;
	}
	
	@Override
	public List<Pelicula> getAllByActor(long idu){
		if (conn == null) return null;
						
		ArrayList<Pelicula> list = new ArrayList<Pelicula>();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM Pelicula WHERE protagonista="+idu);

			while ( rs.next() ) {
				Pelicula element = new Pelicula();


				element.setname(rs.getString("name"));




				element.setimage(rs.getString("image"));





				element.setid_Pelicula(rs.getInt("id_Pelicula"));



				//cargamos los datos de la referencia protagonista
				ActorDAO aActorDAO= new JDBCActorDAOImpl();
				aActorDAO.setConnection(this.conn);
	
				element.setprotagonista(aActorDAO.get(rs.getInt("protagonista")));
							
				list.add(element);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}


	@Override
	public List<Pelicula> getAll(){
		if (conn == null) return null;
						
		ArrayList<Pelicula> list = new ArrayList<Pelicula>();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM Pelicula");

			while ( rs.next() ) {
				Pelicula element = new Pelicula();


				element.setname(rs.getString("name"));




				element.setimage(rs.getString("image"));





				element.setid_Pelicula(rs.getInt("id_Pelicula"));



				ActorDAO aActorDAO= new JDBCActorDAOImpl();
				aActorDAO.setConnection(this.conn);
	
				element.setprotagonista(aActorDAO.get(rs.getInt("protagonista")));
							
				list.add(element);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}

	@Override
	public Pelicula get(long id){
		if (conn == null) return null;
		
		Pelicula element = null;		
		
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM Pelicula WHERE id_Pelicula="+id);			 
			if (!rs.next()) return null;

			element = new Pelicula();


			element.setname(rs.getString("name"));




			element.setimage(rs.getString("image"));





			element.setid_Pelicula(rs.getInt("id_Pelicula"));




			ActorDAO aActorDAO= new JDBCActorDAOImpl();
			aActorDAO.setConnection(this.conn);

			element.setprotagonista(aActorDAO.get(rs.getInt("protagonista")));
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return element;
	}

	@Override
	public boolean add(Pelicula aPelicula){
		boolean done = false;
		if (conn != null){
			
			Pelicula element= aPelicula;

			Statement stmt;
			try {
				stmt = conn.createStatement();
				stmt.executeUpdate("INSERT INTO Pelicula (name, image, id_Pelicula,protagonista) VALUES('"+
									element.getname()
+"','"+									element.getimage()
+"','"+									element.getid_Pelicula()
									+"','"+
									element.getprotagonista().getid_Actor()
									+"')");
						
				done= true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return done;
	}

	@Override
	public boolean delete(long id){
		boolean done = false;
		if (conn != null){

			Statement stmt;
			try {
				stmt = conn.createStatement();
				stmt.executeUpdate("DELETE FROM Pelicula WHERE id_Pelicula="+id);
				done= true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return done;
	}

	@Override
	public boolean deleteAllByActor(long idu){
		boolean done = false;
		if (conn != null){

			List<Pelicula> toDelete= this.getAllByActor(idu);
			
			for(int i=0; i<toDelete.size(); i++) {
				this.delete(toDelete.get(i).getid_Pelicula());
			}
			
			done= true;
		}
		return done;
	}
}

