		package es.unex.giiis.dmss.controller;
		
		import java.io.FileWriter;
		import java.io.IOException;
		import java.io.PrintWriter;
		import java.util.logging.Logger;
		import java.sql.Connection;
		
		
		import javax.servlet.RequestDispatcher;
		import javax.servlet.ServletException;
		import javax.servlet.annotation.WebServlet;
		import javax.servlet.http.HttpServlet;
		import javax.servlet.http.HttpServletRequest;
		import javax.servlet.http.HttpServletResponse;
		import javax.servlet.http.HttpSession;
		
		import es.unex.giiis.dmss.dao.*;
		import es.unex.giiis.dmss.model.*;
		
		/**
		 * Servlet implementation. Automatically generated
		 */
		@WebServlet("/CRUDActorBorradoServlet")
		public class CRUDActorBorradoServlet extends HttpServlet {
			private static final long serialVersionUID = 1L;
			private static final Logger logger = 
					Logger.getLogger(HttpServlet.class.getName());
		       
		    /**
		     * @see HttpServlet#HttpServlet()
		     */
		    public CRUDActorBorradoServlet() {
		
		        super();
		    }
		
			/**
			 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
			 */
			protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				logger.info("The request was made using GET");		
				HttpSession session = request.getSession();
		
				request.setCharacterEncoding("UTF-8");
				
				//Conexion
				Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		
				//DAO DAOobj = new DAOImpl y establecer conexion
				ActorDAO ActorDAOobj = new JDBCActorDAOImpl();
				ActorDAOobj.setConnection(conn);
				
				//Obtener el parámetro de la request
				Integer id = Integer.parseInt(request.getParameter("id"));
		
				//Obtener entidad
				Actor Actorobj = ActorDAOobj.get(id);
				
				//Dejarla en la request
				request.setAttribute("Actor",Actorobj);
		
		
				RequestDispatcher view = request.getRequestDispatcher("WEB-INF/CRUDActorBorrado.jsp");
				view.forward(request,response);	
			}
		
			/**
			 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
			 */
			protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {				
				request.setCharacterEncoding("UTF-8");
		
				logger.info("The request was made using POST");		
		
				
				//Obtener el parámetro de la request
				Integer id = Integer.parseInt(request.getParameter("id"));
		
				//Conexion
				Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		
				//DAO DAOobj = new DAOImpl y establecer conexion
				ActorDAO ActorDAOobj = new JDBCActorDAOImpl();
				ActorDAOobj.setConnection(conn);
						
				//Borrar Actor
				ActorDAOobj.delete(id);
		
				//Comprobación de dependientes, para borrar entradas
		
				//COM. GENERACION:Comprobamos si existen referencias por las muchas=false de Actor
		
				//COM. GENERACION:Comprobamos si existen referencias por las muchas=true de Actor
		
					//COM. GENERACION:Comprobamos si existe alguna referencia muchas=true referenciando a esta por la entidad Pelicula
					
					//vamos a eliminar tupla a la entidad dependiente org.eclipse.emf.ecore.impl.DynamicEObjectImpl@2d730799 (eClass: org.eclipse.emf.ecore.impl.EClassImpl@13d7f738 (name: Entidad) (instanceClassName: null) (abstract: false, interface: false))Pelicula
		
					//DAO dependiente
					ActorPeliculaDAO ActorPeliculaDAOprotagonista_deMuchas = new JDBCActorPeliculaDAOImpl();
					ActorPeliculaDAOprotagonista_deMuchas.setConnection(conn);
		
					//eliminar todas las tuplas
					ActorPeliculaDAOprotagonista_deMuchas.deleteAllByActor(id);
		
					//vamos a eliminar la tupla de la entidad Pelicula
		
					//DAO Pelicula
					PeliculaDAO PeliculaDAOprotagonista_deMuchas = new JDBCPeliculaDAOImpl();
					PeliculaDAOprotagonista_deMuchas.setConnection(conn);
		
					//eliminar tupla
					PeliculaDAOprotagonista_deMuchas.deleteAllByActor(id);
					
		
				//Redirigir
				logger.info("Borrado Actor");	
				response.sendRedirect("CRUDActorIndiceServlet");
				
			}
		
		}
		
		
