		package es.unex.giiis.dmss.controller;
		
		import java.io.FileWriter;
		import java.io.IOException;
		import java.io.PrintWriter;
		import java.util.logging.Logger;
		import java.sql.Connection;
		import java.util.ArrayList;
		import java.util.List;
		
		
		import javax.servlet.RequestDispatcher;
		import javax.servlet.ServletException;
		import javax.servlet.annotation.WebServlet;
		import javax.servlet.http.HttpServlet;
		import javax.servlet.http.HttpServletRequest;
		import javax.servlet.http.HttpServletResponse;
		import javax.servlet.http.HttpSession;
		
		import es.unex.giiis.dmss.dao.*;
		import es.unex.giiis.dmss.model.*;
		
		/**
		 * Servlet implementation. Automatically generated
		 */
		@WebServlet("/creacionDirectorServlet")
		public class creacionDirectorServlet extends HttpServlet {
			private static final long serialVersionUID = 1L;
			private static final Logger logger = 
					Logger.getLogger(HttpServlet.class.getName());
		       
		    /**
		     * @see HttpServlet#HttpServlet()
		     */
		    public creacionDirectorServlet() {
		
		        super();
		    }
		
			/**
			 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
			 */
			protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				logger.info("The request was made using GET");		
				HttpSession session = request.getSession();
		
				request.setCharacterEncoding("UTF-8");
		
				//Conexion
				Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		
				//Cargar las referencias a otras entidades de muchas=false
		
				RequestDispatcher view = request.getRequestDispatcher("WEB-INF/creacionDirector.jsp");
				view.forward(request,response);	
			}
		
			/**
			 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
			 */
			protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {				
				request.setCharacterEncoding("UTF-8");
				
				logger.info("The request was made using POST");		
		
				//Crear nuevo
				Director Directorobj = new Director();
		
				//Recuperar los atributos del form y asignar 
		
				//Conexion
				Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		
							String name = request.getParameter("name");
						Directorobj.setname(name);
		
							String image = request.getParameter("image");
						Directorobj.setimage(image);
		
							String nombre = request.getParameter("nombre");
						Directorobj.setnombre(nombre);
		
							String apellidos = request.getParameter("apellidos");
						Directorobj.setapellidos(apellidos);
		
							int fecha_nac = Integer.parseInt(request.getParameter("fecha_nac"));
						Directorobj.setfecha_nac(fecha_nac);
		
							int id_Director = Integer.parseInt(request.getParameter("id_Director"));
						Directorobj.setid_Director(id_Director);
		
		
		
				//DAO DAOobj = new DAOImpl y establecer conexion
				DirectorDAO DirectorDAOobj = new JDBCDirectorDAOImpl();
				DirectorDAOobj.setConnection(conn);
						
				//Guardar
				DirectorDAOobj.add(Directorobj);
		
				//Redirigir
				logger.info("Creado Director");	
		
				response.sendRedirect("indiceDirectorServlet");
			}
		
		}
		
		
