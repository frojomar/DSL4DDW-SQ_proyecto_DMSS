package es.unex.giiis.dmss.dao;

import java.sql.Connection;
import java.util.List;

import es.unex.giiis.dmss.model.Actor;



public interface ActorDAO {

	public void setConnection(Connection conn);
	

	public List<Actor> getAll();

	public Actor get(long id);

	public boolean add(Actor aActor);

	public boolean delete(long id);

}
