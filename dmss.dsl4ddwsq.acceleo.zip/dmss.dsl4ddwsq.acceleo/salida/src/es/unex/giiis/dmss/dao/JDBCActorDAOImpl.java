
package es.unex.giiis.dmss.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import es.unex.giiis.dmss.model.Actor;


public class JDBCActorDAOImpl implements ActorDAO {

	private Connection conn;

	@Override
	public void setConnection(Connection conn){
		this.conn = conn;
	}
	

	@Override
	public List<Actor> getAll(){
		if (conn == null) return null;
						
		ArrayList<Actor> list = new ArrayList<Actor>();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM Actor");

			while ( rs.next() ) {
				Actor element = new Actor();


				element.setname(rs.getString("name"));




				element.setimage(rs.getString("image"));




				element.setnombre_completo(rs.getString("nombre_completo"));




				element.setsexo(rs.getString("sexo"));





				element.setid_Actor(rs.getInt("id_Actor"));



							
				list.add(element);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}

	@Override
	public Actor get(long id){
		if (conn == null) return null;
		
		Actor element = null;		
		
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM Actor WHERE id_Actor="+id);			 
			if (!rs.next()) return null;

			element = new Actor();


			element.setname(rs.getString("name"));




			element.setimage(rs.getString("image"));




			element.setnombre_completo(rs.getString("nombre_completo"));




			element.setsexo(rs.getString("sexo"));





			element.setid_Actor(rs.getInt("id_Actor"));



			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return element;
	}

	@Override
	public boolean add(Actor aActor){
		boolean done = false;
		if (conn != null){
			
			Actor element= aActor;

			Statement stmt;
			try {
				stmt = conn.createStatement();
				stmt.executeUpdate("INSERT INTO Actor (name, image, nombre_completo, sexo, id_Actor) VALUES('"+
									element.getname()
+"','"+									element.getimage()
+"','"+									element.getnombre_completo()
+"','"+									element.getsexo()
+"','"+									element.getid_Actor()
									
									+"')");
						
				done= true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return done;
	}

	@Override
	public boolean delete(long id){
		boolean done = false;
		if (conn != null){

			Statement stmt;
			try {
				stmt = conn.createStatement();
				stmt.executeUpdate("DELETE FROM Actor WHERE id_Actor="+id);
				done= true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return done;
	}

}

