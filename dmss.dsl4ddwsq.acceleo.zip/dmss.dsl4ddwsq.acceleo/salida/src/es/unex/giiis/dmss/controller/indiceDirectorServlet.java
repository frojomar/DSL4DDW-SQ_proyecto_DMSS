		package es.unex.giiis.dmss.controller;
		
		import java.io.FileWriter;
		import java.io.IOException;
		import java.io.PrintWriter;
		import java.util.logging.Logger;
		import java.sql.Connection;
		import java.util.ArrayList;
		import java.util.List;
		
		import javax.servlet.RequestDispatcher;
		import javax.servlet.ServletException;
		import javax.servlet.annotation.WebServlet;
		import javax.servlet.http.HttpServlet;
		import javax.servlet.http.HttpServletRequest;
		import javax.servlet.http.HttpServletResponse;
		import javax.servlet.http.HttpSession;
		
		import es.unex.giiis.dmss.dao.JDBCDirectorDAOImpl;
		import es.unex.giiis.dmss.dao.DirectorDAO;
		import es.unex.giiis.dmss.model.Director;
		
		/**
		 * Servlet implementation. Automatically generated
		 */
		@WebServlet("/indiceDirectorServlet")
		public class indiceDirectorServlet extends HttpServlet {
			private static final long serialVersionUID = 1L;
			private static final Logger logger = 
					Logger.getLogger(HttpServlet.class.getName());
		       
		    /**
		     * @see HttpServlet#HttpServlet()
		     */
		    public indiceDirectorServlet() {
		
		        super();
		    }
		
			/**
			 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
			 */
			protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				logger.info("The request was made using GET");		
				HttpSession session = request.getSession();
		
				request.setCharacterEncoding("UTF-8");
		
				//Conexion
				Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		
				//DAO DAOobj = new DAOImpl y establecer conexion
				DirectorDAO DirectorDAOobj = new JDBCDirectorDAOImpl();
				DirectorDAOobj.setConnection(conn);
				
				//Obtener entidades de la Base de Datos
				List<Director> Directorobj = DirectorDAOobj.getAll();
				
				//Dejarla en la request
				request.setAttribute("DirectorList",Directorobj);
		
				RequestDispatcher view = request.getRequestDispatcher("WEB-INF/indiceDirector.jsp");
				view.forward(request,response);	
			}
		
			/**
			 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
			 */
			protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {				
				doGet(request, response);
			}
		
		}
