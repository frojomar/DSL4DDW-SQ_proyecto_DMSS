		package es.unex.giiis.dmss.controller;
		
		import java.io.FileWriter;
		import java.io.IOException;
		import java.io.PrintWriter;
		import java.util.logging.Logger;
		import java.sql.Connection;
		import java.util.ArrayList;
		import java.util.List;
		
		
		import javax.servlet.RequestDispatcher;
		import javax.servlet.ServletException;
		import javax.servlet.annotation.WebServlet;
		import javax.servlet.http.HttpServlet;
		import javax.servlet.http.HttpServletRequest;
		import javax.servlet.http.HttpServletResponse;
		import javax.servlet.http.HttpSession;
		
		import es.unex.giiis.dmss.dao.*;
		import es.unex.giiis.dmss.model.*;
		
		/**
		 * Servlet implementation. Automatically generated
		 */
		@WebServlet("/CRUDPeliculaCreacionServlet")
		public class CRUDPeliculaCreacionServlet extends HttpServlet {
			private static final long serialVersionUID = 1L;
			private static final Logger logger = 
					Logger.getLogger(HttpServlet.class.getName());
		       
		    /**
		     * @see HttpServlet#HttpServlet()
		     */
		    public CRUDPeliculaCreacionServlet() {
		
		        super();
		    }
		
			/**
			 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
			 */
			protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				logger.info("The request was made using GET");		
				HttpSession session = request.getSession();
		
				request.setCharacterEncoding("UTF-8");
		
				//Conexion
				Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		
				//Cargar las referencias a otras entidades de muchas=false
				//DAO DAOobj = new DAOImpl y establecer conexion para referencia protagonista a Actor
				ActorDAO ActorDAOprotagonista = new JDBCActorDAOImpl();
				ActorDAOprotagonista.setConnection(conn);
				
				//Obtener todas las instancias
				List<Actor> protagonistaList =ActorDAOprotagonista.getAll();
		
				//Dejarlas en la request
				request.setAttribute("protagonistaList",protagonistaList);
		
				RequestDispatcher view = request.getRequestDispatcher("WEB-INF/CRUDPeliculaCreacion.jsp");
				view.forward(request,response);	
			}
		
			/**
			 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
			 */
			protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {				
				request.setCharacterEncoding("UTF-8");
				
				logger.info("The request was made using POST");		
		
				//Crear nuevo
				Pelicula Peliculaobj = new Pelicula();
		
				//Recuperar los atributos del form y asignar 
		
				//Conexion
				Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		
							String name = request.getParameter("name");
						Peliculaobj.setname(name);
		
							String image = request.getParameter("image");
						Peliculaobj.setimage(image);
		
							int id_Pelicula = Integer.parseInt(request.getParameter("id_Pelicula"));
						Peliculaobj.setid_Pelicula(id_Pelicula);
		
		
						int protagonistaID = Integer.parseInt(request.getParameter("protagonista"));
						
						//DAO DAOobj = new DAOImpl y establecer conexion para la referencia protagonista a Actor
						ActorDAO ActorDAOprotagonista = new JDBCActorDAOImpl();
						ActorDAOprotagonista.setConnection(conn);
				
						//Obtener la instancia con id adecuado
						Actor protagonistaItem =ActorDAOprotagonista.get(protagonistaID);
				
						//Asignarselo a la nueva instancia
						Peliculaobj.setprotagonista(protagonistaItem);
							
		
						//COM. GENERACION:Comprobamos si existe alguna referencia muchas=true referenciando a esta por la entidad Actor
						
						//vamos a añadir tupla a la entidad dependiente ActorPelicula
		
						//DAO dependiente
						ActorPeliculaDAO ActorPeliculaDAOprotagonista_de = new JDBCActorPeliculaDAOImpl();
						ActorPeliculaDAOprotagonista_de.setConnection(conn);
		
						//añadir tupla
						ActorPeliculaDAOprotagonista_de.add(protagonistaID,Peliculaobj.getid_Pelicula());
		
		
				//DAO DAOobj = new DAOImpl y establecer conexion
				PeliculaDAO PeliculaDAOobj = new JDBCPeliculaDAOImpl();
				PeliculaDAOobj.setConnection(conn);
						
				//Guardar
				PeliculaDAOobj.add(Peliculaobj);
		
				//Redirigir
				logger.info("Creado Pelicula");	
		
				response.sendRedirect("CRUDPeliculaIndiceServlet");
			}
		
		}
		
		
