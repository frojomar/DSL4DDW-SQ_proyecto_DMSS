package es.unex.giiis.dmss.controller;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Logger;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 * Servlet implementation. Automatically generated
 */
@WebServlet("/EncuestaSatisfacionServlet")
public class EncuestaSatisfacionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = 
			Logger.getLogger(HttpServlet.class.getName());
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EncuestaSatisfacionServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		logger.info("The request was made using GET");		
		
		RequestDispatcher view = request.getRequestDispatcher("WEB-INF/EncuestaSatisfacion.jsp");
		view.forward(request,response);	
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {				
		HttpSession session = request.getSession();

		request.setCharacterEncoding("UTF-8");
		
		logger.info("The request was made using POST");
				
		PrintWriter out = null;
		FileWriter fwr= null;

		try {
			fwr = new FileWriter("EncuestaSatisfacionResultados.txt", true);
			out = new PrintWriter(fwr);
		

			out.println("NUEVO INTENTO DE CONTESTAR EL CUESTIONARIO");

				String Danostuopinion = request.getParameter("Danos tu opinion");
				out.println("Pregunta 'Danos tu opinion'"+Danostuopinion);
				out.println("");

				String Recomendariaslapagina = request.getParameter("Recomendarias la pagina");
				out.println("Pregunta 'Recomendarias la pagina'"+Recomendariaslapagina);
				out.println("");


			out.println("");
			out.println("");

		}catch(IOException e){
			logger.info("NO SE HA PODIDO CREAR EL FLUJO DE ESCRITURA");
		}
		finally {
			 if (out != null)
				 out.close();
		 }

		
		response.sendRedirect("ResultadosEncuestaSatisfacionServlet");
		
	}

}
