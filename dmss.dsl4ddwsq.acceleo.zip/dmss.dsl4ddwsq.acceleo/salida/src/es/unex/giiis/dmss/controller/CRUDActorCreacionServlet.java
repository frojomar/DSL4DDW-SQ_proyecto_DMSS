		package es.unex.giiis.dmss.controller;
		
		import java.io.FileWriter;
		import java.io.IOException;
		import java.io.PrintWriter;
		import java.util.logging.Logger;
		import java.sql.Connection;
		import java.util.ArrayList;
		import java.util.List;
		
		
		import javax.servlet.RequestDispatcher;
		import javax.servlet.ServletException;
		import javax.servlet.annotation.WebServlet;
		import javax.servlet.http.HttpServlet;
		import javax.servlet.http.HttpServletRequest;
		import javax.servlet.http.HttpServletResponse;
		import javax.servlet.http.HttpSession;
		
		import es.unex.giiis.dmss.dao.*;
		import es.unex.giiis.dmss.model.*;
		
		/**
		 * Servlet implementation. Automatically generated
		 */
		@WebServlet("/CRUDActorCreacionServlet")
		public class CRUDActorCreacionServlet extends HttpServlet {
			private static final long serialVersionUID = 1L;
			private static final Logger logger = 
					Logger.getLogger(HttpServlet.class.getName());
		       
		    /**
		     * @see HttpServlet#HttpServlet()
		     */
		    public CRUDActorCreacionServlet() {
		
		        super();
		    }
		
			/**
			 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
			 */
			protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				logger.info("The request was made using GET");		
				HttpSession session = request.getSession();
		
				request.setCharacterEncoding("UTF-8");
		
				//Conexion
				Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		
				//Cargar las referencias a otras entidades de muchas=false
		
				RequestDispatcher view = request.getRequestDispatcher("WEB-INF/CRUDActorCreacion.jsp");
				view.forward(request,response);	
			}
		
			/**
			 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
			 */
			protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {				
				request.setCharacterEncoding("UTF-8");
				
				logger.info("The request was made using POST");		
		
				//Crear nuevo
				Actor Actorobj = new Actor();
		
				//Recuperar los atributos del form y asignar 
		
				//Conexion
				Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		
							String name = request.getParameter("name");
						Actorobj.setname(name);
		
							String image = request.getParameter("image");
						Actorobj.setimage(image);
		
							String nombre_completo = request.getParameter("nombre_completo");
						Actorobj.setnombre_completo(nombre_completo);
		
							String sexo = request.getParameter("sexo");
						Actorobj.setsexo(sexo);
		
							int id_Actor = Integer.parseInt(request.getParameter("id_Actor"));
						Actorobj.setid_Actor(id_Actor);
		
		
		
				//DAO DAOobj = new DAOImpl y establecer conexion
				ActorDAO ActorDAOobj = new JDBCActorDAOImpl();
				ActorDAOobj.setConnection(conn);
						
				//Guardar
				ActorDAOobj.add(Actorobj);
		
				//Redirigir
				logger.info("Creado Actor");	
		
				response.sendRedirect("CRUDActorIndiceServlet");
			}
		
		}
		
		
