package es.unex.giiis.dmss.model;


import java.util.ArrayList;
import java.util.List;

/*
Codigo generado automaticamente
No modificar

Clase generada: Pelicula.java

*/
public class Pelicula {
	//Atributos
		private String name; //Atributo name
		private String image; //Atributo image
		private Integer id_Pelicula; //Atributo id_Pelicula
		private Actor protagonista;


	//Metodos
	//Generación de getters y setters
		public String getname(){
			return name;
		}

		public void setname(String _name){
			name= _name;
		}
		public String getimage(){
			return image;
		}

		public void setimage(String _image){
			image= _image;
		}
		public Integer getid_Pelicula(){
			return id_Pelicula;
		}

		public void setid_Pelicula(Integer _id_Pelicula){
			id_Pelicula= _id_Pelicula;
		}

		
		public Actor getprotagonista(){
			return protagonista;
		}

		public void setprotagonista(Actor _protagonista){
			protagonista= _protagonista;
		}


	//Constructor por defecto
	public Pelicula(){
				name=new String("");
				image=new String("");
					id_Pelicula=new Integer(0);
				protagonista= new Actor();
	}
	//Constructor parametrizado
	public Pelicula(String name, String image, Integer id_Pelicula, Actor protagonista ){
			this.name=name;
			this.image=image;
			this.id_Pelicula=id_Pelicula;
			this.protagonista= protagonista;
	}
	//Operación toString
	public String toString(){
		String result="";
			result=result.concat("name: "+this.name+" -- ");
			result=result.concat("image: "+this.image+" -- ");
			result=result.concat("id_Pelicula: "+this.id_Pelicula+" -- ");
			result=result.concat("protagonista: "+this.protagonista.toString()+" -- ");
		return result;
	}
}
