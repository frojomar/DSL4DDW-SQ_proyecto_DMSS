package es.unex.giiis.dmss.controller;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Logger;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 * Servlet implementation. Automatically generated
 */
@WebServlet("/CuestionarioConocimientosESDLAServlet")
public class CuestionarioConocimientosESDLAServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = 
			Logger.getLogger(HttpServlet.class.getName());
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CuestionarioConocimientosESDLAServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		logger.info("The request was made using GET");		
		
		RequestDispatcher view = request.getRequestDispatcher("WEB-INF/CuestionarioConocimientosESDLA.jsp");
		view.forward(request,response);	
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {				
		HttpSession session = request.getSession();

		request.setCharacterEncoding("UTF-8");
		
		logger.info("The request was made using POST");
				
		PrintWriter out = null;
		FileWriter fwr= null;

		try {
			fwr = new FileWriter("CuestionarioConocimientosESDLAResultados.txt", true);
			out = new PrintWriter(fwr);
		

			out.println("NUEVO INTENTO DE CONTESTAR EL CUESTIONARIO");

				String Comosellamaelhobbitqueportaelanillo = request.getParameter("Como se llama el hobbit que porta el anillo");
				out.println("Pregunta 'Como se llama el hobbit que porta el anillo'"+Comosellamaelhobbitqueportaelanillo);
				out.println("");

				String Comosellamasucompañero = request.getParameter("Como se llama su compañero");
				out.println("Pregunta 'Como se llama su compañero'"+Comosellamasucompañero);
				out.println("");

				String ExisteunpersonajellamadoGandalf = request.getParameter("Existe un personaje llamado Gandalf");
				out.println("Pregunta 'Existe un personaje llamado Gandalf'"+ExisteunpersonajellamadoGandalf);
				out.println("");


			out.println("");
			out.println("");

		}catch(IOException e){
			logger.info("NO SE HA PODIDO CREAR EL FLUJO DE ESCRITURA");
		}
		finally {
			 if (out != null)
				 out.close();
		 }

			Float resultado= new Float(9.5);
			session.setAttribute("resultado", resultado);
		
		response.sendRedirect("ResultadosCuestionarioConocimientosESDLAServlet");
		
	}

}
