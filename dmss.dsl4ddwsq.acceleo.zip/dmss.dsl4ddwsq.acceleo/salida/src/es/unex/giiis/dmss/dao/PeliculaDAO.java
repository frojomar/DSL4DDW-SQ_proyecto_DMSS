package es.unex.giiis.dmss.dao;

import java.sql.Connection;
import java.util.List;

import es.unex.giiis.dmss.model.Pelicula;



public interface PeliculaDAO {

	public void setConnection(Connection conn);
	
	public List<Pelicula> getAllByActor(long idu);


	public List<Pelicula> getAll();

	public Pelicula get(long id);

	public boolean add(Pelicula aPelicula);

	public boolean delete(long id);

	public boolean deleteAllByActor(long idu);

}
