package es.unex.giiis.dmss.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class JDBCActorPeliculaDAOImpl implements ActorPeliculaDAO {

	private Connection conn;

	@Override
	public void setConnection(Connection conn){
		this.conn = conn;
	}
	
	@Override
	public List<Integer> getAllByActor(long id){
		if (conn == null) return null;
						
		ArrayList<Integer> list = new ArrayList<Integer>();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM ActorPelicula WHERE Actor_key="+id);

			while ( rs.next() ) {							
				
				list.add(rs.getInt("Pelicula_key"));

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}

	@Override
	public Integer get(long aPeliculaID){
		if (conn == null) return null;
		
		Integer element = null;		
		
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM ActorPelicula WHERE Pelicula_key="+aPeliculaID);			 
			if (!rs.next()) return null;

			element =rs.getInt("Actor_key");
		
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return element;
	}

	@Override
	public boolean add(Integer aActorID, Integer aPeliculaID){
		boolean done = false;
		if (conn != null){

			Statement stmt;
			try {
				stmt = conn.createStatement();
				stmt.executeUpdate("INSERT INTO ActorPelicula (Actor_key, Pelicula_key) VALUES('"+
									aActorID+"','"+
									aPeliculaID+"')");
						
				done= true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return done;
	}

	@Override
	public boolean delete(long aPeliculaID){
		boolean done = false;
		if (conn != null){

			Statement stmt;
			try {
				stmt = conn.createStatement();
				stmt.executeUpdate("DELETE FROM ActorPelicula WHERE Pelicula_key="+aPeliculaID);
				done= true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return done;
	}

	@Override
	public boolean deleteAllByActor(long id){
		boolean done = false;
		if (conn != null){

			List<Integer> toDelete= this.getAllByActor(id);
			
			for(int i=0; i<toDelete.size(); i++) {
				this.delete(toDelete.get(i));
			}
			
			done= true;
		}
		return done;
	}

}

