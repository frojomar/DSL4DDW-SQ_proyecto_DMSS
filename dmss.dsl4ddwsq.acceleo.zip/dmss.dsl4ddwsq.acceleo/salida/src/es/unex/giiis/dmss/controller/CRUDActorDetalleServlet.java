		
		package es.unex.giiis.dmss.controller;
		
		import java.io.FileWriter;
		import java.io.IOException;
		import java.io.PrintWriter;
		import java.util.logging.Logger;
		import java.sql.Connection;
		import java.util.ArrayList;
		import java.util.List;
		
		import javax.servlet.RequestDispatcher;
		import javax.servlet.ServletException;
		import javax.servlet.annotation.WebServlet;
		import javax.servlet.http.HttpServlet;
		import javax.servlet.http.HttpServletRequest;
		import javax.servlet.http.HttpServletResponse;
		import javax.servlet.http.HttpSession;
		
		import es.unex.giiis.dmss.dao.*;
		import es.unex.giiis.dmss.dao.*;
		import es.unex.giiis.dmss.model.*;
		
		
		/**
		 * Servlet implementation. Automatically generated
		 */
		@WebServlet("/CRUDActorDetalleServlet")
		public class CRUDActorDetalleServlet extends HttpServlet {
			private static final long serialVersionUID = 1L;
			private static final Logger logger = 
					Logger.getLogger(HttpServlet.class.getName());
		       
		    /**
		     * @see HttpServlet#HttpServlet()
		     */
		    public CRUDActorDetalleServlet() {
		
		        super();
		    }
		
			/**
			 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
			 */
			protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				logger.info("The request was made using GET");		
				HttpSession session = request.getSession();
		
				request.setCharacterEncoding("UTF-8");
		
				//Conexion
				Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		
				//DAO DAOobj = new DAOImpl y establecer conexion
				ActorDAO ActorDAOobj = new JDBCActorDAOImpl();
				ActorDAOobj.setConnection(conn);
				
				//Obtener el parámetro de la request
				Integer id = Integer.parseInt(request.getParameter("id"));
		
				//Obtener entidad
				Actor Actorobj = ActorDAOobj.get(id);
				
				//COM. GENERACION: vamos a recuperar las referencias de muchas=true y completarlas
					//cargamos los datos de la referencia multiple protagonista_de
		
					//DAO para convertir IDs
					PeliculaDAO Peliculaprotagonista_deDAO= new JDBCPeliculaDAOImpl();
					Peliculaprotagonista_deDAO.setConnection(conn);
					//DAO para obtener IDs
					ActorPeliculaDAO protagonista_deDAO= new JDBCActorPeliculaDAOImpl();
					protagonista_deDAO.setConnection(conn);
		
					List<Integer> protagonista_deIDlist = protagonista_deDAO.getAllByActor(Actorobj.getid_Actor());
		
					List<Pelicula> protagonista_delist= new ArrayList<Pelicula>();
		 
						for(int i=0; i<protagonista_deIDlist.size(); i++){
						protagonista_delist.add(Peliculaprotagonista_deDAO.get(protagonista_deIDlist.get(i)));
					}
		
					Actorobj.setprotagonista_de(protagonista_delist);
				//Dejarla en la request
				request.setAttribute("Actor",Actorobj);
		
				RequestDispatcher view = request.getRequestDispatcher("WEB-INF/CRUDActorDetalle.jsp");
				view.forward(request,response);	
			}
		
			/**
			 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
			 */
			protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {				
				doGet(request, response);
			}
		
		}
		
