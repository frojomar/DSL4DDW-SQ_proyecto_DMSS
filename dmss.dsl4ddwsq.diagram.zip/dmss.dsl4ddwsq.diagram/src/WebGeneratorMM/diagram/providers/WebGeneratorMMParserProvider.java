/*
 * 
 */
package WebGeneratorMM.diagram.providers;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.common.core.service.AbstractProvider;
import org.eclipse.gmf.runtime.common.core.service.IOperation;
import org.eclipse.gmf.runtime.common.ui.services.parser.GetParserOperation;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParser;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParserProvider;
import org.eclipse.gmf.runtime.common.ui.services.parser.ParserService;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.emf.ui.services.parser.ParserHintAdapter;
import org.eclipse.gmf.runtime.notation.View;

/**
 * @generated
 */
public class WebGeneratorMMParserProvider extends AbstractProvider implements IParserProvider {

	/**
	* @generated
	*/
	private IParser indiceName_5004Parser;

	/**
	* @generated
	*/
	private IParser getIndiceName_5004Parser() {
		if (indiceName_5004Parser == null) {
			EAttribute[] features = new EAttribute[] {
					WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getPaginaWeb_Name() };
			WebGeneratorMM.diagram.parsers.MessageFormatParser parser = new WebGeneratorMM.diagram.parsers.MessageFormatParser(
					features);
			indiceName_5004Parser = parser;
		}
		return indiceName_5004Parser;
	}

	/**
	* @generated
	*/
	private IParser paginaCRUDName_5005Parser;

	/**
	* @generated
	*/
	private IParser getPaginaCRUDName_5005Parser() {
		if (paginaCRUDName_5005Parser == null) {
			EAttribute[] features = new EAttribute[] {
					WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getPaginaWeb_Name() };
			WebGeneratorMM.diagram.parsers.MessageFormatParser parser = new WebGeneratorMM.diagram.parsers.MessageFormatParser(
					features);
			paginaCRUDName_5005Parser = parser;
		}
		return paginaCRUDName_5005Parser;
	}

	/**
	* @generated
	*/
	private IParser encuestaName_5007Parser;

	/**
	* @generated
	*/
	private IParser getEncuestaName_5007Parser() {
		if (encuestaName_5007Parser == null) {
			EAttribute[] features = new EAttribute[] {
					WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getPaginaWeb_Name() };
			WebGeneratorMM.diagram.parsers.MessageFormatParser parser = new WebGeneratorMM.diagram.parsers.MessageFormatParser(
					features);
			encuestaName_5007Parser = parser;
		}
		return encuestaName_5007Parser;
	}

	/**
	* @generated
	*/
	private IParser cuestionarioName_5008Parser;

	/**
	* @generated
	*/
	private IParser getCuestionarioName_5008Parser() {
		if (cuestionarioName_5008Parser == null) {
			EAttribute[] features = new EAttribute[] {
					WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getPaginaWeb_Name() };
			WebGeneratorMM.diagram.parsers.MessageFormatParser parser = new WebGeneratorMM.diagram.parsers.MessageFormatParser(
					features);
			cuestionarioName_5008Parser = parser;
		}
		return cuestionarioName_5008Parser;
	}

	/**
	* @generated
	*/
	private IParser detalleName_5009Parser;

	/**
	* @generated
	*/
	private IParser getDetalleName_5009Parser() {
		if (detalleName_5009Parser == null) {
			EAttribute[] features = new EAttribute[] {
					WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getPaginaWeb_Name() };
			WebGeneratorMM.diagram.parsers.MessageFormatParser parser = new WebGeneratorMM.diagram.parsers.MessageFormatParser(
					features);
			detalleName_5009Parser = parser;
		}
		return detalleName_5009Parser;
	}

	/**
	* @generated
	*/
	private IParser borradoName_5010Parser;

	/**
	* @generated
	*/
	private IParser getBorradoName_5010Parser() {
		if (borradoName_5010Parser == null) {
			EAttribute[] features = new EAttribute[] {
					WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getPaginaWeb_Name() };
			WebGeneratorMM.diagram.parsers.MessageFormatParser parser = new WebGeneratorMM.diagram.parsers.MessageFormatParser(
					features);
			borradoName_5010Parser = parser;
		}
		return borradoName_5010Parser;
	}

	/**
	* @generated
	*/
	private IParser creacionName_5011Parser;

	/**
	* @generated
	*/
	private IParser getCreacionName_5011Parser() {
		if (creacionName_5011Parser == null) {
			EAttribute[] features = new EAttribute[] {
					WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getPaginaWeb_Name() };
			WebGeneratorMM.diagram.parsers.MessageFormatParser parser = new WebGeneratorMM.diagram.parsers.MessageFormatParser(
					features);
			creacionName_5011Parser = parser;
		}
		return creacionName_5011Parser;
	}

	/**
	* @generated
	*/
	private IParser paginaHomeName_5012Parser;

	/**
	* @generated
	*/
	private IParser getPaginaHomeName_5012Parser() {
		if (paginaHomeName_5012Parser == null) {
			EAttribute[] features = new EAttribute[] {
					WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getPaginaWeb_Name() };
			WebGeneratorMM.diagram.parsers.MessageFormatParser parser = new WebGeneratorMM.diagram.parsers.MessageFormatParser(
					features);
			paginaHomeName_5012Parser = parser;
		}
		return paginaHomeName_5012Parser;
	}

	/**
	* @generated
	*/
	private IParser entidadName_5015Parser;

	/**
	* @generated
	*/
	private IParser getEntidadName_5015Parser() {
		if (entidadName_5015Parser == null) {
			EAttribute[] features = new EAttribute[] {
					WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getEntidad_Name() };
			WebGeneratorMM.diagram.parsers.MessageFormatParser parser = new WebGeneratorMM.diagram.parsers.MessageFormatParser(
					features);
			entidadName_5015Parser = parser;
		}
		return entidadName_5015Parser;
	}

	/**
	* @generated
	*/
	private IParser enlaceExternoName_5001Parser;

	/**
	* @generated
	*/
	private IParser getEnlaceExternoName_5001Parser() {
		if (enlaceExternoName_5001Parser == null) {
			EAttribute[] features = new EAttribute[] {
					WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getEnlace_Name() };
			WebGeneratorMM.diagram.parsers.MessageFormatParser parser = new WebGeneratorMM.diagram.parsers.MessageFormatParser(
					features);
			enlaceExternoName_5001Parser = parser;
		}
		return enlaceExternoName_5001Parser;
	}

	/**
	* @generated
	*/
	private IParser enlaceInternoName_5002Parser;

	/**
	* @generated
	*/
	private IParser getEnlaceInternoName_5002Parser() {
		if (enlaceInternoName_5002Parser == null) {
			EAttribute[] features = new EAttribute[] {
					WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getEnlace_Name() };
			WebGeneratorMM.diagram.parsers.MessageFormatParser parser = new WebGeneratorMM.diagram.parsers.MessageFormatParser(
					features);
			enlaceInternoName_5002Parser = parser;
		}
		return enlaceInternoName_5002Parser;
	}

	/**
	* @generated
	*/
	private IParser conexionRedSocialTag_5003Parser;

	/**
	* @generated
	*/
	private IParser getConexionRedSocialTag_5003Parser() {
		if (conexionRedSocialTag_5003Parser == null) {
			EAttribute[] features = new EAttribute[] {
					WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getConexionRedSocial_Tag() };
			WebGeneratorMM.diagram.parsers.MessageFormatParser parser = new WebGeneratorMM.diagram.parsers.MessageFormatParser(
					features);
			conexionRedSocialTag_5003Parser = parser;
		}
		return conexionRedSocialTag_5003Parser;
	}

	/**
	* @generated
	*/
	private IParser preguntaCortaContent_5006Parser;

	/**
	* @generated
	*/
	private IParser getPreguntaCortaContent_5006Parser() {
		if (preguntaCortaContent_5006Parser == null) {
			EAttribute[] features = new EAttribute[] {
					WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getPregunta_Content() };
			WebGeneratorMM.diagram.parsers.MessageFormatParser parser = new WebGeneratorMM.diagram.parsers.MessageFormatParser(
					features);
			preguntaCortaContent_5006Parser = parser;
		}
		return preguntaCortaContent_5006Parser;
	}

	/**
	* @generated
	*/
	private IParser preguntaElegirContent_5017Parser;

	/**
	* @generated
	*/
	private IParser getPreguntaElegirContent_5017Parser() {
		if (preguntaElegirContent_5017Parser == null) {
			EAttribute[] features = new EAttribute[] {
					WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getPregunta_Content() };
			WebGeneratorMM.diagram.parsers.MessageFormatParser parser = new WebGeneratorMM.diagram.parsers.MessageFormatParser(
					features);
			preguntaElegirContent_5017Parser = parser;
		}
		return preguntaElegirContent_5017Parser;
	}

	/**
	* @generated
	*/
	private IParser opcionContent_5016Parser;

	/**
	* @generated
	*/
	private IParser getOpcionContent_5016Parser() {
		if (opcionContent_5016Parser == null) {
			EAttribute[] features = new EAttribute[] {
					WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getOpcion_Content() };
			WebGeneratorMM.diagram.parsers.MessageFormatParser parser = new WebGeneratorMM.diagram.parsers.MessageFormatParser(
					features);
			opcionContent_5016Parser = parser;
		}
		return opcionContent_5016Parser;
	}

	/**
	* @generated
	*/
	private IParser preguntaVFContent_5018Parser;

	/**
	* @generated
	*/
	private IParser getPreguntaVFContent_5018Parser() {
		if (preguntaVFContent_5018Parser == null) {
			EAttribute[] features = new EAttribute[] {
					WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getPregunta_Content() };
			WebGeneratorMM.diagram.parsers.MessageFormatParser parser = new WebGeneratorMM.diagram.parsers.MessageFormatParser(
					features);
			preguntaVFContent_5018Parser = parser;
		}
		return preguntaVFContent_5018Parser;
	}

	/**
	* @generated
	*/
	private IParser referenciaName_5013Parser;

	/**
	* @generated
	*/
	private IParser getReferenciaName_5013Parser() {
		if (referenciaName_5013Parser == null) {
			EAttribute[] features = new EAttribute[] {
					WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getReferencia_Name() };
			WebGeneratorMM.diagram.parsers.MessageFormatParser parser = new WebGeneratorMM.diagram.parsers.MessageFormatParser(
					features);
			referenciaName_5013Parser = parser;
		}
		return referenciaName_5013Parser;
	}

	/**
	* @generated
	*/
	private IParser atributoName_5014Parser;

	/**
	* @generated
	*/
	private IParser getAtributoName_5014Parser() {
		if (atributoName_5014Parser == null) {
			EAttribute[] features = new EAttribute[] {
					WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getAtributo_Name() };
			WebGeneratorMM.diagram.parsers.MessageFormatParser parser = new WebGeneratorMM.diagram.parsers.MessageFormatParser(
					features);
			atributoName_5014Parser = parser;
		}
		return atributoName_5014Parser;
	}

	/**
	* @generated
	*/
	protected IParser getParser(int visualID) {
		switch (visualID) {
		case WebGeneratorMM.diagram.edit.parts.IndiceNameEditPart.VISUAL_ID:
			return getIndiceName_5004Parser();
		case WebGeneratorMM.diagram.edit.parts.PaginaCRUDNameEditPart.VISUAL_ID:
			return getPaginaCRUDName_5005Parser();
		case WebGeneratorMM.diagram.edit.parts.EncuestaNameEditPart.VISUAL_ID:
			return getEncuestaName_5007Parser();
		case WebGeneratorMM.diagram.edit.parts.CuestionarioNameEditPart.VISUAL_ID:
			return getCuestionarioName_5008Parser();
		case WebGeneratorMM.diagram.edit.parts.DetalleNameEditPart.VISUAL_ID:
			return getDetalleName_5009Parser();
		case WebGeneratorMM.diagram.edit.parts.BorradoNameEditPart.VISUAL_ID:
			return getBorradoName_5010Parser();
		case WebGeneratorMM.diagram.edit.parts.CreacionNameEditPart.VISUAL_ID:
			return getCreacionName_5011Parser();
		case WebGeneratorMM.diagram.edit.parts.PaginaHomeNameEditPart.VISUAL_ID:
			return getPaginaHomeName_5012Parser();
		case WebGeneratorMM.diagram.edit.parts.EntidadNameEditPart.VISUAL_ID:
			return getEntidadName_5015Parser();
		case WebGeneratorMM.diagram.edit.parts.EnlaceExternoNameEditPart.VISUAL_ID:
			return getEnlaceExternoName_5001Parser();
		case WebGeneratorMM.diagram.edit.parts.EnlaceInternoNameEditPart.VISUAL_ID:
			return getEnlaceInternoName_5002Parser();
		case WebGeneratorMM.diagram.edit.parts.ConexionRedSocialTagEditPart.VISUAL_ID:
			return getConexionRedSocialTag_5003Parser();
		case WebGeneratorMM.diagram.edit.parts.PreguntaCortaContentEditPart.VISUAL_ID:
			return getPreguntaCortaContent_5006Parser();
		case WebGeneratorMM.diagram.edit.parts.PreguntaElegirContentEditPart.VISUAL_ID:
			return getPreguntaElegirContent_5017Parser();
		case WebGeneratorMM.diagram.edit.parts.OpcionContentEditPart.VISUAL_ID:
			return getOpcionContent_5016Parser();
		case WebGeneratorMM.diagram.edit.parts.PreguntaVFContentEditPart.VISUAL_ID:
			return getPreguntaVFContent_5018Parser();
		case WebGeneratorMM.diagram.edit.parts.ReferenciaNameEditPart.VISUAL_ID:
			return getReferenciaName_5013Parser();
		case WebGeneratorMM.diagram.edit.parts.AtributoNameEditPart.VISUAL_ID:
			return getAtributoName_5014Parser();
		}
		return null;
	}

	/**
	* Utility method that consults ParserService
	* @generated
	*/
	public static IParser getParser(IElementType type, EObject object, String parserHint) {
		return ParserService.getInstance().getParser(new HintAdapter(type, object, parserHint));
	}

	/**
	* @generated
	*/
	public IParser getParser(IAdaptable hint) {
		String vid = (String) hint.getAdapter(String.class);
		if (vid != null) {
			return getParser(WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getVisualID(vid));
		}
		View view = (View) hint.getAdapter(View.class);
		if (view != null) {
			return getParser(WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getVisualID(view));
		}
		return null;
	}

	/**
	* @generated
	*/
	public boolean provides(IOperation operation) {
		if (operation instanceof GetParserOperation) {
			IAdaptable hint = ((GetParserOperation) operation).getHint();
			if (WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.getElement(hint) == null) {
				return false;
			}
			return getParser(hint) != null;
		}
		return false;
	}

	/**
	* @generated
	*/
	private static class HintAdapter extends ParserHintAdapter {

		/**
		* @generated
		*/
		private final IElementType elementType;

		/**
		* @generated
		*/
		public HintAdapter(IElementType type, EObject object, String parserHint) {
			super(object, parserHint);
			assert type != null;
			elementType = type;
		}

		/**
		* @generated
		*/
		public Object getAdapter(Class adapter) {
			if (IElementType.class.equals(adapter)) {
				return elementType;
			}
			return super.getAdapter(adapter);
		}
	}

}
