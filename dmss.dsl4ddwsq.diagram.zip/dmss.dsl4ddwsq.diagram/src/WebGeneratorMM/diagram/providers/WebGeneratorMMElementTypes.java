/*
 * 
 */
package WebGeneratorMM.diagram.providers;

import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.ENamedElement;
import org.eclipse.gmf.runtime.emf.type.core.ElementTypeRegistry;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.tooling.runtime.providers.DiagramElementTypeImages;
import org.eclipse.gmf.tooling.runtime.providers.DiagramElementTypes;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.graphics.Image;

/**
 * @generated
 */
public class WebGeneratorMMElementTypes {

	/**
	* @generated
	*/
	private WebGeneratorMMElementTypes() {
	}

	/**
	* @generated
	*/
	private static Map<IElementType, ENamedElement> elements;

	/**
	* @generated
	*/
	private static DiagramElementTypeImages elementTypeImages = new DiagramElementTypeImages(
			WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
					.getItemProvidersAdapterFactory());

	/**
	* @generated
	*/
	private static Set<IElementType> KNOWN_ELEMENT_TYPES;

	/**
	* @generated
	*/
	public static final IElementType SitioWeb_1000 = getElementType("dmss.dsl4ddwsq.diagram.SitioWeb_1000"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Indice_2001 = getElementType("dmss.dsl4ddwsq.diagram.Indice_2001"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType PaginaCRUD_2002 = getElementType("dmss.dsl4ddwsq.diagram.PaginaCRUD_2002"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Encuesta_2003 = getElementType("dmss.dsl4ddwsq.diagram.Encuesta_2003"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Cuestionario_2004 = getElementType("dmss.dsl4ddwsq.diagram.Cuestionario_2004"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Detalle_2005 = getElementType("dmss.dsl4ddwsq.diagram.Detalle_2005"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Borrado_2006 = getElementType("dmss.dsl4ddwsq.diagram.Borrado_2006"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Creacion_2007 = getElementType("dmss.dsl4ddwsq.diagram.Creacion_2007"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType PaginaHome_2008 = getElementType("dmss.dsl4ddwsq.diagram.PaginaHome_2008"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Entidad_2009 = getElementType("dmss.dsl4ddwsq.diagram.Entidad_2009"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType EnlaceExterno_3001 = getElementType("dmss.dsl4ddwsq.diagram.EnlaceExterno_3001"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType EnlaceInterno_3002 = getElementType("dmss.dsl4ddwsq.diagram.EnlaceInterno_3002"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType ConexionRedSocial_3003 = getElementType(
			"dmss.dsl4ddwsq.diagram.ConexionRedSocial_3003"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType PreguntaCorta_3004 = getElementType("dmss.dsl4ddwsq.diagram.PreguntaCorta_3004"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType PreguntaElegir_3007 = getElementType("dmss.dsl4ddwsq.diagram.PreguntaElegir_3007"); //$NON-NLS-1$

	/**
	* @generated
	*/
	public static final IElementType Opcion_3008 = getElementType("dmss.dsl4ddwsq.diagram.Opcion_3008"); //$NON-NLS-1$

	/**
	* @generated
	*/
	public static final IElementType PreguntaVF_3009 = getElementType("dmss.dsl4ddwsq.diagram.PreguntaVF_3009"); //$NON-NLS-1$

	/**
	* @generated
	*/
	public static final IElementType Referencia_3005 = getElementType("dmss.dsl4ddwsq.diagram.Referencia_3005"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Atributo_3006 = getElementType("dmss.dsl4ddwsq.diagram.Atributo_3006"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType ReferenciaDestino_4001 = getElementType(
			"dmss.dsl4ddwsq.diagram.ReferenciaDestino_4001"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType EnlaceInternoReferencia_4002 = getElementType(
			"dmss.dsl4ddwsq.diagram.EnlaceInternoReferencia_4002"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType PaginaEntidadEntidad_4003 = getElementType(
			"dmss.dsl4ddwsq.diagram.PaginaEntidadEntidad_4003"); //$NON-NLS-1$

	/**
	* @generated
	*/
	public static ImageDescriptor getImageDescriptor(ENamedElement element) {
		return elementTypeImages.getImageDescriptor(element);
	}

	/**
	* @generated
	*/
	public static Image getImage(ENamedElement element) {
		return elementTypeImages.getImage(element);
	}

	/**
	* @generated
	*/
	public static ImageDescriptor getImageDescriptor(IAdaptable hint) {
		return getImageDescriptor(getElement(hint));
	}

	/**
	* @generated
	*/
	public static Image getImage(IAdaptable hint) {
		return getImage(getElement(hint));
	}

	/**
	* Returns 'type' of the ecore object associated with the hint.
	* 
	* @generated
	*/
	public static ENamedElement getElement(IAdaptable hint) {
		Object type = hint.getAdapter(IElementType.class);
		if (elements == null) {
			elements = new IdentityHashMap<IElementType, ENamedElement>();

			elements.put(SitioWeb_1000, WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getSitioWeb());

			elements.put(Indice_2001, WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getIndice());

			elements.put(PaginaCRUD_2002, WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getPaginaCRUD());

			elements.put(Encuesta_2003, WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getEncuesta());

			elements.put(Cuestionario_2004, WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getCuestionario());

			elements.put(Detalle_2005, WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getDetalle());

			elements.put(Borrado_2006, WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getBorrado());

			elements.put(Creacion_2007, WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getCreacion());

			elements.put(PaginaHome_2008, WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getPaginaHome());

			elements.put(Entidad_2009, WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getEntidad());

			elements.put(EnlaceExterno_3001, WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getEnlaceExterno());

			elements.put(EnlaceInterno_3002, WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getEnlaceInterno());

			elements.put(ConexionRedSocial_3003, WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getConexionRedSocial());

			elements.put(PreguntaCorta_3004, WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getPreguntaCorta());

			elements.put(PreguntaElegir_3007, WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getPreguntaElegir());

			elements.put(Opcion_3008, WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getOpcion());

			elements.put(PreguntaVF_3009, WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getPreguntaVF());

			elements.put(Referencia_3005, WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getReferencia());

			elements.put(Atributo_3006, WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getAtributo());

			elements.put(ReferenciaDestino_4001,
					WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getReferencia_Destino());

			elements.put(EnlaceInternoReferencia_4002,
					WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getEnlaceInterno_Referencia());

			elements.put(PaginaEntidadEntidad_4003,
					WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getPaginaEntidad_Entidad());
		}
		return (ENamedElement) elements.get(type);
	}

	/**
	* @generated
	*/
	private static IElementType getElementType(String id) {
		return ElementTypeRegistry.getInstance().getType(id);
	}

	/**
	* @generated
	*/
	public static boolean isKnownElementType(IElementType elementType) {
		if (KNOWN_ELEMENT_TYPES == null) {
			KNOWN_ELEMENT_TYPES = new HashSet<IElementType>();
			KNOWN_ELEMENT_TYPES.add(SitioWeb_1000);
			KNOWN_ELEMENT_TYPES.add(Indice_2001);
			KNOWN_ELEMENT_TYPES.add(PaginaCRUD_2002);
			KNOWN_ELEMENT_TYPES.add(Encuesta_2003);
			KNOWN_ELEMENT_TYPES.add(Cuestionario_2004);
			KNOWN_ELEMENT_TYPES.add(Detalle_2005);
			KNOWN_ELEMENT_TYPES.add(Borrado_2006);
			KNOWN_ELEMENT_TYPES.add(Creacion_2007);
			KNOWN_ELEMENT_TYPES.add(PaginaHome_2008);
			KNOWN_ELEMENT_TYPES.add(Entidad_2009);
			KNOWN_ELEMENT_TYPES.add(EnlaceExterno_3001);
			KNOWN_ELEMENT_TYPES.add(EnlaceInterno_3002);
			KNOWN_ELEMENT_TYPES.add(ConexionRedSocial_3003);
			KNOWN_ELEMENT_TYPES.add(PreguntaCorta_3004);
			KNOWN_ELEMENT_TYPES.add(PreguntaElegir_3007);
			KNOWN_ELEMENT_TYPES.add(Opcion_3008);
			KNOWN_ELEMENT_TYPES.add(PreguntaVF_3009);
			KNOWN_ELEMENT_TYPES.add(Referencia_3005);
			KNOWN_ELEMENT_TYPES.add(Atributo_3006);
			KNOWN_ELEMENT_TYPES.add(ReferenciaDestino_4001);
			KNOWN_ELEMENT_TYPES.add(EnlaceInternoReferencia_4002);
			KNOWN_ELEMENT_TYPES.add(PaginaEntidadEntidad_4003);
		}
		return KNOWN_ELEMENT_TYPES.contains(elementType);
	}

	/**
	* @generated
	*/
	public static IElementType getElementType(int visualID) {
		switch (visualID) {
		case WebGeneratorMM.diagram.edit.parts.SitioWebEditPart.VISUAL_ID:
			return SitioWeb_1000;
		case WebGeneratorMM.diagram.edit.parts.IndiceEditPart.VISUAL_ID:
			return Indice_2001;
		case WebGeneratorMM.diagram.edit.parts.PaginaCRUDEditPart.VISUAL_ID:
			return PaginaCRUD_2002;
		case WebGeneratorMM.diagram.edit.parts.EncuestaEditPart.VISUAL_ID:
			return Encuesta_2003;
		case WebGeneratorMM.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID:
			return Cuestionario_2004;
		case WebGeneratorMM.diagram.edit.parts.DetalleEditPart.VISUAL_ID:
			return Detalle_2005;
		case WebGeneratorMM.diagram.edit.parts.BorradoEditPart.VISUAL_ID:
			return Borrado_2006;
		case WebGeneratorMM.diagram.edit.parts.CreacionEditPart.VISUAL_ID:
			return Creacion_2007;
		case WebGeneratorMM.diagram.edit.parts.PaginaHomeEditPart.VISUAL_ID:
			return PaginaHome_2008;
		case WebGeneratorMM.diagram.edit.parts.EntidadEditPart.VISUAL_ID:
			return Entidad_2009;
		case WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID:
			return EnlaceExterno_3001;
		case WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID:
			return EnlaceInterno_3002;
		case WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID:
			return ConexionRedSocial_3003;
		case WebGeneratorMM.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID:
			return PreguntaCorta_3004;
		case WebGeneratorMM.diagram.edit.parts.PreguntaElegirEditPart.VISUAL_ID:
			return PreguntaElegir_3007;
		case WebGeneratorMM.diagram.edit.parts.OpcionEditPart.VISUAL_ID:
			return Opcion_3008;
		case WebGeneratorMM.diagram.edit.parts.PreguntaVFEditPart.VISUAL_ID:
			return PreguntaVF_3009;
		case WebGeneratorMM.diagram.edit.parts.ReferenciaEditPart.VISUAL_ID:
			return Referencia_3005;
		case WebGeneratorMM.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
			return Atributo_3006;
		case WebGeneratorMM.diagram.edit.parts.ReferenciaDestinoEditPart.VISUAL_ID:
			return ReferenciaDestino_4001;
		case WebGeneratorMM.diagram.edit.parts.EnlaceInternoReferenciaEditPart.VISUAL_ID:
			return EnlaceInternoReferencia_4002;
		case WebGeneratorMM.diagram.edit.parts.PaginaEntidadEntidadEditPart.VISUAL_ID:
			return PaginaEntidadEntidad_4003;
		}
		return null;
	}

	/**
	* @generated
	*/
	public static final DiagramElementTypes TYPED_INSTANCE = new DiagramElementTypes(elementTypeImages) {

		/**
		* @generated
		*/
		@Override

		public boolean isKnownElementType(IElementType elementType) {
			return WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.isKnownElementType(elementType);
		}

		/**
		* @generated
		*/
		@Override

		public IElementType getElementTypeForVisualId(int visualID) {
			return WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.getElementType(visualID);
		}

		/**
		* @generated
		*/
		@Override

		public ENamedElement getDefiningNamedElement(IAdaptable elementTypeAdapter) {
			return WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.getElement(elementTypeAdapter);
		}
	};

}
