/*
 * 
 */
package WebGeneratorMM.diagram.providers;

import org.eclipse.gmf.tooling.runtime.providers.DefaultEditPartProvider;

/**
 * @generated
 */
public class WebGeneratorMMEditPartProvider extends DefaultEditPartProvider {

	/**
	* @generated
	*/
	public WebGeneratorMMEditPartProvider() {
		super(new WebGeneratorMM.diagram.edit.parts.WebGeneratorMMEditPartFactory(),
				WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.TYPED_INSTANCE,
				WebGeneratorMM.diagram.edit.parts.SitioWebEditPart.MODEL_ID);
	}

}
