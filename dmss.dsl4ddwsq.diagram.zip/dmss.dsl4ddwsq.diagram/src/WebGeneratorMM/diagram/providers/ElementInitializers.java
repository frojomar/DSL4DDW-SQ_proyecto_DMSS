/*
 * 
 */
package WebGeneratorMM.diagram.providers;

/**
 * @generated
 */
public class ElementInitializers {

	protected ElementInitializers() {
		// use #getInstance to access cached instance
	}

	/**
	* @generated
	*/
	public static ElementInitializers getInstance() {
		ElementInitializers cached = WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
				.getElementInitializers();
		if (cached == null) {
			WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
					.setElementInitializers(cached = new ElementInitializers());
		}
		return cached;
	}
}
