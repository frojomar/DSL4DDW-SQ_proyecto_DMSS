/*
 * 
 */
package WebGeneratorMM.diagram.providers;

import org.eclipse.gmf.runtime.common.ui.services.icon.IIconProvider;
import org.eclipse.gmf.tooling.runtime.providers.DefaultElementTypeIconProvider;

/**
 * @generated
 */
public class WebGeneratorMMIconProvider extends DefaultElementTypeIconProvider implements IIconProvider {

	/**
	* @generated
	*/
	public WebGeneratorMMIconProvider() {
		super(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.TYPED_INSTANCE);
	}

}
