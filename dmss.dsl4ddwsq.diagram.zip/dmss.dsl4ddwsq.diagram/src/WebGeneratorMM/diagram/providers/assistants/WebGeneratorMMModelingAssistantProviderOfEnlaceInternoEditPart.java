/*
 * 
 */
package WebGeneratorMM.diagram.providers.assistants;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;

/**
 * @generated
 */
public class WebGeneratorMMModelingAssistantProviderOfEnlaceInternoEditPart
		extends WebGeneratorMM.diagram.providers.WebGeneratorMMModelingAssistantProvider {

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getRelTypesOnSource(IAdaptable source) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnSource((WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart) sourceEditPart);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetRelTypesOnSource(WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart source) {
		List<IElementType> types = new ArrayList<IElementType>(1);
		types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceInternoReferencia_4002);
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getRelTypesOnSourceAndTarget(IAdaptable source, IAdaptable target) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source.getAdapter(IGraphicalEditPart.class);
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnSourceAndTarget((WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart) sourceEditPart,
				targetEditPart);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetRelTypesOnSourceAndTarget(
			WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart source, IGraphicalEditPart targetEditPart) {
		List<IElementType> types = new LinkedList<IElementType>();
		if (targetEditPart instanceof WebGeneratorMM.diagram.edit.parts.IndiceEditPart) {
			types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceInternoReferencia_4002);
		}
		if (targetEditPart instanceof WebGeneratorMM.diagram.edit.parts.PaginaCRUDEditPart) {
			types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceInternoReferencia_4002);
		}
		if (targetEditPart instanceof WebGeneratorMM.diagram.edit.parts.EncuestaEditPart) {
			types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceInternoReferencia_4002);
		}
		if (targetEditPart instanceof WebGeneratorMM.diagram.edit.parts.CuestionarioEditPart) {
			types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceInternoReferencia_4002);
		}
		if (targetEditPart instanceof WebGeneratorMM.diagram.edit.parts.DetalleEditPart) {
			types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceInternoReferencia_4002);
		}
		if (targetEditPart instanceof WebGeneratorMM.diagram.edit.parts.BorradoEditPart) {
			types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceInternoReferencia_4002);
		}
		if (targetEditPart instanceof WebGeneratorMM.diagram.edit.parts.CreacionEditPart) {
			types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceInternoReferencia_4002);
		}
		if (targetEditPart instanceof WebGeneratorMM.diagram.edit.parts.PaginaHomeEditPart) {
			types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceInternoReferencia_4002);
		}
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getTypesForTarget(IAdaptable source, IElementType relationshipType) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source.getAdapter(IGraphicalEditPart.class);
		return doGetTypesForTarget((WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart) sourceEditPart,
				relationshipType);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetTypesForTarget(WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart source,
			IElementType relationshipType) {
		List<IElementType> types = new ArrayList<IElementType>();
		if (relationshipType == WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceInternoReferencia_4002) {
			types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Indice_2001);
			types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PaginaCRUD_2002);
			types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Encuesta_2003);
			types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Cuestionario_2004);
			types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Detalle_2005);
			types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Borrado_2006);
			types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Creacion_2007);
			types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PaginaHome_2008);
		}
		return types;
	}

}
