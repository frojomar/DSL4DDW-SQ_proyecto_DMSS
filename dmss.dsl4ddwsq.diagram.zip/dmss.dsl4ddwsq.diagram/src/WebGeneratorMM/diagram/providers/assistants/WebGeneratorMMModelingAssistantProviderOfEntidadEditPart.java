/*
 * 
 */
package WebGeneratorMM.diagram.providers.assistants;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;

/**
 * @generated
 */
public class WebGeneratorMMModelingAssistantProviderOfEntidadEditPart
		extends WebGeneratorMM.diagram.providers.WebGeneratorMMModelingAssistantProvider {

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getTypesForPopupBar(IAdaptable host) {
		List<IElementType> types = new ArrayList<IElementType>(2);
		types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Referencia_3005);
		types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Atributo_3006);
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getRelTypesOnTarget(IAdaptable target) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnTarget((WebGeneratorMM.diagram.edit.parts.EntidadEditPart) targetEditPart);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetRelTypesOnTarget(WebGeneratorMM.diagram.edit.parts.EntidadEditPart target) {
		List<IElementType> types = new ArrayList<IElementType>(2);
		types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.ReferenciaDestino_4001);
		types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PaginaEntidadEntidad_4003);
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getTypesForSource(IAdaptable target, IElementType relationshipType) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetTypesForSource((WebGeneratorMM.diagram.edit.parts.EntidadEditPart) targetEditPart,
				relationshipType);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetTypesForSource(WebGeneratorMM.diagram.edit.parts.EntidadEditPart target,
			IElementType relationshipType) {
		List<IElementType> types = new ArrayList<IElementType>();
		if (relationshipType == WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.ReferenciaDestino_4001) {
			types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Referencia_3005);
		} else if (relationshipType == WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PaginaEntidadEntidad_4003) {
			types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Indice_2001);
			types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PaginaCRUD_2002);
			types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Detalle_2005);
			types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Borrado_2006);
			types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Creacion_2007);
		}
		return types;
	}

}
