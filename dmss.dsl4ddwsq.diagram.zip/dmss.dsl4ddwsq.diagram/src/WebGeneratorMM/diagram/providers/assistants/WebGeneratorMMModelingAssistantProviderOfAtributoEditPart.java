/*
 * 
 */
package WebGeneratorMM.diagram.providers.assistants;

/**
 * @generated
 */
public class WebGeneratorMMModelingAssistantProviderOfAtributoEditPart
		extends WebGeneratorMM.diagram.providers.WebGeneratorMMModelingAssistantProvider {

}
