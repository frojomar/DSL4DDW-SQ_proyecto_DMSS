/*
 * 
 */
package WebGeneratorMM.diagram.providers.assistants;

/**
 * @generated
 */
public class WebGeneratorMMModelingAssistantProviderOfConexionRedSocialEditPart
		extends WebGeneratorMM.diagram.providers.WebGeneratorMMModelingAssistantProvider {

}
