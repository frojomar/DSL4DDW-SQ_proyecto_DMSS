/*
 * 
 */
package WebGeneratorMM.diagram.providers.assistants;

/**
 * @generated
 */
public class WebGeneratorMMModelingAssistantProviderOfPreguntaVFEditPart
		extends WebGeneratorMM.diagram.providers.WebGeneratorMMModelingAssistantProvider {

}
