/*
 * 
 */
package WebGeneratorMM.diagram.providers.assistants;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;

/**
 * @generated
 */
public class WebGeneratorMMModelingAssistantProviderOfCreacionEditPart
		extends WebGeneratorMM.diagram.providers.WebGeneratorMMModelingAssistantProvider {

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getTypesForPopupBar(IAdaptable host) {
		List<IElementType> types = new ArrayList<IElementType>(3);
		types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.ConexionRedSocial_3003);
		types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceExterno_3001);
		types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceInterno_3002);
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getRelTypesOnSource(IAdaptable source) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnSource((WebGeneratorMM.diagram.edit.parts.CreacionEditPart) sourceEditPart);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetRelTypesOnSource(WebGeneratorMM.diagram.edit.parts.CreacionEditPart source) {
		List<IElementType> types = new ArrayList<IElementType>(1);
		types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PaginaEntidadEntidad_4003);
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getRelTypesOnSourceAndTarget(IAdaptable source, IAdaptable target) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source.getAdapter(IGraphicalEditPart.class);
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnSourceAndTarget((WebGeneratorMM.diagram.edit.parts.CreacionEditPart) sourceEditPart,
				targetEditPart);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetRelTypesOnSourceAndTarget(WebGeneratorMM.diagram.edit.parts.CreacionEditPart source,
			IGraphicalEditPart targetEditPart) {
		List<IElementType> types = new LinkedList<IElementType>();
		if (targetEditPart instanceof WebGeneratorMM.diagram.edit.parts.EntidadEditPart) {
			types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PaginaEntidadEntidad_4003);
		}
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getTypesForTarget(IAdaptable source, IElementType relationshipType) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source.getAdapter(IGraphicalEditPart.class);
		return doGetTypesForTarget((WebGeneratorMM.diagram.edit.parts.CreacionEditPart) sourceEditPart,
				relationshipType);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetTypesForTarget(WebGeneratorMM.diagram.edit.parts.CreacionEditPart source,
			IElementType relationshipType) {
		List<IElementType> types = new ArrayList<IElementType>();
		if (relationshipType == WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PaginaEntidadEntidad_4003) {
			types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Entidad_2009);
		}
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getRelTypesOnTarget(IAdaptable target) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnTarget((WebGeneratorMM.diagram.edit.parts.CreacionEditPart) targetEditPart);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetRelTypesOnTarget(WebGeneratorMM.diagram.edit.parts.CreacionEditPart target) {
		List<IElementType> types = new ArrayList<IElementType>(1);
		types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceInternoReferencia_4002);
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getTypesForSource(IAdaptable target, IElementType relationshipType) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetTypesForSource((WebGeneratorMM.diagram.edit.parts.CreacionEditPart) targetEditPart,
				relationshipType);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetTypesForSource(WebGeneratorMM.diagram.edit.parts.CreacionEditPart target,
			IElementType relationshipType) {
		List<IElementType> types = new ArrayList<IElementType>();
		if (relationshipType == WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceInternoReferencia_4002) {
			types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceInterno_3002);
		}
		return types;
	}

}
