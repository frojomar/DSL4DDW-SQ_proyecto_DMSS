/*
 * 
 */
package WebGeneratorMM.diagram.providers.assistants;

/**
 * @generated
 */
public class WebGeneratorMMModelingAssistantProviderOfOpcionEditPart
		extends WebGeneratorMM.diagram.providers.WebGeneratorMMModelingAssistantProvider {

}
