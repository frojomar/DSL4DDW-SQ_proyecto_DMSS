/*
 * 
 */
package WebGeneratorMM.diagram.providers.assistants;

/**
 * @generated
 */
public class WebGeneratorMMModelingAssistantProviderOfPreguntaCortaEditPart
		extends WebGeneratorMM.diagram.providers.WebGeneratorMMModelingAssistantProvider {

}
