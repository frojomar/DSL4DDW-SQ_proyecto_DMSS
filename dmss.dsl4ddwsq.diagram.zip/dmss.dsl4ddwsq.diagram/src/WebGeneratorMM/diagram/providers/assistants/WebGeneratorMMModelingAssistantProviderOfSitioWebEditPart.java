/*
 * 
 */
package WebGeneratorMM.diagram.providers.assistants;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;

/**
 * @generated
 */
public class WebGeneratorMMModelingAssistantProviderOfSitioWebEditPart
		extends WebGeneratorMM.diagram.providers.WebGeneratorMMModelingAssistantProvider {

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getTypesForPopupBar(IAdaptable host) {
		List<IElementType> types = new ArrayList<IElementType>(9);
		types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Indice_2001);
		types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PaginaCRUD_2002);
		types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Encuesta_2003);
		types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Cuestionario_2004);
		types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Detalle_2005);
		types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Borrado_2006);
		types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Creacion_2007);
		types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PaginaHome_2008);
		types.add(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Entidad_2009);
		return types;
	}

}
