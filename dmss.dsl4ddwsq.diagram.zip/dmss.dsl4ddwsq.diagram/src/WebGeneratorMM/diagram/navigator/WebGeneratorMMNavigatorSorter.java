/*
* 
*/
package WebGeneratorMM.diagram.navigator;

import org.eclipse.jface.viewers.ViewerSorter;

/**
 * @generated
 */
public class WebGeneratorMMNavigatorSorter extends ViewerSorter {

	/**
	* @generated
	*/
	private static final int GROUP_CATEGORY = 7023;

	/**
	* @generated
	*/
	private static final int SHORTCUTS_CATEGORY = 7022;

	/**
	* @generated
	*/
	public int category(Object element) {
		if (element instanceof WebGeneratorMM.diagram.navigator.WebGeneratorMMNavigatorItem) {
			WebGeneratorMM.diagram.navigator.WebGeneratorMMNavigatorItem item = (WebGeneratorMM.diagram.navigator.WebGeneratorMMNavigatorItem) element;
			if (item.getView().getEAnnotation("Shortcut") != null) { //$NON-NLS-1$
				return SHORTCUTS_CATEGORY;
			}
			return WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getVisualID(item.getView());
		}
		return GROUP_CATEGORY;
	}

}
