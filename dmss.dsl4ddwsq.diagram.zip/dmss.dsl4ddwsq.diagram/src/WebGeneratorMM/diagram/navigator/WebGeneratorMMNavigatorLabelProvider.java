/*
* 
*/
package WebGeneratorMM.diagram.navigator;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.common.ui.services.parser.CommonParserHint;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParser;
import org.eclipse.gmf.runtime.common.ui.services.parser.ParserOptions;
import org.eclipse.gmf.runtime.emf.core.util.EObjectAdapter;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.jface.viewers.ITreePathLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TreePath;
import org.eclipse.jface.viewers.ViewerLabel;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.IMemento;
import org.eclipse.ui.navigator.ICommonContentExtensionSite;
import org.eclipse.ui.navigator.ICommonLabelProvider;

/**
 * @generated
 */
public class WebGeneratorMMNavigatorLabelProvider extends LabelProvider
		implements ICommonLabelProvider, ITreePathLabelProvider {

	/**
	* @generated
	*/
	static {
		WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance().getImageRegistry()
				.put("Navigator?UnknownElement", ImageDescriptor.getMissingImageDescriptor()); //$NON-NLS-1$
		WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance().getImageRegistry()
				.put("Navigator?ImageNotFound", ImageDescriptor.getMissingImageDescriptor()); //$NON-NLS-1$
	}

	/**
	* @generated
	*/
	public void updateLabel(ViewerLabel label, TreePath elementPath) {
		Object element = elementPath.getLastSegment();
		if (element instanceof WebGeneratorMM.diagram.navigator.WebGeneratorMMNavigatorItem
				&& !isOwnView(((WebGeneratorMM.diagram.navigator.WebGeneratorMMNavigatorItem) element).getView())) {
			return;
		}
		label.setText(getText(element));
		label.setImage(getImage(element));
	}

	/**
	* @generated
	*/
	public Image getImage(Object element) {
		if (element instanceof WebGeneratorMM.diagram.navigator.WebGeneratorMMNavigatorGroup) {
			WebGeneratorMM.diagram.navigator.WebGeneratorMMNavigatorGroup group = (WebGeneratorMM.diagram.navigator.WebGeneratorMMNavigatorGroup) element;
			return WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
					.getBundledImage(group.getIcon());
		}

		if (element instanceof WebGeneratorMM.diagram.navigator.WebGeneratorMMNavigatorItem) {
			WebGeneratorMM.diagram.navigator.WebGeneratorMMNavigatorItem navigatorItem = (WebGeneratorMM.diagram.navigator.WebGeneratorMMNavigatorItem) element;
			if (!isOwnView(navigatorItem.getView())) {
				return super.getImage(element);
			}
			return getImage(navigatorItem.getView());
		}

		// Due to plugin.xml content will be called only for "own" views
		if (element instanceof IAdaptable) {
			View view = (View) ((IAdaptable) element).getAdapter(View.class);
			if (view != null && isOwnView(view)) {
				return getImage(view);
			}
		}

		return super.getImage(element);
	}

	/**
	* @generated
	*/
	public Image getImage(View view) {
		switch (WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getVisualID(view)) {
		case WebGeneratorMM.diagram.edit.parts.SitioWebEditPart.VISUAL_ID:
			return getImage("Navigator?Diagram?http://www.unex.es/dmss/WebGeneratorMM?SitioWeb", //$NON-NLS-1$
					WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.SitioWeb_1000);
		case WebGeneratorMM.diagram.edit.parts.IndiceEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?http://www.unex.es/dmss/WebGeneratorMM?Indice", //$NON-NLS-1$
					WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Indice_2001);
		case WebGeneratorMM.diagram.edit.parts.PaginaCRUDEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?http://www.unex.es/dmss/WebGeneratorMM?PaginaCRUD", //$NON-NLS-1$
					WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PaginaCRUD_2002);
		case WebGeneratorMM.diagram.edit.parts.EncuestaEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?http://www.unex.es/dmss/WebGeneratorMM?Encuesta", //$NON-NLS-1$
					WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Encuesta_2003);
		case WebGeneratorMM.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?http://www.unex.es/dmss/WebGeneratorMM?Cuestionario", //$NON-NLS-1$
					WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Cuestionario_2004);
		case WebGeneratorMM.diagram.edit.parts.DetalleEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?http://www.unex.es/dmss/WebGeneratorMM?Detalle", //$NON-NLS-1$
					WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Detalle_2005);
		case WebGeneratorMM.diagram.edit.parts.BorradoEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?http://www.unex.es/dmss/WebGeneratorMM?Borrado", //$NON-NLS-1$
					WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Borrado_2006);
		case WebGeneratorMM.diagram.edit.parts.CreacionEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?http://www.unex.es/dmss/WebGeneratorMM?Creacion", //$NON-NLS-1$
					WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Creacion_2007);
		case WebGeneratorMM.diagram.edit.parts.PaginaHomeEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?http://www.unex.es/dmss/WebGeneratorMM?PaginaHome", //$NON-NLS-1$
					WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PaginaHome_2008);
		case WebGeneratorMM.diagram.edit.parts.EntidadEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?http://www.unex.es/dmss/WebGeneratorMM?Entidad", //$NON-NLS-1$
					WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Entidad_2009);
		case WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.unex.es/dmss/WebGeneratorMM?EnlaceExterno", //$NON-NLS-1$
					WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceExterno_3001);
		case WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.unex.es/dmss/WebGeneratorMM?EnlaceInterno", //$NON-NLS-1$
					WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceInterno_3002);
		case WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.unex.es/dmss/WebGeneratorMM?ConexionRedSocial", //$NON-NLS-1$
					WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.ConexionRedSocial_3003);
		case WebGeneratorMM.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.unex.es/dmss/WebGeneratorMM?PreguntaCorta", //$NON-NLS-1$
					WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PreguntaCorta_3004);
		case WebGeneratorMM.diagram.edit.parts.ReferenciaEditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.unex.es/dmss/WebGeneratorMM?Referencia", //$NON-NLS-1$
					WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Referencia_3005);
		case WebGeneratorMM.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.unex.es/dmss/WebGeneratorMM?Atributo", //$NON-NLS-1$
					WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Atributo_3006);
		case WebGeneratorMM.diagram.edit.parts.PreguntaElegirEditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.unex.es/dmss/WebGeneratorMM?PreguntaElegir", //$NON-NLS-1$
					WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PreguntaElegir_3007);
		case WebGeneratorMM.diagram.edit.parts.OpcionEditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.unex.es/dmss/WebGeneratorMM?Opcion", //$NON-NLS-1$
					WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Opcion_3008);
		case WebGeneratorMM.diagram.edit.parts.PreguntaVFEditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.unex.es/dmss/WebGeneratorMM?PreguntaVF", //$NON-NLS-1$
					WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PreguntaVF_3009);
		case WebGeneratorMM.diagram.edit.parts.ReferenciaDestinoEditPart.VISUAL_ID:
			return getImage("Navigator?Link?http://www.unex.es/dmss/WebGeneratorMM?Referencia?destino", //$NON-NLS-1$
					WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.ReferenciaDestino_4001);
		case WebGeneratorMM.diagram.edit.parts.EnlaceInternoReferenciaEditPart.VISUAL_ID:
			return getImage("Navigator?Link?http://www.unex.es/dmss/WebGeneratorMM?EnlaceInterno?referencia", //$NON-NLS-1$
					WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceInternoReferencia_4002);
		case WebGeneratorMM.diagram.edit.parts.PaginaEntidadEntidadEditPart.VISUAL_ID:
			return getImage("Navigator?Link?http://www.unex.es/dmss/WebGeneratorMM?PaginaEntidad?entidad", //$NON-NLS-1$
					WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PaginaEntidadEntidad_4003);
		}
		return getImage("Navigator?UnknownElement", null); //$NON-NLS-1$
	}

	/**
	* @generated
	*/
	private Image getImage(String key, IElementType elementType) {
		ImageRegistry imageRegistry = WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
				.getImageRegistry();
		Image image = imageRegistry.get(key);
		if (image == null && elementType != null
				&& WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.isKnownElementType(elementType)) {
			image = WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.getImage(elementType);
			imageRegistry.put(key, image);
		}

		if (image == null) {
			image = imageRegistry.get("Navigator?ImageNotFound"); //$NON-NLS-1$
			imageRegistry.put(key, image);
		}
		return image;
	}

	/**
	* @generated
	*/
	public String getText(Object element) {
		if (element instanceof WebGeneratorMM.diagram.navigator.WebGeneratorMMNavigatorGroup) {
			WebGeneratorMM.diagram.navigator.WebGeneratorMMNavigatorGroup group = (WebGeneratorMM.diagram.navigator.WebGeneratorMMNavigatorGroup) element;
			return group.getGroupName();
		}

		if (element instanceof WebGeneratorMM.diagram.navigator.WebGeneratorMMNavigatorItem) {
			WebGeneratorMM.diagram.navigator.WebGeneratorMMNavigatorItem navigatorItem = (WebGeneratorMM.diagram.navigator.WebGeneratorMMNavigatorItem) element;
			if (!isOwnView(navigatorItem.getView())) {
				return null;
			}
			return getText(navigatorItem.getView());
		}

		// Due to plugin.xml content will be called only for "own" views
		if (element instanceof IAdaptable) {
			View view = (View) ((IAdaptable) element).getAdapter(View.class);
			if (view != null && isOwnView(view)) {
				return getText(view);
			}
		}

		return super.getText(element);
	}

	/**
	* @generated
	*/
	public String getText(View view) {
		if (view.getElement() != null && view.getElement().eIsProxy()) {
			return getUnresolvedDomainElementProxyText(view);
		}
		switch (WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getVisualID(view)) {
		case WebGeneratorMM.diagram.edit.parts.SitioWebEditPart.VISUAL_ID:
			return getSitioWeb_1000Text(view);
		case WebGeneratorMM.diagram.edit.parts.IndiceEditPart.VISUAL_ID:
			return getIndice_2001Text(view);
		case WebGeneratorMM.diagram.edit.parts.PaginaCRUDEditPart.VISUAL_ID:
			return getPaginaCRUD_2002Text(view);
		case WebGeneratorMM.diagram.edit.parts.EncuestaEditPart.VISUAL_ID:
			return getEncuesta_2003Text(view);
		case WebGeneratorMM.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID:
			return getCuestionario_2004Text(view);
		case WebGeneratorMM.diagram.edit.parts.DetalleEditPart.VISUAL_ID:
			return getDetalle_2005Text(view);
		case WebGeneratorMM.diagram.edit.parts.BorradoEditPart.VISUAL_ID:
			return getBorrado_2006Text(view);
		case WebGeneratorMM.diagram.edit.parts.CreacionEditPart.VISUAL_ID:
			return getCreacion_2007Text(view);
		case WebGeneratorMM.diagram.edit.parts.PaginaHomeEditPart.VISUAL_ID:
			return getPaginaHome_2008Text(view);
		case WebGeneratorMM.diagram.edit.parts.EntidadEditPart.VISUAL_ID:
			return getEntidad_2009Text(view);
		case WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID:
			return getEnlaceExterno_3001Text(view);
		case WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID:
			return getEnlaceInterno_3002Text(view);
		case WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID:
			return getConexionRedSocial_3003Text(view);
		case WebGeneratorMM.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID:
			return getPreguntaCorta_3004Text(view);
		case WebGeneratorMM.diagram.edit.parts.ReferenciaEditPart.VISUAL_ID:
			return getReferencia_3005Text(view);
		case WebGeneratorMM.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
			return getAtributo_3006Text(view);
		case WebGeneratorMM.diagram.edit.parts.PreguntaElegirEditPart.VISUAL_ID:
			return getPreguntaElegir_3007Text(view);
		case WebGeneratorMM.diagram.edit.parts.OpcionEditPart.VISUAL_ID:
			return getOpcion_3008Text(view);
		case WebGeneratorMM.diagram.edit.parts.PreguntaVFEditPart.VISUAL_ID:
			return getPreguntaVF_3009Text(view);
		case WebGeneratorMM.diagram.edit.parts.ReferenciaDestinoEditPart.VISUAL_ID:
			return getReferenciaDestino_4001Text(view);
		case WebGeneratorMM.diagram.edit.parts.EnlaceInternoReferenciaEditPart.VISUAL_ID:
			return getEnlaceInternoReferencia_4002Text(view);
		case WebGeneratorMM.diagram.edit.parts.PaginaEntidadEntidadEditPart.VISUAL_ID:
			return getPaginaEntidadEntidad_4003Text(view);
		}
		return getUnknownElementText(view);
	}

	/**
	* @generated
	*/
	private String getSitioWeb_1000Text(View view) {
		WebGeneratorMM.SitioWeb domainModelElement = (WebGeneratorMM.SitioWeb) view.getElement();
		if (domainModelElement != null) {
			return domainModelElement.getName();
		} else {
			WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
					.logError("No domain element for view with visualID = " + 1000); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getIndice_2001Text(View view) {
		IParser parser = WebGeneratorMM.diagram.providers.WebGeneratorMMParserProvider.getParser(
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Indice_2001,
				view.getElement() != null ? view.getElement() : view,
				WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry
						.getType(WebGeneratorMM.diagram.edit.parts.IndiceNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5004); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getPaginaCRUD_2002Text(View view) {
		IParser parser = WebGeneratorMM.diagram.providers.WebGeneratorMMParserProvider.getParser(
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PaginaCRUD_2002,
				view.getElement() != null ? view.getElement() : view,
				WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry
						.getType(WebGeneratorMM.diagram.edit.parts.PaginaCRUDNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5005); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getEncuesta_2003Text(View view) {
		IParser parser = WebGeneratorMM.diagram.providers.WebGeneratorMMParserProvider.getParser(
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Encuesta_2003,
				view.getElement() != null ? view.getElement() : view,
				WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry
						.getType(WebGeneratorMM.diagram.edit.parts.EncuestaNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5007); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getCuestionario_2004Text(View view) {
		IParser parser = WebGeneratorMM.diagram.providers.WebGeneratorMMParserProvider.getParser(
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Cuestionario_2004,
				view.getElement() != null ? view.getElement() : view,
				WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry
						.getType(WebGeneratorMM.diagram.edit.parts.CuestionarioNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5008); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getDetalle_2005Text(View view) {
		IParser parser = WebGeneratorMM.diagram.providers.WebGeneratorMMParserProvider.getParser(
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Detalle_2005,
				view.getElement() != null ? view.getElement() : view,
				WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry
						.getType(WebGeneratorMM.diagram.edit.parts.DetalleNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5009); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getBorrado_2006Text(View view) {
		IParser parser = WebGeneratorMM.diagram.providers.WebGeneratorMMParserProvider.getParser(
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Borrado_2006,
				view.getElement() != null ? view.getElement() : view,
				WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry
						.getType(WebGeneratorMM.diagram.edit.parts.BorradoNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5010); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getCreacion_2007Text(View view) {
		IParser parser = WebGeneratorMM.diagram.providers.WebGeneratorMMParserProvider.getParser(
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Creacion_2007,
				view.getElement() != null ? view.getElement() : view,
				WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry
						.getType(WebGeneratorMM.diagram.edit.parts.CreacionNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5011); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getPaginaHome_2008Text(View view) {
		IParser parser = WebGeneratorMM.diagram.providers.WebGeneratorMMParserProvider.getParser(
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PaginaHome_2008,
				view.getElement() != null ? view.getElement() : view,
				WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry
						.getType(WebGeneratorMM.diagram.edit.parts.PaginaHomeNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5012); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getEntidad_2009Text(View view) {
		IParser parser = WebGeneratorMM.diagram.providers.WebGeneratorMMParserProvider.getParser(
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Entidad_2009,
				view.getElement() != null ? view.getElement() : view,
				WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry
						.getType(WebGeneratorMM.diagram.edit.parts.EntidadNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5015); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getEnlaceExterno_3001Text(View view) {
		IParser parser = WebGeneratorMM.diagram.providers.WebGeneratorMMParserProvider.getParser(
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceExterno_3001,
				view.getElement() != null ? view.getElement() : view,
				WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry
						.getType(WebGeneratorMM.diagram.edit.parts.EnlaceExternoNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5001); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getEnlaceInterno_3002Text(View view) {
		IParser parser = WebGeneratorMM.diagram.providers.WebGeneratorMMParserProvider.getParser(
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceInterno_3002,
				view.getElement() != null ? view.getElement() : view,
				WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry
						.getType(WebGeneratorMM.diagram.edit.parts.EnlaceInternoNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5002); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getConexionRedSocial_3003Text(View view) {
		IParser parser = WebGeneratorMM.diagram.providers.WebGeneratorMMParserProvider.getParser(
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.ConexionRedSocial_3003,
				view.getElement() != null ? view.getElement() : view,
				WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry
						.getType(WebGeneratorMM.diagram.edit.parts.ConexionRedSocialTagEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5003); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getPreguntaCorta_3004Text(View view) {
		IParser parser = WebGeneratorMM.diagram.providers.WebGeneratorMMParserProvider.getParser(
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PreguntaCorta_3004,
				view.getElement() != null ? view.getElement() : view,
				WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry
						.getType(WebGeneratorMM.diagram.edit.parts.PreguntaCortaContentEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5006); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getReferencia_3005Text(View view) {
		IParser parser = WebGeneratorMM.diagram.providers.WebGeneratorMMParserProvider.getParser(
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Referencia_3005,
				view.getElement() != null ? view.getElement() : view,
				WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry
						.getType(WebGeneratorMM.diagram.edit.parts.ReferenciaNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5013); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getAtributo_3006Text(View view) {
		IParser parser = WebGeneratorMM.diagram.providers.WebGeneratorMMParserProvider.getParser(
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Atributo_3006,
				view.getElement() != null ? view.getElement() : view,
				WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry
						.getType(WebGeneratorMM.diagram.edit.parts.AtributoNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5014); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getPreguntaElegir_3007Text(View view) {
		IParser parser = WebGeneratorMM.diagram.providers.WebGeneratorMMParserProvider.getParser(
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PreguntaElegir_3007,
				view.getElement() != null ? view.getElement() : view,
				WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry
						.getType(WebGeneratorMM.diagram.edit.parts.PreguntaElegirContentEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5017); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getOpcion_3008Text(View view) {
		IParser parser = WebGeneratorMM.diagram.providers.WebGeneratorMMParserProvider.getParser(
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Opcion_3008,
				view.getElement() != null ? view.getElement() : view,
				WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry
						.getType(WebGeneratorMM.diagram.edit.parts.OpcionContentEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5016); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getPreguntaVF_3009Text(View view) {
		IParser parser = WebGeneratorMM.diagram.providers.WebGeneratorMMParserProvider.getParser(
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PreguntaVF_3009,
				view.getElement() != null ? view.getElement() : view,
				WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry
						.getType(WebGeneratorMM.diagram.edit.parts.PreguntaVFContentEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5018); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getReferenciaDestino_4001Text(View view) {
		IParser parser = WebGeneratorMM.diagram.providers.WebGeneratorMMParserProvider.getParser(
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.ReferenciaDestino_4001,
				view.getElement() != null ? view.getElement() : view, CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 6001); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getEnlaceInternoReferencia_4002Text(View view) {
		IParser parser = WebGeneratorMM.diagram.providers.WebGeneratorMMParserProvider.getParser(
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceInternoReferencia_4002,
				view.getElement() != null ? view.getElement() : view, CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 6002); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getPaginaEntidadEntidad_4003Text(View view) {
		IParser parser = WebGeneratorMM.diagram.providers.WebGeneratorMMParserProvider.getParser(
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PaginaEntidadEntidad_4003,
				view.getElement() != null ? view.getElement() : view, CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 6003); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getUnknownElementText(View view) {
		return "<UnknownElement Visual_ID = " + view.getType() + ">"; //$NON-NLS-1$  //$NON-NLS-2$
	}

	/**
	* @generated
	*/
	private String getUnresolvedDomainElementProxyText(View view) {
		return "<Unresolved domain element Visual_ID = " + view.getType() + ">"; //$NON-NLS-1$  //$NON-NLS-2$
	}

	/**
	* @generated
	*/
	public void init(ICommonContentExtensionSite aConfig) {
	}

	/**
	* @generated
	*/
	public void restoreState(IMemento aMemento) {
	}

	/**
	* @generated
	*/
	public void saveState(IMemento aMemento) {
	}

	/**
	* @generated
	*/
	public String getDescription(Object anElement) {
		return null;
	}

	/**
	* @generated
	*/
	private boolean isOwnView(View view) {
		return WebGeneratorMM.diagram.edit.parts.SitioWebEditPart.MODEL_ID
				.equals(WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getModelID(view));
	}

}
