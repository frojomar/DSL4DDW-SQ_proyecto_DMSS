/*
* 
*/
package WebGeneratorMM.diagram.part;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.gmf.tooling.runtime.update.DiagramUpdater;

/**
 * @generated
 */
public class WebGeneratorMMDiagramUpdater {

	/**
	* @generated
	*/
	public static boolean isShortcutOrphaned(View view) {
		return !view.isSetElement() || view.getElement() == null || view.getElement().eIsProxy();
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> getSemanticChildren(View view) {
		switch (WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getVisualID(view)) {
		case WebGeneratorMM.diagram.edit.parts.SitioWebEditPart.VISUAL_ID:
			return getSitioWeb_1000SemanticChildren(view);
		case WebGeneratorMM.diagram.edit.parts.IndiceIndiceConexionredsocialCompartmentEditPart.VISUAL_ID:
			return getIndiceIndiceConexionredsocialCompartment_7001SemanticChildren(view);
		case WebGeneratorMM.diagram.edit.parts.IndiceIndiceEnlacesCompartmentEditPart.VISUAL_ID:
			return getIndiceIndiceEnlacesCompartment_7002SemanticChildren(view);
		case WebGeneratorMM.diagram.edit.parts.PaginaCRUDPaginaCRUDConexionredsocialCompartmentEditPart.VISUAL_ID:
			return getPaginaCRUDPaginaCRUDConexionredsocialCompartment_7003SemanticChildren(view);
		case WebGeneratorMM.diagram.edit.parts.PaginaCRUDPaginaCRUDEnlacesCompartmentEditPart.VISUAL_ID:
			return getPaginaCRUDPaginaCRUDEnlacesCompartment_7004SemanticChildren(view);
		case WebGeneratorMM.diagram.edit.parts.EncuestaEncuestaConexionredsocialCompartmentEditPart.VISUAL_ID:
			return getEncuestaEncuestaConexionredsocialCompartment_7005SemanticChildren(view);
		case WebGeneratorMM.diagram.edit.parts.EncuestaEncuestaEnlacesCompartmentEditPart.VISUAL_ID:
			return getEncuestaEncuestaEnlacesCompartment_7006SemanticChildren(view);
		case WebGeneratorMM.diagram.edit.parts.EncuestaEncuestaPreguntasCompartmentEditPart.VISUAL_ID:
			return getEncuestaEncuestaPreguntasCompartment_7007SemanticChildren(view);
		case WebGeneratorMM.diagram.edit.parts.PreguntaElegirPreguntaElegirOpcionesCompartmentEditPart.VISUAL_ID:
			return getPreguntaElegirPreguntaElegirOpcionesCompartment_7021SemanticChildren(view);
		case WebGeneratorMM.diagram.edit.parts.CuestionarioCuestionarioConexionredsocialCompartmentEditPart.VISUAL_ID:
			return getCuestionarioCuestionarioConexionredsocialCompartment_7008SemanticChildren(view);
		case WebGeneratorMM.diagram.edit.parts.CuestionarioCuestionarioEnlacesCompartmentEditPart.VISUAL_ID:
			return getCuestionarioCuestionarioEnlacesCompartment_7009SemanticChildren(view);
		case WebGeneratorMM.diagram.edit.parts.CuestionarioCuestionarioPreguntasCompartmentEditPart.VISUAL_ID:
			return getCuestionarioCuestionarioPreguntasCompartment_7010SemanticChildren(view);
		case WebGeneratorMM.diagram.edit.parts.DetalleDetalleConexionredsocialCompartmentEditPart.VISUAL_ID:
			return getDetalleDetalleConexionredsocialCompartment_7011SemanticChildren(view);
		case WebGeneratorMM.diagram.edit.parts.DetalleDetalleEnlacesCompartmentEditPart.VISUAL_ID:
			return getDetalleDetalleEnlacesCompartment_7012SemanticChildren(view);
		case WebGeneratorMM.diagram.edit.parts.BorradoBorradoConexionredsocialCompartmentEditPart.VISUAL_ID:
			return getBorradoBorradoConexionredsocialCompartment_7013SemanticChildren(view);
		case WebGeneratorMM.diagram.edit.parts.BorradoBorradoEnlacesCompartmentEditPart.VISUAL_ID:
			return getBorradoBorradoEnlacesCompartment_7014SemanticChildren(view);
		case WebGeneratorMM.diagram.edit.parts.CreacionCreacionConexionredsocialCompartmentEditPart.VISUAL_ID:
			return getCreacionCreacionConexionredsocialCompartment_7015SemanticChildren(view);
		case WebGeneratorMM.diagram.edit.parts.CreacionCreacionEnlacesCompartmentEditPart.VISUAL_ID:
			return getCreacionCreacionEnlacesCompartment_7016SemanticChildren(view);
		case WebGeneratorMM.diagram.edit.parts.PaginaHomePaginaHomeConexionredsocialCompartmentEditPart.VISUAL_ID:
			return getPaginaHomePaginaHomeConexionredsocialCompartment_7017SemanticChildren(view);
		case WebGeneratorMM.diagram.edit.parts.PaginaHomePaginaHomeEnlacesCompartmentEditPart.VISUAL_ID:
			return getPaginaHomePaginaHomeEnlacesCompartment_7018SemanticChildren(view);
		case WebGeneratorMM.diagram.edit.parts.EntidadEntidadReferenciasCompartmentEditPart.VISUAL_ID:
			return getEntidadEntidadReferenciasCompartment_7019SemanticChildren(view);
		case WebGeneratorMM.diagram.edit.parts.EntidadEntidadAtributosCompartmentEditPart.VISUAL_ID:
			return getEntidadEntidadAtributosCompartment_7020SemanticChildren(view);
		}
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> getSitioWeb_1000SemanticChildren(
			View view) {
		if (!view.isSetElement()) {
			return Collections.emptyList();
		}
		WebGeneratorMM.SitioWeb modelElement = (WebGeneratorMM.SitioWeb) view.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor>();
		for (Iterator<?> it = modelElement.getPaginasweb().iterator(); it.hasNext();) {
			WebGeneratorMM.PaginaWeb childElement = (WebGeneratorMM.PaginaWeb) it.next();
			int visualID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == WebGeneratorMM.diagram.edit.parts.IndiceEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == WebGeneratorMM.diagram.edit.parts.PaginaCRUDEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == WebGeneratorMM.diagram.edit.parts.EncuestaEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == WebGeneratorMM.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == WebGeneratorMM.diagram.edit.parts.DetalleEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == WebGeneratorMM.diagram.edit.parts.BorradoEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == WebGeneratorMM.diagram.edit.parts.CreacionEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == WebGeneratorMM.diagram.edit.parts.PaginaHomeEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		for (Iterator<?> it = modelElement.getEntidadesModelo().iterator(); it.hasNext();) {
			WebGeneratorMM.Entidad childElement = (WebGeneratorMM.Entidad) it.next();
			int visualID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == WebGeneratorMM.diagram.edit.parts.EntidadEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> getIndiceIndiceConexionredsocialCompartment_7001SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		WebGeneratorMM.Indice modelElement = (WebGeneratorMM.Indice) containerView.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor>();
		for (Iterator<?> it = modelElement.getConexionredsocial().iterator(); it.hasNext();) {
			WebGeneratorMM.ConexionRedSocial childElement = (WebGeneratorMM.ConexionRedSocial) it.next();
			int visualID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> getIndiceIndiceEnlacesCompartment_7002SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		WebGeneratorMM.Indice modelElement = (WebGeneratorMM.Indice) containerView.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor>();
		for (Iterator<?> it = modelElement.getEnlaces().iterator(); it.hasNext();) {
			WebGeneratorMM.Enlace childElement = (WebGeneratorMM.Enlace) it.next();
			int visualID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> getPaginaCRUDPaginaCRUDConexionredsocialCompartment_7003SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		WebGeneratorMM.PaginaCRUD modelElement = (WebGeneratorMM.PaginaCRUD) containerView.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor>();
		for (Iterator<?> it = modelElement.getConexionredsocial().iterator(); it.hasNext();) {
			WebGeneratorMM.ConexionRedSocial childElement = (WebGeneratorMM.ConexionRedSocial) it.next();
			int visualID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> getPaginaCRUDPaginaCRUDEnlacesCompartment_7004SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		WebGeneratorMM.PaginaCRUD modelElement = (WebGeneratorMM.PaginaCRUD) containerView.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor>();
		for (Iterator<?> it = modelElement.getEnlaces().iterator(); it.hasNext();) {
			WebGeneratorMM.Enlace childElement = (WebGeneratorMM.Enlace) it.next();
			int visualID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> getEncuestaEncuestaConexionredsocialCompartment_7005SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		WebGeneratorMM.Encuesta modelElement = (WebGeneratorMM.Encuesta) containerView.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor>();
		for (Iterator<?> it = modelElement.getConexionredsocial().iterator(); it.hasNext();) {
			WebGeneratorMM.ConexionRedSocial childElement = (WebGeneratorMM.ConexionRedSocial) it.next();
			int visualID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> getEncuestaEncuestaEnlacesCompartment_7006SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		WebGeneratorMM.Encuesta modelElement = (WebGeneratorMM.Encuesta) containerView.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor>();
		for (Iterator<?> it = modelElement.getEnlaces().iterator(); it.hasNext();) {
			WebGeneratorMM.Enlace childElement = (WebGeneratorMM.Enlace) it.next();
			int visualID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> getEncuestaEncuestaPreguntasCompartment_7007SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		WebGeneratorMM.Encuesta modelElement = (WebGeneratorMM.Encuesta) containerView.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor>();
		for (Iterator<?> it = modelElement.getPreguntas().iterator(); it.hasNext();) {
			WebGeneratorMM.Pregunta childElement = (WebGeneratorMM.Pregunta) it.next();
			int visualID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == WebGeneratorMM.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == WebGeneratorMM.diagram.edit.parts.PreguntaElegirEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == WebGeneratorMM.diagram.edit.parts.PreguntaVFEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> getPreguntaElegirPreguntaElegirOpcionesCompartment_7021SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		WebGeneratorMM.PreguntaElegir modelElement = (WebGeneratorMM.PreguntaElegir) containerView.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor>();
		for (Iterator<?> it = modelElement.getOpciones().iterator(); it.hasNext();) {
			WebGeneratorMM.Opcion childElement = (WebGeneratorMM.Opcion) it.next();
			int visualID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == WebGeneratorMM.diagram.edit.parts.OpcionEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> getCuestionarioCuestionarioConexionredsocialCompartment_7008SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		WebGeneratorMM.Cuestionario modelElement = (WebGeneratorMM.Cuestionario) containerView.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor>();
		for (Iterator<?> it = modelElement.getConexionredsocial().iterator(); it.hasNext();) {
			WebGeneratorMM.ConexionRedSocial childElement = (WebGeneratorMM.ConexionRedSocial) it.next();
			int visualID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> getCuestionarioCuestionarioEnlacesCompartment_7009SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		WebGeneratorMM.Cuestionario modelElement = (WebGeneratorMM.Cuestionario) containerView.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor>();
		for (Iterator<?> it = modelElement.getEnlaces().iterator(); it.hasNext();) {
			WebGeneratorMM.Enlace childElement = (WebGeneratorMM.Enlace) it.next();
			int visualID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> getCuestionarioCuestionarioPreguntasCompartment_7010SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		WebGeneratorMM.Cuestionario modelElement = (WebGeneratorMM.Cuestionario) containerView.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor>();
		for (Iterator<?> it = modelElement.getPreguntas().iterator(); it.hasNext();) {
			WebGeneratorMM.Pregunta childElement = (WebGeneratorMM.Pregunta) it.next();
			int visualID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == WebGeneratorMM.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == WebGeneratorMM.diagram.edit.parts.PreguntaElegirEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == WebGeneratorMM.diagram.edit.parts.PreguntaVFEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> getDetalleDetalleConexionredsocialCompartment_7011SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		WebGeneratorMM.Detalle modelElement = (WebGeneratorMM.Detalle) containerView.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor>();
		for (Iterator<?> it = modelElement.getConexionredsocial().iterator(); it.hasNext();) {
			WebGeneratorMM.ConexionRedSocial childElement = (WebGeneratorMM.ConexionRedSocial) it.next();
			int visualID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> getDetalleDetalleEnlacesCompartment_7012SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		WebGeneratorMM.Detalle modelElement = (WebGeneratorMM.Detalle) containerView.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor>();
		for (Iterator<?> it = modelElement.getEnlaces().iterator(); it.hasNext();) {
			WebGeneratorMM.Enlace childElement = (WebGeneratorMM.Enlace) it.next();
			int visualID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> getBorradoBorradoConexionredsocialCompartment_7013SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		WebGeneratorMM.Borrado modelElement = (WebGeneratorMM.Borrado) containerView.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor>();
		for (Iterator<?> it = modelElement.getConexionredsocial().iterator(); it.hasNext();) {
			WebGeneratorMM.ConexionRedSocial childElement = (WebGeneratorMM.ConexionRedSocial) it.next();
			int visualID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> getBorradoBorradoEnlacesCompartment_7014SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		WebGeneratorMM.Borrado modelElement = (WebGeneratorMM.Borrado) containerView.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor>();
		for (Iterator<?> it = modelElement.getEnlaces().iterator(); it.hasNext();) {
			WebGeneratorMM.Enlace childElement = (WebGeneratorMM.Enlace) it.next();
			int visualID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> getCreacionCreacionConexionredsocialCompartment_7015SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		WebGeneratorMM.Creacion modelElement = (WebGeneratorMM.Creacion) containerView.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor>();
		for (Iterator<?> it = modelElement.getConexionredsocial().iterator(); it.hasNext();) {
			WebGeneratorMM.ConexionRedSocial childElement = (WebGeneratorMM.ConexionRedSocial) it.next();
			int visualID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> getCreacionCreacionEnlacesCompartment_7016SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		WebGeneratorMM.Creacion modelElement = (WebGeneratorMM.Creacion) containerView.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor>();
		for (Iterator<?> it = modelElement.getEnlaces().iterator(); it.hasNext();) {
			WebGeneratorMM.Enlace childElement = (WebGeneratorMM.Enlace) it.next();
			int visualID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> getPaginaHomePaginaHomeConexionredsocialCompartment_7017SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		WebGeneratorMM.PaginaHome modelElement = (WebGeneratorMM.PaginaHome) containerView.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor>();
		for (Iterator<?> it = modelElement.getConexionredsocial().iterator(); it.hasNext();) {
			WebGeneratorMM.ConexionRedSocial childElement = (WebGeneratorMM.ConexionRedSocial) it.next();
			int visualID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> getPaginaHomePaginaHomeEnlacesCompartment_7018SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		WebGeneratorMM.PaginaHome modelElement = (WebGeneratorMM.PaginaHome) containerView.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor>();
		for (Iterator<?> it = modelElement.getEnlaces().iterator(); it.hasNext();) {
			WebGeneratorMM.Enlace childElement = (WebGeneratorMM.Enlace) it.next();
			int visualID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> getEntidadEntidadReferenciasCompartment_7019SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		WebGeneratorMM.Entidad modelElement = (WebGeneratorMM.Entidad) containerView.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor>();
		for (Iterator<?> it = modelElement.getReferencias().iterator(); it.hasNext();) {
			WebGeneratorMM.Referencia childElement = (WebGeneratorMM.Referencia) it.next();
			int visualID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == WebGeneratorMM.diagram.edit.parts.ReferenciaEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> getEntidadEntidadAtributosCompartment_7020SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		WebGeneratorMM.Entidad modelElement = (WebGeneratorMM.Entidad) containerView.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor>();
		for (Iterator<?> it = modelElement.getAtributos().iterator(); it.hasNext();) {
			WebGeneratorMM.Atributo childElement = (WebGeneratorMM.Atributo) it.next();
			int visualID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == WebGeneratorMM.diagram.edit.parts.AtributoEditPart.VISUAL_ID) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getContainedLinks(View view) {
		switch (WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getVisualID(view)) {
		case WebGeneratorMM.diagram.edit.parts.SitioWebEditPart.VISUAL_ID:
			return getSitioWeb_1000ContainedLinks(view);
		case WebGeneratorMM.diagram.edit.parts.IndiceEditPart.VISUAL_ID:
			return getIndice_2001ContainedLinks(view);
		case WebGeneratorMM.diagram.edit.parts.PaginaCRUDEditPart.VISUAL_ID:
			return getPaginaCRUD_2002ContainedLinks(view);
		case WebGeneratorMM.diagram.edit.parts.EncuestaEditPart.VISUAL_ID:
			return getEncuesta_2003ContainedLinks(view);
		case WebGeneratorMM.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID:
			return getCuestionario_2004ContainedLinks(view);
		case WebGeneratorMM.diagram.edit.parts.DetalleEditPart.VISUAL_ID:
			return getDetalle_2005ContainedLinks(view);
		case WebGeneratorMM.diagram.edit.parts.BorradoEditPart.VISUAL_ID:
			return getBorrado_2006ContainedLinks(view);
		case WebGeneratorMM.diagram.edit.parts.CreacionEditPart.VISUAL_ID:
			return getCreacion_2007ContainedLinks(view);
		case WebGeneratorMM.diagram.edit.parts.PaginaHomeEditPart.VISUAL_ID:
			return getPaginaHome_2008ContainedLinks(view);
		case WebGeneratorMM.diagram.edit.parts.EntidadEditPart.VISUAL_ID:
			return getEntidad_2009ContainedLinks(view);
		case WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID:
			return getEnlaceExterno_3001ContainedLinks(view);
		case WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID:
			return getEnlaceInterno_3002ContainedLinks(view);
		case WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID:
			return getConexionRedSocial_3003ContainedLinks(view);
		case WebGeneratorMM.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID:
			return getPreguntaCorta_3004ContainedLinks(view);
		case WebGeneratorMM.diagram.edit.parts.PreguntaElegirEditPart.VISUAL_ID:
			return getPreguntaElegir_3007ContainedLinks(view);
		case WebGeneratorMM.diagram.edit.parts.OpcionEditPart.VISUAL_ID:
			return getOpcion_3008ContainedLinks(view);
		case WebGeneratorMM.diagram.edit.parts.PreguntaVFEditPart.VISUAL_ID:
			return getPreguntaVF_3009ContainedLinks(view);
		case WebGeneratorMM.diagram.edit.parts.ReferenciaEditPart.VISUAL_ID:
			return getReferencia_3005ContainedLinks(view);
		case WebGeneratorMM.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
			return getAtributo_3006ContainedLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getIncomingLinks(View view) {
		switch (WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getVisualID(view)) {
		case WebGeneratorMM.diagram.edit.parts.IndiceEditPart.VISUAL_ID:
			return getIndice_2001IncomingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.PaginaCRUDEditPart.VISUAL_ID:
			return getPaginaCRUD_2002IncomingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.EncuestaEditPart.VISUAL_ID:
			return getEncuesta_2003IncomingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID:
			return getCuestionario_2004IncomingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.DetalleEditPart.VISUAL_ID:
			return getDetalle_2005IncomingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.BorradoEditPart.VISUAL_ID:
			return getBorrado_2006IncomingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.CreacionEditPart.VISUAL_ID:
			return getCreacion_2007IncomingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.PaginaHomeEditPart.VISUAL_ID:
			return getPaginaHome_2008IncomingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.EntidadEditPart.VISUAL_ID:
			return getEntidad_2009IncomingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID:
			return getEnlaceExterno_3001IncomingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID:
			return getEnlaceInterno_3002IncomingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID:
			return getConexionRedSocial_3003IncomingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID:
			return getPreguntaCorta_3004IncomingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.PreguntaElegirEditPart.VISUAL_ID:
			return getPreguntaElegir_3007IncomingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.OpcionEditPart.VISUAL_ID:
			return getOpcion_3008IncomingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.PreguntaVFEditPart.VISUAL_ID:
			return getPreguntaVF_3009IncomingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.ReferenciaEditPart.VISUAL_ID:
			return getReferencia_3005IncomingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
			return getAtributo_3006IncomingLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getOutgoingLinks(View view) {
		switch (WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getVisualID(view)) {
		case WebGeneratorMM.diagram.edit.parts.IndiceEditPart.VISUAL_ID:
			return getIndice_2001OutgoingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.PaginaCRUDEditPart.VISUAL_ID:
			return getPaginaCRUD_2002OutgoingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.EncuestaEditPart.VISUAL_ID:
			return getEncuesta_2003OutgoingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID:
			return getCuestionario_2004OutgoingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.DetalleEditPart.VISUAL_ID:
			return getDetalle_2005OutgoingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.BorradoEditPart.VISUAL_ID:
			return getBorrado_2006OutgoingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.CreacionEditPart.VISUAL_ID:
			return getCreacion_2007OutgoingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.PaginaHomeEditPart.VISUAL_ID:
			return getPaginaHome_2008OutgoingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.EntidadEditPart.VISUAL_ID:
			return getEntidad_2009OutgoingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID:
			return getEnlaceExterno_3001OutgoingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID:
			return getEnlaceInterno_3002OutgoingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID:
			return getConexionRedSocial_3003OutgoingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID:
			return getPreguntaCorta_3004OutgoingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.PreguntaElegirEditPart.VISUAL_ID:
			return getPreguntaElegir_3007OutgoingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.OpcionEditPart.VISUAL_ID:
			return getOpcion_3008OutgoingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.PreguntaVFEditPart.VISUAL_ID:
			return getPreguntaVF_3009OutgoingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.ReferenciaEditPart.VISUAL_ID:
			return getReferencia_3005OutgoingLinks(view);
		case WebGeneratorMM.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
			return getAtributo_3006OutgoingLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getSitioWeb_1000ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getIndice_2001ContainedLinks(
			View view) {
		WebGeneratorMM.Indice modelElement = (WebGeneratorMM.Indice) view.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_PaginaEntidad_Entidad_4003(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getPaginaCRUD_2002ContainedLinks(
			View view) {
		WebGeneratorMM.PaginaCRUD modelElement = (WebGeneratorMM.PaginaCRUD) view.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_PaginaEntidad_Entidad_4003(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getEncuesta_2003ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getCuestionario_2004ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getDetalle_2005ContainedLinks(
			View view) {
		WebGeneratorMM.Detalle modelElement = (WebGeneratorMM.Detalle) view.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_PaginaEntidad_Entidad_4003(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getBorrado_2006ContainedLinks(
			View view) {
		WebGeneratorMM.Borrado modelElement = (WebGeneratorMM.Borrado) view.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_PaginaEntidad_Entidad_4003(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getCreacion_2007ContainedLinks(
			View view) {
		WebGeneratorMM.Creacion modelElement = (WebGeneratorMM.Creacion) view.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_PaginaEntidad_Entidad_4003(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getPaginaHome_2008ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getEntidad_2009ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getEnlaceExterno_3001ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getEnlaceInterno_3002ContainedLinks(
			View view) {
		WebGeneratorMM.EnlaceInterno modelElement = (WebGeneratorMM.EnlaceInterno) view.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_EnlaceInterno_Referencia_4002(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getConexionRedSocial_3003ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getPreguntaCorta_3004ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getPreguntaElegir_3007ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getOpcion_3008ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getPreguntaVF_3009ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getReferencia_3005ContainedLinks(
			View view) {
		WebGeneratorMM.Referencia modelElement = (WebGeneratorMM.Referencia) view.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Referencia_Destino_4001(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getAtributo_3006ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getIndice_2001IncomingLinks(
			View view) {
		WebGeneratorMM.Indice modelElement = (WebGeneratorMM.Indice) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_EnlaceInterno_Referencia_4002(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getPaginaCRUD_2002IncomingLinks(
			View view) {
		WebGeneratorMM.PaginaCRUD modelElement = (WebGeneratorMM.PaginaCRUD) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_EnlaceInterno_Referencia_4002(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getEncuesta_2003IncomingLinks(
			View view) {
		WebGeneratorMM.Encuesta modelElement = (WebGeneratorMM.Encuesta) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_EnlaceInterno_Referencia_4002(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getCuestionario_2004IncomingLinks(
			View view) {
		WebGeneratorMM.Cuestionario modelElement = (WebGeneratorMM.Cuestionario) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_EnlaceInterno_Referencia_4002(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getDetalle_2005IncomingLinks(
			View view) {
		WebGeneratorMM.Detalle modelElement = (WebGeneratorMM.Detalle) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_EnlaceInterno_Referencia_4002(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getBorrado_2006IncomingLinks(
			View view) {
		WebGeneratorMM.Borrado modelElement = (WebGeneratorMM.Borrado) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_EnlaceInterno_Referencia_4002(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getCreacion_2007IncomingLinks(
			View view) {
		WebGeneratorMM.Creacion modelElement = (WebGeneratorMM.Creacion) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_EnlaceInterno_Referencia_4002(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getPaginaHome_2008IncomingLinks(
			View view) {
		WebGeneratorMM.PaginaHome modelElement = (WebGeneratorMM.PaginaHome) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_EnlaceInterno_Referencia_4002(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getEntidad_2009IncomingLinks(
			View view) {
		WebGeneratorMM.Entidad modelElement = (WebGeneratorMM.Entidad) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_Referencia_Destino_4001(modelElement, crossReferences));
		result.addAll(getIncomingFeatureModelFacetLinks_PaginaEntidad_Entidad_4003(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getEnlaceExterno_3001IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getEnlaceInterno_3002IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getConexionRedSocial_3003IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getPreguntaCorta_3004IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getPreguntaElegir_3007IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getOpcion_3008IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getPreguntaVF_3009IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getReferencia_3005IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getAtributo_3006IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getIndice_2001OutgoingLinks(
			View view) {
		WebGeneratorMM.Indice modelElement = (WebGeneratorMM.Indice) view.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_PaginaEntidad_Entidad_4003(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getPaginaCRUD_2002OutgoingLinks(
			View view) {
		WebGeneratorMM.PaginaCRUD modelElement = (WebGeneratorMM.PaginaCRUD) view.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_PaginaEntidad_Entidad_4003(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getEncuesta_2003OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getCuestionario_2004OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getDetalle_2005OutgoingLinks(
			View view) {
		WebGeneratorMM.Detalle modelElement = (WebGeneratorMM.Detalle) view.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_PaginaEntidad_Entidad_4003(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getBorrado_2006OutgoingLinks(
			View view) {
		WebGeneratorMM.Borrado modelElement = (WebGeneratorMM.Borrado) view.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_PaginaEntidad_Entidad_4003(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getCreacion_2007OutgoingLinks(
			View view) {
		WebGeneratorMM.Creacion modelElement = (WebGeneratorMM.Creacion) view.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_PaginaEntidad_Entidad_4003(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getPaginaHome_2008OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getEntidad_2009OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getEnlaceExterno_3001OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getEnlaceInterno_3002OutgoingLinks(
			View view) {
		WebGeneratorMM.EnlaceInterno modelElement = (WebGeneratorMM.EnlaceInterno) view.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_EnlaceInterno_Referencia_4002(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getConexionRedSocial_3003OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getPreguntaCorta_3004OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getPreguntaElegir_3007OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getOpcion_3008OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getPreguntaVF_3009OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getReferencia_3005OutgoingLinks(
			View view) {
		WebGeneratorMM.Referencia modelElement = (WebGeneratorMM.Referencia) view.getElement();
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Referencia_Destino_4001(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getAtributo_3006OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	private static Collection<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getIncomingFeatureModelFacetLinks_Referencia_Destino_4001(
			WebGeneratorMM.Entidad target, Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE
					.getReferencia_Destino()) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor(setting.getEObject(), target,
						WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.ReferenciaDestino_4001,
						WebGeneratorMM.diagram.edit.parts.ReferenciaDestinoEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getIncomingFeatureModelFacetLinks_EnlaceInterno_Referencia_4002(
			WebGeneratorMM.PaginaWeb target, Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE
					.getEnlaceInterno_Referencia()) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor(setting.getEObject(), target,
						WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceInternoReferencia_4002,
						WebGeneratorMM.diagram.edit.parts.EnlaceInternoReferenciaEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getIncomingFeatureModelFacetLinks_PaginaEntidad_Entidad_4003(
			WebGeneratorMM.Entidad target, Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE
					.getPaginaEntidad_Entidad()) {
				result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor(setting.getEObject(), target,
						WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PaginaEntidadEntidad_4003,
						WebGeneratorMM.diagram.edit.parts.PaginaEntidadEntidadEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	private static Collection<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getOutgoingFeatureModelFacetLinks_Referencia_Destino_4001(
			WebGeneratorMM.Referencia source) {
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		WebGeneratorMM.Entidad destination = source.getDestino();
		if (destination == null) {
			return result;
		}
		result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor(source, destination,
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.ReferenciaDestino_4001,
				WebGeneratorMM.diagram.edit.parts.ReferenciaDestinoEditPart.VISUAL_ID));
		return result;
	}

	/**
	* @generated
	*/
	private static Collection<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getOutgoingFeatureModelFacetLinks_EnlaceInterno_Referencia_4002(
			WebGeneratorMM.EnlaceInterno source) {
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		WebGeneratorMM.PaginaWeb destination = source.getReferencia();
		if (destination == null) {
			return result;
		}
		result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor(source, destination,
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceInternoReferencia_4002,
				WebGeneratorMM.diagram.edit.parts.EnlaceInternoReferenciaEditPart.VISUAL_ID));
		return result;
	}

	/**
	* @generated
	*/
	private static Collection<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getOutgoingFeatureModelFacetLinks_PaginaEntidad_Entidad_4003(
			WebGeneratorMM.PaginaEntidad source) {
		LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> result = new LinkedList<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor>();
		WebGeneratorMM.Entidad destination = source.getEntidad();
		if (destination == null) {
			return result;
		}
		result.add(new WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor(source, destination,
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PaginaEntidadEntidad_4003,
				WebGeneratorMM.diagram.edit.parts.PaginaEntidadEntidadEditPart.VISUAL_ID));
		return result;
	}

	/**
	* @generated
	*/
	public static final DiagramUpdater TYPED_INSTANCE = new DiagramUpdater() {
		/**
		* @generated
		*/
		@Override

		public List<WebGeneratorMM.diagram.part.WebGeneratorMMNodeDescriptor> getSemanticChildren(View view) {
			return WebGeneratorMMDiagramUpdater.getSemanticChildren(view);
		}

		/**
		* @generated
		*/
		@Override

		public List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getContainedLinks(View view) {
			return WebGeneratorMMDiagramUpdater.getContainedLinks(view);
		}

		/**
		* @generated
		*/
		@Override

		public List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getIncomingLinks(View view) {
			return WebGeneratorMMDiagramUpdater.getIncomingLinks(view);
		}

		/**
		* @generated
		*/
		@Override

		public List<WebGeneratorMM.diagram.part.WebGeneratorMMLinkDescriptor> getOutgoingLinks(View view) {
			return WebGeneratorMMDiagramUpdater.getOutgoingLinks(view);
		}
	};

}
