/*
 * 
 */
package WebGeneratorMM.diagram.part;

import org.eclipse.osgi.util.NLS;

/**
 * @generated
 */
public class Messages extends NLS {

	/**
	* @generated
	*/
	static {
		NLS.initializeMessages("messages", Messages.class); //$NON-NLS-1$
	}

	/**
	* @generated
	*/
	private Messages() {
	}

	/**
	* @generated
	*/
	public static String WebGeneratorMMCreationWizardTitle;

	/**
	* @generated
	*/
	public static String WebGeneratorMMCreationWizard_DiagramModelFilePageTitle;

	/**
	* @generated
	*/
	public static String WebGeneratorMMCreationWizard_DiagramModelFilePageDescription;

	/**
	* @generated
	*/
	public static String WebGeneratorMMCreationWizard_DomainModelFilePageTitle;

	/**
	* @generated
	*/
	public static String WebGeneratorMMCreationWizard_DomainModelFilePageDescription;

	/**
	* @generated
	*/
	public static String WebGeneratorMMCreationWizardOpenEditorError;

	/**
	* @generated
	*/
	public static String WebGeneratorMMCreationWizardCreationError;

	/**
	* @generated
	*/
	public static String WebGeneratorMMCreationWizardPageExtensionError;

	/**
	* @generated
	*/
	public static String WebGeneratorMMDiagramEditorUtil_OpenModelResourceErrorDialogTitle;

	/**
	* @generated
	*/
	public static String WebGeneratorMMDiagramEditorUtil_OpenModelResourceErrorDialogMessage;

	/**
	* @generated
	*/
	public static String WebGeneratorMMDiagramEditorUtil_CreateDiagramProgressTask;

	/**
	* @generated
	*/
	public static String WebGeneratorMMDiagramEditorUtil_CreateDiagramCommandLabel;

	/**
	* @generated
	*/
	public static String WebGeneratorMMDocumentProvider_isModifiable;

	/**
	* @generated
	*/
	public static String WebGeneratorMMDocumentProvider_handleElementContentChanged;

	/**
	* @generated
	*/
	public static String WebGeneratorMMDocumentProvider_IncorrectInputError;

	/**
	* @generated
	*/
	public static String WebGeneratorMMDocumentProvider_NoDiagramInResourceError;

	/**
	* @generated
	*/
	public static String WebGeneratorMMDocumentProvider_DiagramLoadingError;

	/**
	* @generated
	*/
	public static String WebGeneratorMMDocumentProvider_UnsynchronizedFileSaveError;

	/**
	* @generated
	*/
	public static String WebGeneratorMMDocumentProvider_SaveDiagramTask;

	/**
	* @generated
	*/
	public static String WebGeneratorMMDocumentProvider_SaveNextResourceTask;

	/**
	* @generated
	*/
	public static String WebGeneratorMMDocumentProvider_SaveAsOperation;

	/**
	* @generated
	*/
	public static String InitDiagramFile_ResourceErrorDialogTitle;

	/**
	* @generated
	*/
	public static String InitDiagramFile_ResourceErrorDialogMessage;

	/**
	* @generated
	*/
	public static String InitDiagramFile_WizardTitle;

	/**
	* @generated
	*/
	public static String InitDiagramFile_OpenModelFileDialogTitle;

	/**
	* @generated
	*/
	public static String WebGeneratorMMNewDiagramFileWizard_CreationPageName;

	/**
	* @generated
	*/
	public static String WebGeneratorMMNewDiagramFileWizard_CreationPageTitle;

	/**
	* @generated
	*/
	public static String WebGeneratorMMNewDiagramFileWizard_CreationPageDescription;

	/**
	* @generated
	*/
	public static String WebGeneratorMMNewDiagramFileWizard_RootSelectionPageName;

	/**
	* @generated
	*/
	public static String WebGeneratorMMNewDiagramFileWizard_RootSelectionPageTitle;

	/**
	* @generated
	*/
	public static String WebGeneratorMMNewDiagramFileWizard_RootSelectionPageDescription;

	/**
	* @generated
	*/
	public static String WebGeneratorMMNewDiagramFileWizard_RootSelectionPageSelectionTitle;

	/**
	* @generated
	*/
	public static String WebGeneratorMMNewDiagramFileWizard_RootSelectionPageNoSelectionMessage;

	/**
	* @generated
	*/
	public static String WebGeneratorMMNewDiagramFileWizard_RootSelectionPageInvalidSelectionMessage;

	/**
	* @generated
	*/
	public static String WebGeneratorMMNewDiagramFileWizard_InitDiagramCommand;

	/**
	* @generated
	*/
	public static String WebGeneratorMMNewDiagramFileWizard_IncorrectRootError;

	/**
	* @generated
	*/
	public static String WebGeneratorMMDiagramEditor_SavingDeletedFile;

	/**
	* @generated
	*/
	public static String WebGeneratorMMDiagramEditor_SaveAsErrorTitle;

	/**
	* @generated
	*/
	public static String WebGeneratorMMDiagramEditor_SaveAsErrorMessage;

	/**
	* @generated
	*/
	public static String WebGeneratorMMDiagramEditor_SaveErrorTitle;

	/**
	* @generated
	*/
	public static String WebGeneratorMMDiagramEditor_SaveErrorMessage;

	/**
	* @generated
	*/
	public static String WebGeneratorMMElementChooserDialog_SelectModelElementTitle;

	/**
	* @generated
	*/
	public static String ModelElementSelectionPageMessage;

	/**
	* @generated
	*/
	public static String ValidateActionMessage;

	/**
	* @generated
	*/
	public static String Objects1Group_title;

	/**
	* @generated
	*/
	public static String Connections2Group_title;

	/**
	* @generated
	*/
	public static String Atributo1CreationTool_title;

	/**
	* @generated
	*/
	public static String Atributo1CreationTool_desc;

	/**
	* @generated
	*/
	public static String Borrado2CreationTool_title;

	/**
	* @generated
	*/
	public static String Borrado2CreationTool_desc;

	/**
	* @generated
	*/
	public static String ConexionRedSocial3CreationTool_title;

	/**
	* @generated
	*/
	public static String ConexionRedSocial3CreationTool_desc;

	/**
	* @generated
	*/
	public static String Creacion4CreationTool_title;

	/**
	* @generated
	*/
	public static String Creacion4CreationTool_desc;

	/**
	* @generated
	*/
	public static String Cuestionario5CreationTool_title;

	/**
	* @generated
	*/
	public static String Cuestionario5CreationTool_desc;

	/**
	* @generated
	*/
	public static String Detalle6CreationTool_title;

	/**
	* @generated
	*/
	public static String Detalle6CreationTool_desc;

	/**
	* @generated
	*/
	public static String Encuesta7CreationTool_title;

	/**
	* @generated
	*/
	public static String Encuesta7CreationTool_desc;

	/**
	* @generated
	*/
	public static String EnlaceExterno8CreationTool_title;

	/**
	* @generated
	*/
	public static String EnlaceExterno8CreationTool_desc;

	/**
	* @generated
	*/
	public static String EnlaceInterno9CreationTool_title;

	/**
	* @generated
	*/
	public static String EnlaceInterno9CreationTool_desc;

	/**
	* @generated
	*/
	public static String Entidad10CreationTool_title;

	/**
	* @generated
	*/
	public static String Entidad10CreationTool_desc;

	/**
	* @generated
	*/
	public static String Indice11CreationTool_title;

	/**
	* @generated
	*/
	public static String Indice11CreationTool_desc;

	/**
	* @generated
	*/
	public static String Opcion12CreationTool_title;

	/**
	* @generated
	*/
	public static String Opcion12CreationTool_desc;

	/**
	* @generated
	*/
	public static String PaginaCRUD13CreationTool_title;

	/**
	* @generated
	*/
	public static String PaginaCRUD13CreationTool_desc;

	/**
	* @generated
	*/
	public static String PaginaHome14CreationTool_title;

	/**
	* @generated
	*/
	public static String PaginaHome14CreationTool_desc;

	/**
	* @generated
	*/
	public static String PreguntaCorta15CreationTool_title;

	/**
	* @generated
	*/
	public static String PreguntaCorta15CreationTool_desc;

	/**
	* @generated
	*/
	public static String PreguntaElegir16CreationTool_title;

	/**
	* @generated
	*/
	public static String PreguntaElegir16CreationTool_desc;

	/**
	* @generated
	*/
	public static String PreguntaVF17CreationTool_title;

	/**
	* @generated
	*/
	public static String PreguntaVF17CreationTool_desc;

	/**
	* @generated
	*/
	public static String Referencia18CreationTool_title;

	/**
	* @generated
	*/
	public static String Referencia18CreationTool_desc;

	/**
	* @generated
	*/
	public static String Enlaceinternoapagina1CreationTool_title;

	/**
	* @generated
	*/
	public static String Enlaceinternoapagina1CreationTool_desc;

	/**
	* @generated
	*/
	public static String EntidadaEntidad2CreationTool_title;

	/**
	* @generated
	*/
	public static String EntidadaEntidad2CreationTool_desc;

	/**
	* @generated
	*/
	public static String PaginadeEntidad3CreationTool_title;

	/**
	* @generated
	*/
	public static String PaginadeEntidad3CreationTool_desc;

	/**
	* @generated
	*/
	public static String IndiceIndiceConexionredsocialCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String IndiceIndiceEnlacesCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String PaginaCRUDPaginaCRUDConexionredsocialCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String PaginaCRUDPaginaCRUDEnlacesCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String EncuestaEncuestaConexionredsocialCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String EncuestaEncuestaEnlacesCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String EncuestaEncuestaPreguntasCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String PreguntaElegirPreguntaElegirOpcionesCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String CuestionarioCuestionarioConexionredsocialCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String CuestionarioCuestionarioEnlacesCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String CuestionarioCuestionarioPreguntasCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String DetalleDetalleConexionredsocialCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String DetalleDetalleEnlacesCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String BorradoBorradoConexionredsocialCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String BorradoBorradoEnlacesCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String CreacionCreacionConexionredsocialCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String CreacionCreacionEnlacesCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String PaginaHomePaginaHomeConexionredsocialCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String PaginaHomePaginaHomeEnlacesCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String EntidadEntidadReferenciasCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String EntidadEntidadAtributosCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String CommandName_OpenDiagram;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_SitioWeb_1000_links;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Indice_2001_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Indice_2001_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_PaginaCRUD_2002_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_PaginaCRUD_2002_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Encuesta_2003_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Cuestionario_2004_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Detalle_2005_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Detalle_2005_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Borrado_2006_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Borrado_2006_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Creacion_2007_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Creacion_2007_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_PaginaHome_2008_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Entidad_2009_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_EnlaceInterno_3002_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Referencia_3005_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_ReferenciaDestino_4001_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_ReferenciaDestino_4001_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_EnlaceInternoReferencia_4002_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_EnlaceInternoReferencia_4002_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_PaginaEntidadEntidad_4003_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_PaginaEntidadEntidad_4003_source;

	/**
	* @generated
	*/
	public static String NavigatorActionProvider_OpenDiagramActionName;

	/**
	* @generated
	*/
	public static String MessageFormatParser_InvalidInputError;

	/**
	* @generated
	*/
	public static String WebGeneratorMMModelingAssistantProviderTitle;

	/**
	* @generated
	*/
	public static String WebGeneratorMMModelingAssistantProviderMessage;

	//TODO: put accessor fields manually	
}
