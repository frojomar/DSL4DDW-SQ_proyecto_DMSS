/*
* 
*/
package WebGeneratorMM.diagram.part;

import org.eclipse.core.runtime.Platform;
import org.eclipse.emf.ecore.EAnnotation;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.notation.Diagram;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.gmf.tooling.runtime.structure.DiagramStructure;

/**
 * This registry is used to determine which type of visual object should be
 * created for the corresponding Diagram, Node, ChildNode or Link represented
 * by a domain model object.
 * 
 * @generated
 */
public class WebGeneratorMMVisualIDRegistry {

	/**
	* @generated
	*/
	private static final String DEBUG_KEY = "dmss.dsl4ddwsq.diagram/debug/visualID"; //$NON-NLS-1$

	/**
	* @generated
	*/
	public static int getVisualID(View view) {
		if (view instanceof Diagram) {
			if (WebGeneratorMM.diagram.edit.parts.SitioWebEditPart.MODEL_ID.equals(view.getType())) {
				return WebGeneratorMM.diagram.edit.parts.SitioWebEditPart.VISUAL_ID;
			} else {
				return -1;
			}
		}
		return WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getVisualID(view.getType());
	}

	/**
	* @generated
	*/
	public static String getModelID(View view) {
		View diagram = view.getDiagram();
		while (view != diagram) {
			EAnnotation annotation = view.getEAnnotation("Shortcut"); //$NON-NLS-1$
			if (annotation != null) {
				return (String) annotation.getDetails().get("modelID"); //$NON-NLS-1$
			}
			view = (View) view.eContainer();
		}
		return diagram != null ? diagram.getType() : null;
	}

	/**
	* @generated
	*/
	public static int getVisualID(String type) {
		try {
			return Integer.parseInt(type);
		} catch (NumberFormatException e) {
			if (Boolean.TRUE.toString().equalsIgnoreCase(Platform.getDebugOption(DEBUG_KEY))) {
				WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
						.logError("Unable to parse view type as a visualID number: " + type);
			}
		}
		return -1;
	}

	/**
	* @generated
	*/
	public static String getType(int visualID) {
		return Integer.toString(visualID);
	}

	/**
	* @generated
	*/
	public static int getDiagramVisualID(EObject domainElement) {
		if (domainElement == null) {
			return -1;
		}
		if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getSitioWeb().isSuperTypeOf(domainElement.eClass())
				&& isDiagram((WebGeneratorMM.SitioWeb) domainElement)) {
			return WebGeneratorMM.diagram.edit.parts.SitioWebEditPart.VISUAL_ID;
		}
		return -1;
	}

	/**
	* @generated
	*/
	public static int getNodeVisualID(View containerView, EObject domainElement) {
		if (domainElement == null) {
			return -1;
		}
		String containerModelID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getModelID(containerView);
		if (!WebGeneratorMM.diagram.edit.parts.SitioWebEditPart.MODEL_ID.equals(containerModelID)
				&& !"WebGeneratorMM".equals(containerModelID)) { //$NON-NLS-1$
			return -1;
		}
		int containerVisualID;
		if (WebGeneratorMM.diagram.edit.parts.SitioWebEditPart.MODEL_ID.equals(containerModelID)) {
			containerVisualID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getVisualID(containerView);
		} else {
			if (containerView instanceof Diagram) {
				containerVisualID = WebGeneratorMM.diagram.edit.parts.SitioWebEditPart.VISUAL_ID;
			} else {
				return -1;
			}
		}
		switch (containerVisualID) {
		case WebGeneratorMM.diagram.edit.parts.SitioWebEditPart.VISUAL_ID:
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getIndice().isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.IndiceEditPart.VISUAL_ID;
			}
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getPaginaCRUD().isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.PaginaCRUDEditPart.VISUAL_ID;
			}
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getEncuesta().isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.EncuestaEditPart.VISUAL_ID;
			}
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getCuestionario()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID;
			}
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getDetalle().isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.DetalleEditPart.VISUAL_ID;
			}
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getBorrado().isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.BorradoEditPart.VISUAL_ID;
			}
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getCreacion().isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.CreacionEditPart.VISUAL_ID;
			}
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getPaginaHome().isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.PaginaHomeEditPart.VISUAL_ID;
			}
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getEntidad().isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.EntidadEditPart.VISUAL_ID;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.IndiceIndiceConexionredsocialCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getConexionRedSocial()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.IndiceIndiceEnlacesCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getEnlaceExterno()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID;
			}
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getEnlaceInterno()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.PaginaCRUDPaginaCRUDConexionredsocialCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getConexionRedSocial()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.PaginaCRUDPaginaCRUDEnlacesCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getEnlaceExterno()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID;
			}
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getEnlaceInterno()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.EncuestaEncuestaConexionredsocialCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getConexionRedSocial()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.EncuestaEncuestaEnlacesCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getEnlaceExterno()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID;
			}
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getEnlaceInterno()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.EncuestaEncuestaPreguntasCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getPreguntaCorta()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID;
			}
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getPreguntaElegir()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.PreguntaElegirEditPart.VISUAL_ID;
			}
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getPreguntaVF().isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.PreguntaVFEditPart.VISUAL_ID;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.PreguntaElegirPreguntaElegirOpcionesCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getOpcion().isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.OpcionEditPart.VISUAL_ID;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.CuestionarioCuestionarioConexionredsocialCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getConexionRedSocial()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.CuestionarioCuestionarioEnlacesCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getEnlaceExterno()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID;
			}
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getEnlaceInterno()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.CuestionarioCuestionarioPreguntasCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getPreguntaCorta()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID;
			}
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getPreguntaElegir()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.PreguntaElegirEditPart.VISUAL_ID;
			}
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getPreguntaVF().isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.PreguntaVFEditPart.VISUAL_ID;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.DetalleDetalleConexionredsocialCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getConexionRedSocial()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.DetalleDetalleEnlacesCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getEnlaceExterno()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID;
			}
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getEnlaceInterno()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.BorradoBorradoConexionredsocialCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getConexionRedSocial()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.BorradoBorradoEnlacesCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getEnlaceExterno()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID;
			}
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getEnlaceInterno()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.CreacionCreacionConexionredsocialCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getConexionRedSocial()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.CreacionCreacionEnlacesCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getEnlaceExterno()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID;
			}
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getEnlaceInterno()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.PaginaHomePaginaHomeConexionredsocialCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getConexionRedSocial()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.PaginaHomePaginaHomeEnlacesCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getEnlaceExterno()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID;
			}
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getEnlaceInterno()
					.isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.EntidadEntidadReferenciasCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getReferencia().isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.ReferenciaEditPart.VISUAL_ID;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.EntidadEntidadAtributosCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.WebGeneratorMMPackage.eINSTANCE.getAtributo().isSuperTypeOf(domainElement.eClass())) {
				return WebGeneratorMM.diagram.edit.parts.AtributoEditPart.VISUAL_ID;
			}
			break;
		}
		return -1;
	}

	/**
	* @generated
	*/
	public static boolean canCreateNode(View containerView, int nodeVisualID) {
		String containerModelID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getModelID(containerView);
		if (!WebGeneratorMM.diagram.edit.parts.SitioWebEditPart.MODEL_ID.equals(containerModelID)
				&& !"WebGeneratorMM".equals(containerModelID)) { //$NON-NLS-1$
			return false;
		}
		int containerVisualID;
		if (WebGeneratorMM.diagram.edit.parts.SitioWebEditPart.MODEL_ID.equals(containerModelID)) {
			containerVisualID = WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getVisualID(containerView);
		} else {
			if (containerView instanceof Diagram) {
				containerVisualID = WebGeneratorMM.diagram.edit.parts.SitioWebEditPart.VISUAL_ID;
			} else {
				return false;
			}
		}
		switch (containerVisualID) {
		case WebGeneratorMM.diagram.edit.parts.SitioWebEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.IndiceEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.PaginaCRUDEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.EncuestaEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.DetalleEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.BorradoEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.CreacionEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.PaginaHomeEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.EntidadEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.IndiceEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.IndiceNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.IndiceIndiceConexionredsocialCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.IndiceIndiceEnlacesCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.PaginaCRUDEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.PaginaCRUDNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.PaginaCRUDPaginaCRUDConexionredsocialCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.PaginaCRUDPaginaCRUDEnlacesCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.EncuestaEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.EncuestaNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.EncuestaEncuestaConexionredsocialCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.EncuestaEncuestaEnlacesCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.EncuestaEncuestaPreguntasCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.CuestionarioNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.CuestionarioCuestionarioConexionredsocialCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.CuestionarioCuestionarioEnlacesCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.CuestionarioCuestionarioPreguntasCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.DetalleEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.DetalleNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.DetalleDetalleConexionredsocialCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.DetalleDetalleEnlacesCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.BorradoEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.BorradoNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.BorradoBorradoConexionredsocialCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.BorradoBorradoEnlacesCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.CreacionEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.CreacionNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.CreacionCreacionConexionredsocialCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.CreacionCreacionEnlacesCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.PaginaHomeEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.PaginaHomeNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.PaginaHomePaginaHomeConexionredsocialCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.PaginaHomePaginaHomeEnlacesCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.EntidadEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.EntidadNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.EntidadEntidadReferenciasCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.EntidadEntidadAtributosCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.EnlaceExternoNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.EnlaceInternoNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.ConexionRedSocialTagEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.PreguntaCortaContentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.PreguntaElegirEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.PreguntaElegirContentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.PreguntaElegirPreguntaElegirOpcionesCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.OpcionEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.OpcionContentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.PreguntaVFEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.PreguntaVFContentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.ReferenciaEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.ReferenciaNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.AtributoNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.IndiceIndiceConexionredsocialCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.IndiceIndiceEnlacesCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.PaginaCRUDPaginaCRUDConexionredsocialCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.PaginaCRUDPaginaCRUDEnlacesCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.EncuestaEncuestaConexionredsocialCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.EncuestaEncuestaEnlacesCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.EncuestaEncuestaPreguntasCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.PreguntaElegirEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.PreguntaVFEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.PreguntaElegirPreguntaElegirOpcionesCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.OpcionEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.CuestionarioCuestionarioConexionredsocialCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.CuestionarioCuestionarioEnlacesCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.CuestionarioCuestionarioPreguntasCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.PreguntaElegirEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.PreguntaVFEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.DetalleDetalleConexionredsocialCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.DetalleDetalleEnlacesCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.BorradoBorradoConexionredsocialCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.BorradoBorradoEnlacesCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.CreacionCreacionConexionredsocialCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.CreacionCreacionEnlacesCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.PaginaHomePaginaHomeConexionredsocialCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.PaginaHomePaginaHomeEnlacesCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.EntidadEntidadReferenciasCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.ReferenciaEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.EntidadEntidadAtributosCompartmentEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.AtributoEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.ReferenciaDestinoEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.WrappingLabelEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.EnlaceInternoReferenciaEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.WrappingLabel2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case WebGeneratorMM.diagram.edit.parts.PaginaEntidadEntidadEditPart.VISUAL_ID:
			if (WebGeneratorMM.diagram.edit.parts.WrappingLabel3EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		}
		return false;
	}

	/**
	* @generated
	*/
	public static int getLinkWithClassVisualID(EObject domainElement) {
		if (domainElement == null) {
			return -1;
		}
		return -1;
	}

	/**
	* User can change implementation of this method to handle some specific
	* situations not covered by default logic.
	* 
	* @generated
	*/
	private static boolean isDiagram(WebGeneratorMM.SitioWeb element) {
		return true;
	}

	/**
	* @generated
	*/
	public static boolean checkNodeVisualID(View containerView, EObject domainElement, int candidate) {
		if (candidate == -1) {
			//unrecognized id is always bad
			return false;
		}
		int basic = getNodeVisualID(containerView, domainElement);
		return basic == candidate;
	}

	/**
	* @generated
	*/
	public static boolean isCompartmentVisualID(int visualID) {
		switch (visualID) {
		case WebGeneratorMM.diagram.edit.parts.IndiceIndiceConexionredsocialCompartmentEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.IndiceIndiceEnlacesCompartmentEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.PaginaCRUDPaginaCRUDConexionredsocialCompartmentEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.PaginaCRUDPaginaCRUDEnlacesCompartmentEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.EncuestaEncuestaConexionredsocialCompartmentEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.EncuestaEncuestaEnlacesCompartmentEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.EncuestaEncuestaPreguntasCompartmentEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.PreguntaElegirPreguntaElegirOpcionesCompartmentEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.CuestionarioCuestionarioConexionredsocialCompartmentEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.CuestionarioCuestionarioEnlacesCompartmentEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.CuestionarioCuestionarioPreguntasCompartmentEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.DetalleDetalleConexionredsocialCompartmentEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.DetalleDetalleEnlacesCompartmentEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.BorradoBorradoConexionredsocialCompartmentEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.BorradoBorradoEnlacesCompartmentEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.CreacionCreacionConexionredsocialCompartmentEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.CreacionCreacionEnlacesCompartmentEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.PaginaHomePaginaHomeConexionredsocialCompartmentEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.PaginaHomePaginaHomeEnlacesCompartmentEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.EntidadEntidadReferenciasCompartmentEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.EntidadEntidadAtributosCompartmentEditPart.VISUAL_ID:
			return true;
		default:
			break;
		}
		return false;
	}

	/**
	* @generated
	*/
	public static boolean isSemanticLeafVisualID(int visualID) {
		switch (visualID) {
		case WebGeneratorMM.diagram.edit.parts.SitioWebEditPart.VISUAL_ID:
			return false;
		case WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.ReferenciaEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.OpcionEditPart.VISUAL_ID:
		case WebGeneratorMM.diagram.edit.parts.PreguntaVFEditPart.VISUAL_ID:
			return true;
		default:
			break;
		}
		return false;
	}

	/**
	* @generated
	*/
	public static final DiagramStructure TYPED_INSTANCE = new DiagramStructure() {
		/**
		* @generated
		*/
		@Override

		public int getVisualID(View view) {
			return WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getVisualID(view);
		}

		/**
		* @generated
		*/
		@Override

		public String getModelID(View view) {
			return WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getModelID(view);
		}

		/**
		* @generated
		*/
		@Override

		public int getNodeVisualID(View containerView, EObject domainElement) {
			return WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getNodeVisualID(containerView,
					domainElement);
		}

		/**
		* @generated
		*/
		@Override

		public boolean checkNodeVisualID(View containerView, EObject domainElement, int candidate) {
			return WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.checkNodeVisualID(containerView,
					domainElement, candidate);
		}

		/**
		* @generated
		*/
		@Override

		public boolean isCompartmentVisualID(int visualID) {
			return WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.isCompartmentVisualID(visualID);
		}

		/**
		* @generated
		*/
		@Override

		public boolean isSemanticLeafVisualID(int visualID) {
			return WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.isSemanticLeafVisualID(visualID);
		}
	};

}
