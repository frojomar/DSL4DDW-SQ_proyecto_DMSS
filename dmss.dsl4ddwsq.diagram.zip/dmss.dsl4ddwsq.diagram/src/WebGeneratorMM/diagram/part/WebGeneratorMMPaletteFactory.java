
/*
 * 
 */
package WebGeneratorMM.diagram.part;

import java.util.Collections;

import org.eclipse.gef.palette.PaletteContainer;
import org.eclipse.gef.palette.PaletteDrawer;
import org.eclipse.gef.palette.PaletteRoot;
import org.eclipse.gef.palette.ToolEntry;
import org.eclipse.gmf.tooling.runtime.part.DefaultLinkToolEntry;
import org.eclipse.gmf.tooling.runtime.part.DefaultNodeToolEntry;

/**
 * @generated
 */
public class WebGeneratorMMPaletteFactory {

	/**
	* @generated
	*/
	public void fillPalette(PaletteRoot paletteRoot) {
		paletteRoot.add(createObjects1Group());
		paletteRoot.add(createConnections2Group());
	}

	/**
	* Creates "Objects" palette tool group
	* @generated
	*/
	private PaletteContainer createObjects1Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(WebGeneratorMM.diagram.part.Messages.Objects1Group_title);
		paletteContainer.setId("createObjects1Group"); //$NON-NLS-1$
		paletteContainer.add(createAtributo1CreationTool());
		paletteContainer.add(createBorrado2CreationTool());
		paletteContainer.add(createConexionRedSocial3CreationTool());
		paletteContainer.add(createCreacion4CreationTool());
		paletteContainer.add(createCuestionario5CreationTool());
		paletteContainer.add(createDetalle6CreationTool());
		paletteContainer.add(createEncuesta7CreationTool());
		paletteContainer.add(createEnlaceExterno8CreationTool());
		paletteContainer.add(createEnlaceInterno9CreationTool());
		paletteContainer.add(createEntidad10CreationTool());
		paletteContainer.add(createIndice11CreationTool());
		paletteContainer.add(createOpcion12CreationTool());
		paletteContainer.add(createPaginaCRUD13CreationTool());
		paletteContainer.add(createPaginaHome14CreationTool());
		paletteContainer.add(createPreguntaCorta15CreationTool());
		paletteContainer.add(createPreguntaElegir16CreationTool());
		paletteContainer.add(createPreguntaVF17CreationTool());
		paletteContainer.add(createReferencia18CreationTool());
		return paletteContainer;
	}

	/**
	* Creates "Connections" palette tool group
	* @generated
	*/
	private PaletteContainer createConnections2Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(
				WebGeneratorMM.diagram.part.Messages.Connections2Group_title);
		paletteContainer.setId("createConnections2Group"); //$NON-NLS-1$
		paletteContainer.add(createEnlaceinternoapagina1CreationTool());
		paletteContainer.add(createEntidadaEntidad2CreationTool());
		paletteContainer.add(createPaginadeEntidad3CreationTool());
		return paletteContainer;
	}

	/**
	* @generated
	*/
	private ToolEntry createAtributo1CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				WebGeneratorMM.diagram.part.Messages.Atributo1CreationTool_title,
				WebGeneratorMM.diagram.part.Messages.Atributo1CreationTool_desc,
				Collections.singletonList(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Atributo_3006));
		entry.setId("createAtributo1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes
				.getImageDescriptor(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Atributo_3006));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createBorrado2CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				WebGeneratorMM.diagram.part.Messages.Borrado2CreationTool_title,
				WebGeneratorMM.diagram.part.Messages.Borrado2CreationTool_desc,
				Collections.singletonList(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Borrado_2006));
		entry.setId("createBorrado2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes
				.getImageDescriptor(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Borrado_2006));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createConexionRedSocial3CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				WebGeneratorMM.diagram.part.Messages.ConexionRedSocial3CreationTool_title,
				WebGeneratorMM.diagram.part.Messages.ConexionRedSocial3CreationTool_desc, Collections.singletonList(
						WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.ConexionRedSocial_3003));
		entry.setId("createConexionRedSocial3CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.getImageDescriptor(
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.ConexionRedSocial_3003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createCreacion4CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				WebGeneratorMM.diagram.part.Messages.Creacion4CreationTool_title,
				WebGeneratorMM.diagram.part.Messages.Creacion4CreationTool_desc,
				Collections.singletonList(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Creacion_2007));
		entry.setId("createCreacion4CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes
				.getImageDescriptor(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Creacion_2007));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createCuestionario5CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				WebGeneratorMM.diagram.part.Messages.Cuestionario5CreationTool_title,
				WebGeneratorMM.diagram.part.Messages.Cuestionario5CreationTool_desc, Collections
						.singletonList(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Cuestionario_2004));
		entry.setId("createCuestionario5CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes
				.getImageDescriptor(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Cuestionario_2004));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createDetalle6CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				WebGeneratorMM.diagram.part.Messages.Detalle6CreationTool_title,
				WebGeneratorMM.diagram.part.Messages.Detalle6CreationTool_desc,
				Collections.singletonList(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Detalle_2005));
		entry.setId("createDetalle6CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes
				.getImageDescriptor(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Detalle_2005));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createEncuesta7CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				WebGeneratorMM.diagram.part.Messages.Encuesta7CreationTool_title,
				WebGeneratorMM.diagram.part.Messages.Encuesta7CreationTool_desc,
				Collections.singletonList(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Encuesta_2003));
		entry.setId("createEncuesta7CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes
				.getImageDescriptor(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Encuesta_2003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createEnlaceExterno8CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				WebGeneratorMM.diagram.part.Messages.EnlaceExterno8CreationTool_title,
				WebGeneratorMM.diagram.part.Messages.EnlaceExterno8CreationTool_desc, Collections
						.singletonList(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceExterno_3001));
		entry.setId("createEnlaceExterno8CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes
				.getImageDescriptor(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceExterno_3001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createEnlaceInterno9CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				WebGeneratorMM.diagram.part.Messages.EnlaceInterno9CreationTool_title,
				WebGeneratorMM.diagram.part.Messages.EnlaceInterno9CreationTool_desc, Collections
						.singletonList(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceInterno_3002));
		entry.setId("createEnlaceInterno9CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes
				.getImageDescriptor(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceInterno_3002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createEntidad10CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				WebGeneratorMM.diagram.part.Messages.Entidad10CreationTool_title,
				WebGeneratorMM.diagram.part.Messages.Entidad10CreationTool_desc,
				Collections.singletonList(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Entidad_2009));
		entry.setId("createEntidad10CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes
				.getImageDescriptor(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Entidad_2009));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createIndice11CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				WebGeneratorMM.diagram.part.Messages.Indice11CreationTool_title,
				WebGeneratorMM.diagram.part.Messages.Indice11CreationTool_desc,
				Collections.singletonList(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Indice_2001));
		entry.setId("createIndice11CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes
				.getImageDescriptor(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Indice_2001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createOpcion12CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				WebGeneratorMM.diagram.part.Messages.Opcion12CreationTool_title,
				WebGeneratorMM.diagram.part.Messages.Opcion12CreationTool_desc,
				Collections.singletonList(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Opcion_3008));
		entry.setId("createOpcion12CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes
				.getImageDescriptor(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Opcion_3008));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createPaginaCRUD13CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				WebGeneratorMM.diagram.part.Messages.PaginaCRUD13CreationTool_title,
				WebGeneratorMM.diagram.part.Messages.PaginaCRUD13CreationTool_desc,
				Collections.singletonList(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PaginaCRUD_2002));
		entry.setId("createPaginaCRUD13CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes
				.getImageDescriptor(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PaginaCRUD_2002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createPaginaHome14CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				WebGeneratorMM.diagram.part.Messages.PaginaHome14CreationTool_title,
				WebGeneratorMM.diagram.part.Messages.PaginaHome14CreationTool_desc,
				Collections.singletonList(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PaginaHome_2008));
		entry.setId("createPaginaHome14CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes
				.getImageDescriptor(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PaginaHome_2008));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createPreguntaCorta15CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				WebGeneratorMM.diagram.part.Messages.PreguntaCorta15CreationTool_title,
				WebGeneratorMM.diagram.part.Messages.PreguntaCorta15CreationTool_desc, Collections
						.singletonList(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PreguntaCorta_3004));
		entry.setId("createPreguntaCorta15CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes
				.getImageDescriptor(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PreguntaCorta_3004));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createPreguntaElegir16CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				WebGeneratorMM.diagram.part.Messages.PreguntaElegir16CreationTool_title,
				WebGeneratorMM.diagram.part.Messages.PreguntaElegir16CreationTool_desc, Collections.singletonList(
						WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PreguntaElegir_3007));
		entry.setId("createPreguntaElegir16CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes
				.getImageDescriptor(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PreguntaElegir_3007));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createPreguntaVF17CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				WebGeneratorMM.diagram.part.Messages.PreguntaVF17CreationTool_title,
				WebGeneratorMM.diagram.part.Messages.PreguntaVF17CreationTool_desc,
				Collections.singletonList(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PreguntaVF_3009));
		entry.setId("createPreguntaVF17CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes
				.getImageDescriptor(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PreguntaVF_3009));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createReferencia18CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				WebGeneratorMM.diagram.part.Messages.Referencia18CreationTool_title,
				WebGeneratorMM.diagram.part.Messages.Referencia18CreationTool_desc,
				Collections.singletonList(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Referencia_3005));
		entry.setId("createReferencia18CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes
				.getImageDescriptor(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Referencia_3005));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createEnlaceinternoapagina1CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(
				WebGeneratorMM.diagram.part.Messages.Enlaceinternoapagina1CreationTool_title,
				WebGeneratorMM.diagram.part.Messages.Enlaceinternoapagina1CreationTool_desc, Collections.singletonList(
						WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceInternoReferencia_4002));
		entry.setId("createEnlaceinternoapagina1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.getImageDescriptor(
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceInternoReferencia_4002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createEntidadaEntidad2CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(
				WebGeneratorMM.diagram.part.Messages.EntidadaEntidad2CreationTool_title,
				WebGeneratorMM.diagram.part.Messages.EntidadaEntidad2CreationTool_desc, Collections.singletonList(
						WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.ReferenciaDestino_4001));
		entry.setId("createEntidadaEntidad2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.getImageDescriptor(
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.ReferenciaDestino_4001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createPaginadeEntidad3CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(
				WebGeneratorMM.diagram.part.Messages.PaginadeEntidad3CreationTool_title,
				WebGeneratorMM.diagram.part.Messages.PaginadeEntidad3CreationTool_desc, Collections.singletonList(
						WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PaginaEntidadEntidad_4003));
		entry.setId("createPaginadeEntidad3CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.getImageDescriptor(
				WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PaginaEntidadEntidad_4003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

}
