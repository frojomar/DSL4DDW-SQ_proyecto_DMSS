/*
 * 
 */
package WebGeneratorMM.diagram.part;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.actions.WorkspaceModifyOperation;

/**
 * @generated
 */
public class WebGeneratorMMCreationWizard extends Wizard implements INewWizard {

	/**
	* @generated
	*/
	private IWorkbench workbench;

	/**
	* @generated
	*/
	protected IStructuredSelection selection;

	/**
	* @generated
	*/
	protected WebGeneratorMM.diagram.part.WebGeneratorMMCreationWizardPage diagramModelFilePage;

	/**
	* @generated
	*/
	protected WebGeneratorMM.diagram.part.WebGeneratorMMCreationWizardPage domainModelFilePage;

	/**
	* @generated
	*/
	protected Resource diagram;

	/**
	* @generated
	*/
	private boolean openNewlyCreatedDiagramEditor = true;

	/**
	* @generated
	*/
	public IWorkbench getWorkbench() {
		return workbench;
	}

	/**
	* @generated
	*/
	public IStructuredSelection getSelection() {
		return selection;
	}

	/**
	* @generated
	*/
	public final Resource getDiagram() {
		return diagram;
	}

	/**
	* @generated
	*/
	public final boolean isOpenNewlyCreatedDiagramEditor() {
		return openNewlyCreatedDiagramEditor;
	}

	/**
	* @generated
	*/
	public void setOpenNewlyCreatedDiagramEditor(boolean openNewlyCreatedDiagramEditor) {
		this.openNewlyCreatedDiagramEditor = openNewlyCreatedDiagramEditor;
	}

	/**
	* @generated
	*/
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		this.workbench = workbench;
		this.selection = selection;
		setWindowTitle(WebGeneratorMM.diagram.part.Messages.WebGeneratorMMCreationWizardTitle);
		setDefaultPageImageDescriptor(WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin
				.getBundledImageDescriptor("icons/wizban/NewWebGeneratorMMWizard.gif")); //$NON-NLS-1$
		setNeedsProgressMonitor(true);
	}

	/**
	* @generated
	*/
	public void addPages() {
		diagramModelFilePage = new WebGeneratorMM.diagram.part.WebGeneratorMMCreationWizardPage("DiagramModelFile", //$NON-NLS-1$
				getSelection(), "webgeneratormm_diagram"); //$NON-NLS-1$
		diagramModelFilePage
				.setTitle(WebGeneratorMM.diagram.part.Messages.WebGeneratorMMCreationWizard_DiagramModelFilePageTitle);
		diagramModelFilePage.setDescription(
				WebGeneratorMM.diagram.part.Messages.WebGeneratorMMCreationWizard_DiagramModelFilePageDescription);
		addPage(diagramModelFilePage);

		domainModelFilePage = new WebGeneratorMM.diagram.part.WebGeneratorMMCreationWizardPage("DomainModelFile", //$NON-NLS-1$
				getSelection(), "webgeneratormm") { //$NON-NLS-1$

			public void setVisible(boolean visible) {
				if (visible) {
					String fileName = diagramModelFilePage.getFileName();
					fileName = fileName.substring(0, fileName.length() - ".webgeneratormm_diagram".length()); //$NON-NLS-1$
					setFileName(WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorUtil
							.getUniqueFileName(getContainerFullPath(), fileName, "webgeneratormm")); //$NON-NLS-1$
				}
				super.setVisible(visible);
			}
		};
		domainModelFilePage
				.setTitle(WebGeneratorMM.diagram.part.Messages.WebGeneratorMMCreationWizard_DomainModelFilePageTitle);
		domainModelFilePage.setDescription(
				WebGeneratorMM.diagram.part.Messages.WebGeneratorMMCreationWizard_DomainModelFilePageDescription);
		addPage(domainModelFilePage);
	}

	/**
	* @generated
	*/
	public boolean performFinish() {
		IRunnableWithProgress op = new WorkspaceModifyOperation(null) {

			protected void execute(IProgressMonitor monitor) throws CoreException, InterruptedException {
				diagram = WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorUtil
						.createDiagram(diagramModelFilePage.getURI(), domainModelFilePage.getURI(), monitor);
				if (isOpenNewlyCreatedDiagramEditor() && diagram != null) {
					try {
						WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorUtil.openDiagram(diagram);
					} catch (PartInitException e) {
						ErrorDialog.openError(getContainer().getShell(),
								WebGeneratorMM.diagram.part.Messages.WebGeneratorMMCreationWizardOpenEditorError, null,
								e.getStatus());
					}
				}
			}
		};
		try {
			getContainer().run(false, true, op);
		} catch (InterruptedException e) {
			return false;
		} catch (InvocationTargetException e) {
			if (e.getTargetException() instanceof CoreException) {
				ErrorDialog.openError(getContainer().getShell(),
						WebGeneratorMM.diagram.part.Messages.WebGeneratorMMCreationWizardCreationError, null,
						((CoreException) e.getTargetException()).getStatus());
			} else {
				WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance()
						.logError("Error creating diagram", e.getTargetException()); //$NON-NLS-1$
			}
			return false;
		}
		return diagram != null;
	}
}
