/*
 * 
 */
package WebGeneratorMM.diagram.edit.parts;

import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPartFactory;
import org.eclipse.gef.tools.CellEditorLocator;
import org.eclipse.gmf.runtime.diagram.ui.editparts.ITextAwareEditPart;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.gmf.tooling.runtime.directedit.locator.CellEditorLocatorAccess;

/**
 * @generated
 */
public class WebGeneratorMMEditPartFactory implements EditPartFactory {

	/**
	* @generated
	*/
	public EditPart createEditPart(EditPart context, Object model) {
		if (model instanceof View) {
			View view = (View) model;
			switch (WebGeneratorMM.diagram.part.WebGeneratorMMVisualIDRegistry.getVisualID(view)) {

			case WebGeneratorMM.diagram.edit.parts.SitioWebEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.SitioWebEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.IndiceEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.IndiceEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.IndiceNameEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.IndiceNameEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.PaginaCRUDEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.PaginaCRUDEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.PaginaCRUDNameEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.PaginaCRUDNameEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.EncuestaEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.EncuestaEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.EncuestaNameEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.EncuestaNameEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.CuestionarioEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.CuestionarioNameEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.CuestionarioNameEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.DetalleEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.DetalleEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.DetalleNameEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.DetalleNameEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.BorradoEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.BorradoEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.BorradoNameEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.BorradoNameEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.CreacionEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.CreacionEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.CreacionNameEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.CreacionNameEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.PaginaHomeEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.PaginaHomeEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.PaginaHomeNameEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.PaginaHomeNameEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.EntidadEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.EntidadEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.EntidadNameEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.EntidadNameEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.EnlaceExternoEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.EnlaceExternoNameEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.EnlaceExternoNameEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.EnlaceInternoEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.EnlaceInternoNameEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.EnlaceInternoNameEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.ConexionRedSocialEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.ConexionRedSocialTagEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.ConexionRedSocialTagEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.PreguntaCortaEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.PreguntaCortaContentEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.PreguntaCortaContentEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.PreguntaElegirEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.PreguntaElegirEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.PreguntaElegirContentEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.PreguntaElegirContentEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.OpcionEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.OpcionEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.OpcionContentEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.OpcionContentEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.PreguntaVFEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.PreguntaVFEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.PreguntaVFContentEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.PreguntaVFContentEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.ReferenciaEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.ReferenciaEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.ReferenciaNameEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.ReferenciaNameEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.AtributoEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.AtributoNameEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.AtributoNameEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.IndiceIndiceConexionredsocialCompartmentEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.IndiceIndiceConexionredsocialCompartmentEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.IndiceIndiceEnlacesCompartmentEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.IndiceIndiceEnlacesCompartmentEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.PaginaCRUDPaginaCRUDConexionredsocialCompartmentEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.PaginaCRUDPaginaCRUDConexionredsocialCompartmentEditPart(
						view);

			case WebGeneratorMM.diagram.edit.parts.PaginaCRUDPaginaCRUDEnlacesCompartmentEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.PaginaCRUDPaginaCRUDEnlacesCompartmentEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.EncuestaEncuestaConexionredsocialCompartmentEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.EncuestaEncuestaConexionredsocialCompartmentEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.EncuestaEncuestaEnlacesCompartmentEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.EncuestaEncuestaEnlacesCompartmentEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.EncuestaEncuestaPreguntasCompartmentEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.EncuestaEncuestaPreguntasCompartmentEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.PreguntaElegirPreguntaElegirOpcionesCompartmentEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.PreguntaElegirPreguntaElegirOpcionesCompartmentEditPart(
						view);

			case WebGeneratorMM.diagram.edit.parts.CuestionarioCuestionarioConexionredsocialCompartmentEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.CuestionarioCuestionarioConexionredsocialCompartmentEditPart(
						view);

			case WebGeneratorMM.diagram.edit.parts.CuestionarioCuestionarioEnlacesCompartmentEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.CuestionarioCuestionarioEnlacesCompartmentEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.CuestionarioCuestionarioPreguntasCompartmentEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.CuestionarioCuestionarioPreguntasCompartmentEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.DetalleDetalleConexionredsocialCompartmentEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.DetalleDetalleConexionredsocialCompartmentEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.DetalleDetalleEnlacesCompartmentEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.DetalleDetalleEnlacesCompartmentEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.BorradoBorradoConexionredsocialCompartmentEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.BorradoBorradoConexionredsocialCompartmentEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.BorradoBorradoEnlacesCompartmentEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.BorradoBorradoEnlacesCompartmentEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.CreacionCreacionConexionredsocialCompartmentEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.CreacionCreacionConexionredsocialCompartmentEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.CreacionCreacionEnlacesCompartmentEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.CreacionCreacionEnlacesCompartmentEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.PaginaHomePaginaHomeConexionredsocialCompartmentEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.PaginaHomePaginaHomeConexionredsocialCompartmentEditPart(
						view);

			case WebGeneratorMM.diagram.edit.parts.PaginaHomePaginaHomeEnlacesCompartmentEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.PaginaHomePaginaHomeEnlacesCompartmentEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.EntidadEntidadReferenciasCompartmentEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.EntidadEntidadReferenciasCompartmentEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.EntidadEntidadAtributosCompartmentEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.EntidadEntidadAtributosCompartmentEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.ReferenciaDestinoEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.ReferenciaDestinoEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.WrappingLabelEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.WrappingLabelEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.EnlaceInternoReferenciaEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.EnlaceInternoReferenciaEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.WrappingLabel2EditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.WrappingLabel2EditPart(view);

			case WebGeneratorMM.diagram.edit.parts.PaginaEntidadEntidadEditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.PaginaEntidadEntidadEditPart(view);

			case WebGeneratorMM.diagram.edit.parts.WrappingLabel3EditPart.VISUAL_ID:
				return new WebGeneratorMM.diagram.edit.parts.WrappingLabel3EditPart(view);

			}
		}
		return createUnrecognizedEditPart(context, model);
	}

	/**
	* @generated
	*/
	private EditPart createUnrecognizedEditPart(EditPart context, Object model) {
		// Handle creation of unrecognized child node EditParts here
		return null;
	}

	/**
	* @generated
	*/
	public static CellEditorLocator getTextCellEditorLocator(ITextAwareEditPart source) {
		return CellEditorLocatorAccess.INSTANCE.getTextCellEditorLocator(source);
	}

}
