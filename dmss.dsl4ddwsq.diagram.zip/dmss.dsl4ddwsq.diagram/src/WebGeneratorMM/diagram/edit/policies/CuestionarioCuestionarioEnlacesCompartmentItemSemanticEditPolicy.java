/*
* 
*/
package WebGeneratorMM.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class CuestionarioCuestionarioEnlacesCompartmentItemSemanticEditPolicy
		extends WebGeneratorMM.diagram.edit.policies.WebGeneratorMMBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public CuestionarioCuestionarioEnlacesCompartmentItemSemanticEditPolicy() {
		super(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Cuestionario_2004);
	}

	/**
	* @generated
	*/
	protected Command getCreateCommand(CreateElementRequest req) {
		if (WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceExterno_3001 == req.getElementType()) {
			return getGEFWrapper(new WebGeneratorMM.diagram.edit.commands.EnlaceExternoCreateCommand(req));
		}
		if (WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.EnlaceInterno_3002 == req.getElementType()) {
			return getGEFWrapper(new WebGeneratorMM.diagram.edit.commands.EnlaceInternoCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
