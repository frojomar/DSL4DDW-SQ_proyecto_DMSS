/*
* 
*/
package WebGeneratorMM.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class PreguntaElegirPreguntaElegirOpcionesCompartmentItemSemanticEditPolicy
		extends WebGeneratorMM.diagram.edit.policies.WebGeneratorMMBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public PreguntaElegirPreguntaElegirOpcionesCompartmentItemSemanticEditPolicy() {
		super(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PreguntaElegir_3007);
	}

	/**
	* @generated
	*/
	protected Command getCreateCommand(CreateElementRequest req) {
		if (WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Opcion_3008 == req.getElementType()) {
			return getGEFWrapper(new WebGeneratorMM.diagram.edit.commands.OpcionCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
