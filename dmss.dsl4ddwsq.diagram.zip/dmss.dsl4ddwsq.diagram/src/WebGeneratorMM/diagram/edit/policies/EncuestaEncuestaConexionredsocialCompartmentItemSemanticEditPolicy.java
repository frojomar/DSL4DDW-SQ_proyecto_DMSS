/*
* 
*/
package WebGeneratorMM.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class EncuestaEncuestaConexionredsocialCompartmentItemSemanticEditPolicy
		extends WebGeneratorMM.diagram.edit.policies.WebGeneratorMMBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public EncuestaEncuestaConexionredsocialCompartmentItemSemanticEditPolicy() {
		super(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Encuesta_2003);
	}

	/**
	* @generated
	*/
	protected Command getCreateCommand(CreateElementRequest req) {
		if (WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.ConexionRedSocial_3003 == req
				.getElementType()) {
			return getGEFWrapper(new WebGeneratorMM.diagram.edit.commands.ConexionRedSocialCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
