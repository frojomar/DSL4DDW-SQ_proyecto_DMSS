/*
* 
*/
package WebGeneratorMM.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class BorradoBorradoConexionredsocialCompartmentItemSemanticEditPolicy
		extends WebGeneratorMM.diagram.edit.policies.WebGeneratorMMBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public BorradoBorradoConexionredsocialCompartmentItemSemanticEditPolicy() {
		super(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Borrado_2006);
	}

	/**
	* @generated
	*/
	protected Command getCreateCommand(CreateElementRequest req) {
		if (WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.ConexionRedSocial_3003 == req
				.getElementType()) {
			return getGEFWrapper(new WebGeneratorMM.diagram.edit.commands.ConexionRedSocialCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
