/*
* 
*/
package WebGeneratorMM.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class EntidadEntidadAtributosCompartmentItemSemanticEditPolicy
		extends WebGeneratorMM.diagram.edit.policies.WebGeneratorMMBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public EntidadEntidadAtributosCompartmentItemSemanticEditPolicy() {
		super(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Entidad_2009);
	}

	/**
	* @generated
	*/
	protected Command getCreateCommand(CreateElementRequest req) {
		if (WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Atributo_3006 == req.getElementType()) {
			return getGEFWrapper(new WebGeneratorMM.diagram.edit.commands.AtributoCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
