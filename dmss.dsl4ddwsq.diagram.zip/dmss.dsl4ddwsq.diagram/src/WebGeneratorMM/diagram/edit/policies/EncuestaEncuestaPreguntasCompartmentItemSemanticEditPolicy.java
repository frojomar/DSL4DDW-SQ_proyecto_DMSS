/*
* 
*/
package WebGeneratorMM.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class EncuestaEncuestaPreguntasCompartmentItemSemanticEditPolicy
		extends WebGeneratorMM.diagram.edit.policies.WebGeneratorMMBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public EncuestaEncuestaPreguntasCompartmentItemSemanticEditPolicy() {
		super(WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.Encuesta_2003);
	}

	/**
	* @generated
	*/
	protected Command getCreateCommand(CreateElementRequest req) {
		if (WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PreguntaCorta_3004 == req.getElementType()) {
			return getGEFWrapper(new WebGeneratorMM.diagram.edit.commands.PreguntaCortaCreateCommand(req));
		}
		if (WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PreguntaElegir_3007 == req.getElementType()) {
			return getGEFWrapper(new WebGeneratorMM.diagram.edit.commands.PreguntaElegirCreateCommand(req));
		}
		if (WebGeneratorMM.diagram.providers.WebGeneratorMMElementTypes.PreguntaVF_3009 == req.getElementType()) {
			return getGEFWrapper(new WebGeneratorMM.diagram.edit.commands.PreguntaVFCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
