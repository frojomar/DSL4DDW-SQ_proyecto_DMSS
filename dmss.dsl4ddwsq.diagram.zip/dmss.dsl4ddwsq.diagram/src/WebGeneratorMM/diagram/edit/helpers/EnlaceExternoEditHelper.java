/*
 * 
 */
package WebGeneratorMM.diagram.edit.helpers;

/**
 * @generated
 */
public class EnlaceExternoEditHelper extends WebGeneratorMM.diagram.edit.helpers.WebGeneratorMMBaseEditHelper {
}
