/*
 * 
 */
package WebGeneratorMM.diagram.edit.helpers;

/**
 * @generated
 */
public class ConexionRedSocialEditHelper extends WebGeneratorMM.diagram.edit.helpers.WebGeneratorMMBaseEditHelper {
}
