/*
 * 
 */
package WebGeneratorMM.diagram.edit.helpers;

/**
 * @generated
 */
public class PreguntaVFEditHelper extends WebGeneratorMM.diagram.edit.helpers.WebGeneratorMMBaseEditHelper {
}
