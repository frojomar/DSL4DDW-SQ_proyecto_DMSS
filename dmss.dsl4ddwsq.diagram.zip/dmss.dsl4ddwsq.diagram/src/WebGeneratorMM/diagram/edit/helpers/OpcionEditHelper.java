/*
 * 
 */
package WebGeneratorMM.diagram.edit.helpers;

/**
 * @generated
 */
public class OpcionEditHelper extends WebGeneratorMM.diagram.edit.helpers.WebGeneratorMMBaseEditHelper {
}
