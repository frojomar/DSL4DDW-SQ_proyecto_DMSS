/*
 * 
 */
package WebGeneratorMM.diagram.edit.helpers;

/**
 * @generated
 */
public class EncuestaEditHelper extends WebGeneratorMM.diagram.edit.helpers.WebGeneratorMMBaseEditHelper {
}
