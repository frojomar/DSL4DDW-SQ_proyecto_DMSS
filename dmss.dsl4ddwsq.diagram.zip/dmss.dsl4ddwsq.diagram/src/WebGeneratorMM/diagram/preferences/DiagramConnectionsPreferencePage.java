/*
 * 
 */
package WebGeneratorMM.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.ConnectionsPreferencePage;

/**
 * @generated
 */
public class DiagramConnectionsPreferencePage extends ConnectionsPreferencePage {

	/**
	* @generated
	*/
	public DiagramConnectionsPreferencePage() {
		setPreferenceStore(
				WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
