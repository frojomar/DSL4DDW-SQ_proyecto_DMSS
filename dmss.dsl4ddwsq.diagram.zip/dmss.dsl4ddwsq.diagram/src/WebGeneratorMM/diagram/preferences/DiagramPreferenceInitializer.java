/*
 * 
 */
package WebGeneratorMM.diagram.preferences;

import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;
import org.eclipse.jface.preference.IPreferenceStore;

/**
 * @generated
 */
public class DiagramPreferenceInitializer extends AbstractPreferenceInitializer {

	/**
	* @generated
	*/
	public void initializeDefaultPreferences() {
		IPreferenceStore store = getPreferenceStore();
		WebGeneratorMM.diagram.preferences.DiagramGeneralPreferencePage.initDefaults(store);
		WebGeneratorMM.diagram.preferences.DiagramAppearancePreferencePage.initDefaults(store);
		WebGeneratorMM.diagram.preferences.DiagramConnectionsPreferencePage.initDefaults(store);
		WebGeneratorMM.diagram.preferences.DiagramPrintingPreferencePage.initDefaults(store);
		WebGeneratorMM.diagram.preferences.DiagramRulersAndGridPreferencePage.initDefaults(store);

	}

	/**
	* @generated
	*/
	protected IPreferenceStore getPreferenceStore() {
		return WebGeneratorMM.diagram.part.WebGeneratorMMDiagramEditorPlugin.getInstance().getPreferenceStore();
	}
}
