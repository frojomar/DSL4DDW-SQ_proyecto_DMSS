/**
 */
package WebGeneratorMM;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pagina Web</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link WebGeneratorMM.PaginaWeb#getName <em>Name</em>}</li>
 *   <li>{@link WebGeneratorMM.PaginaWeb#getConexionredsocial <em>Conexionredsocial</em>}</li>
 *   <li>{@link WebGeneratorMM.PaginaWeb#getEnlaces <em>Enlaces</em>}</li>
 * </ul>
 *
 * @see WebGeneratorMM.WebGeneratorMMPackage#getPaginaWeb()
 * @model abstract="true"
 *        annotation="MyDSLDoc Description='Elemento p\341gina web que se traducir\341 en una p\341gina web real en HTML.\nUna p\341gina web puede convertirse en la p\341gina Home del sitio, una p\341gina de entidad, o un formulario de recogida de datos.\nCada p\341gina web contiene una serie de enlaces (internos o externos) y da la opci\363n de establecer una conexi\363n hacia una red social.'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore constraints='nombre_sin_espacios'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot nombre_sin_espacios='self.name=self.name.replaceAll(\' \',\'\')'"
 *        annotation="gmf.node label='name' color='255,206,147' border.width='3' border.style='solid'"
 * @generated
 */
public interface PaginaWeb extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getPaginaWeb_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link WebGeneratorMM.PaginaWeb#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Conexionredsocial</b></em>' containment reference list.
	 * The list contents are of type {@link WebGeneratorMM.ConexionRedSocial}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Conexionredsocial</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Conexionredsocial</em>' containment reference list.
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getPaginaWeb_Conexionredsocial()
	 * @model containment="true"
	 *        annotation="gmf.compartment foo='bar' layout='list'"
	 * @generated
	 */
	EList<ConexionRedSocial> getConexionredsocial();

	/**
	 * Returns the value of the '<em><b>Enlaces</b></em>' containment reference list.
	 * The list contents are of type {@link WebGeneratorMM.Enlace}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Enlaces</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Enlaces</em>' containment reference list.
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getPaginaWeb_Enlaces()
	 * @model containment="true"
	 *        annotation="gmf.compartment foo='bar' layout='list'"
	 * @generated
	 */
	EList<Enlace> getEnlaces();

} // PaginaWeb
