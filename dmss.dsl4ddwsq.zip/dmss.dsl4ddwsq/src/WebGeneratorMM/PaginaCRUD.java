/**
 */
package WebGeneratorMM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pagina CRUD</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see WebGeneratorMM.WebGeneratorMMPackage#getPaginaCRUD()
 * @model annotation="MyDSLDoc Description='Representa una p\341gina CRUD que se utiliza para las conexiones con la base de datos. Al ser CRUD, las opciones que se ofrecen son: Create, Read, Update y Delete. Al especificar este tipo de p\341gina se crean las 4 p\341ginas CRUD al mismo tiempo.'"
 *        annotation="gmf.node label='name' color='170,242,152'"
 * @generated
 */
public interface PaginaCRUD extends PaginaEntidad {
} // PaginaCRUD
