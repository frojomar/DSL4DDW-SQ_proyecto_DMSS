/**
 */
package WebGeneratorMM;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Entidad</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link WebGeneratorMM.Entidad#getReferencias <em>Referencias</em>}</li>
 *   <li>{@link WebGeneratorMM.Entidad#getAtributos <em>Atributos</em>}</li>
 *   <li>{@link WebGeneratorMM.Entidad#getName <em>Name</em>}</li>
 * </ul>
 *
 * @see WebGeneratorMM.WebGeneratorMMPackage#getEntidad()
 * @model annotation="MyDSLDoc Description='Representaci\363n de un objeto o un concepto del mundo real. Ser\341n clases que poseen un nombre para identificarlas junto con una serie de atributos y m\351todos.'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore constraints='name_es_string un_atributo_name id_es_integer un_atributo_id image_es_string un_atributo_image nombres_atributos_distintos nombre_sin_espacios'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot name_es_string='self.atributos->select(name=\'name\')->forAll(type=ATRTYPE::String)' un_atributo_name='self.atributos->select(name=\'name\')->size()=1' id_es_integer='self.atributos->select(name=(\'id_\'.concat(self.name)))->forAll(type=ATRTYPE::Integer)' un_atributo_id='self.atributos->select(name=(\'id_\'.concat(self.name)))->size()=1' image_es_string='self.atributos->select(name=\'image\')->forAll(type=ATRTYPE::String)' un_atributo_image='self.atributos->select(name=\'image\')->size()=1' nombres_atributos_distintos='self.atributos->forAll(a1, a2: Atributo | a1=a2 or a1.name<>a2.name)' nombre_sin_espacios='self.name=self.name.replaceAll(\' \',\'\')'"
 *        annotation="gmf.node label='name' color='249,247,112' border.width='3' border.style='solid'"
 * @generated
 */
public interface Entidad extends EObject {
	/**
	 * Returns the value of the '<em><b>Referencias</b></em>' containment reference list.
	 * The list contents are of type {@link WebGeneratorMM.Referencia}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Referencias</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Referencias</em>' containment reference list.
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getEntidad_Referencias()
	 * @model containment="true"
	 *        annotation="gmf.compartment foo='bar' layout='list'"
	 * @generated
	 */
	EList<Referencia> getReferencias();

	/**
	 * Returns the value of the '<em><b>Atributos</b></em>' containment reference list.
	 * The list contents are of type {@link WebGeneratorMM.Atributo}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Atributos</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Atributos</em>' containment reference list.
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getEntidad_Atributos()
	 * @model containment="true"
	 *        annotation="gmf.compartment foo='bar' layout='list'"
	 * @generated
	 */
	EList<Atributo> getAtributos();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getEntidad_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link WebGeneratorMM.Entidad#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

} // Entidad
