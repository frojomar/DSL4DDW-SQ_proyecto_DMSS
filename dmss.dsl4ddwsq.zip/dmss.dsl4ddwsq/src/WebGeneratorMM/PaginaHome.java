/**
 */
package WebGeneratorMM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pagina Home</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see WebGeneratorMM.WebGeneratorMMPackage#getPaginaHome()
 * @model annotation="MyDSLDoc Description='P\341gina principal del Sitio Web (index). Ser\341 la primera p\341gina a la que acceder\341 un usuario al entrar al sitio.'"
 *        annotation="gmf.node label='name' figure='svg' svg.uri='platform:/plugin/dmss.dsl4ddwsq/img/home.svg'"
 * @generated
 */
public interface PaginaHome extends PaginaWeb {
} // PaginaHome
