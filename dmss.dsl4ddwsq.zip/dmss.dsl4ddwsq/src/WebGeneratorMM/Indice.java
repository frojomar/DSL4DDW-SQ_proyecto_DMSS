/**
 */
package WebGeneratorMM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Indice</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see WebGeneratorMM.WebGeneratorMMPackage#getIndice()
 * @model annotation="MyDSLDoc Description='Hereda de PaginaEntidad. Representa la p\341gina \355ndice donde se podr\341n encontrar todas las referencias al resto de p\341ginas para facilitar su ubicaci\363n y f\341cil acceso.'"
 *        annotation="gmf.node label='name' color='170,242,152'"
 * @generated
 */
public interface Indice extends PaginaEntidad {
} // Indice
