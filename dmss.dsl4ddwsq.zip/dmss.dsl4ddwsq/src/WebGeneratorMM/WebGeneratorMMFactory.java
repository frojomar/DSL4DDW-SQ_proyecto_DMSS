/**
 */
package WebGeneratorMM;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see WebGeneratorMM.WebGeneratorMMPackage
 * @generated
 */
public interface WebGeneratorMMFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	WebGeneratorMMFactory eINSTANCE = WebGeneratorMM.impl.WebGeneratorMMFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sitio Web</em>'.
	 * @generated
	 */
	SitioWeb createSitioWeb();

	/**
	 * Returns a new object of class '<em>Entidad</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Entidad</em>'.
	 * @generated
	 */
	Entidad createEntidad();

	/**
	 * Returns a new object of class '<em>Referencia</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Referencia</em>'.
	 * @generated
	 */
	Referencia createReferencia();

	/**
	 * Returns a new object of class '<em>Atributo</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Atributo</em>'.
	 * @generated
	 */
	Atributo createAtributo();

	/**
	 * Returns a new object of class '<em>Indice</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Indice</em>'.
	 * @generated
	 */
	Indice createIndice();

	/**
	 * Returns a new object of class '<em>Pagina CRUD</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Pagina CRUD</em>'.
	 * @generated
	 */
	PaginaCRUD createPaginaCRUD();

	/**
	 * Returns a new object of class '<em>Pagina Home</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Pagina Home</em>'.
	 * @generated
	 */
	PaginaHome createPaginaHome();

	/**
	 * Returns a new object of class '<em>Conexion Red Social</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Conexion Red Social</em>'.
	 * @generated
	 */
	ConexionRedSocial createConexionRedSocial();

	/**
	 * Returns a new object of class '<em>Pregunta Corta</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Pregunta Corta</em>'.
	 * @generated
	 */
	PreguntaCorta createPreguntaCorta();

	/**
	 * Returns a new object of class '<em>Pregunta Elegir</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Pregunta Elegir</em>'.
	 * @generated
	 */
	PreguntaElegir createPreguntaElegir();

	/**
	 * Returns a new object of class '<em>Pregunta VF</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Pregunta VF</em>'.
	 * @generated
	 */
	PreguntaVF createPreguntaVF();

	/**
	 * Returns a new object of class '<em>Encuesta</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Encuesta</em>'.
	 * @generated
	 */
	Encuesta createEncuesta();

	/**
	 * Returns a new object of class '<em>Cuestionario</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Cuestionario</em>'.
	 * @generated
	 */
	Cuestionario createCuestionario();

	/**
	 * Returns a new object of class '<em>Enlace Externo</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Enlace Externo</em>'.
	 * @generated
	 */
	EnlaceExterno createEnlaceExterno();

	/**
	 * Returns a new object of class '<em>Enlace Interno</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Enlace Interno</em>'.
	 * @generated
	 */
	EnlaceInterno createEnlaceInterno();

	/**
	 * Returns a new object of class '<em>Opcion</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Opcion</em>'.
	 * @generated
	 */
	Opcion createOpcion();

	/**
	 * Returns a new object of class '<em>Detalle</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Detalle</em>'.
	 * @generated
	 */
	Detalle createDetalle();

	/**
	 * Returns a new object of class '<em>Borrado</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Borrado</em>'.
	 * @generated
	 */
	Borrado createBorrado();

	/**
	 * Returns a new object of class '<em>Creacion</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Creacion</em>'.
	 * @generated
	 */
	Creacion createCreacion();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	WebGeneratorMMPackage getWebGeneratorMMPackage();

} //WebGeneratorMMFactory
