/**
 */
package WebGeneratorMM;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Opcion</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link WebGeneratorMM.Opcion#getContent <em>Content</em>}</li>
 *   <li>{@link WebGeneratorMM.Opcion#isCorrecta <em>Correcta</em>}</li>
 * </ul>
 *
 * @see WebGeneratorMM.WebGeneratorMMPackage#getOpcion()
 * @model annotation="MyDSLDoc Description='Ofrece una descripci\363n para detallar la opci\363n y un atributo para especificar si es la opci\363n correcta a la pregunta o no.'"
 *        annotation="gmf.node label='content'"
 * @generated
 */
public interface Opcion extends EObject {
	/**
	 * Returns the value of the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Content</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Content</em>' attribute.
	 * @see #setContent(String)
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getOpcion_Content()
	 * @model
	 * @generated
	 */
	String getContent();

	/**
	 * Sets the value of the '{@link WebGeneratorMM.Opcion#getContent <em>Content</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Content</em>' attribute.
	 * @see #getContent()
	 * @generated
	 */
	void setContent(String value);

	/**
	 * Returns the value of the '<em><b>Correcta</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Correcta</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Correcta</em>' attribute.
	 * @see #setCorrecta(boolean)
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getOpcion_Correcta()
	 * @model
	 * @generated
	 */
	boolean isCorrecta();

	/**
	 * Sets the value of the '{@link WebGeneratorMM.Opcion#isCorrecta <em>Correcta</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Correcta</em>' attribute.
	 * @see #isCorrecta()
	 * @generated
	 */
	void setCorrecta(boolean value);

} // Opcion
