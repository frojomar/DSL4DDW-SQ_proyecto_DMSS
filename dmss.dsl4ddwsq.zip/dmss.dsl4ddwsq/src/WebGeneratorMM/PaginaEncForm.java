/**
 */
package WebGeneratorMM;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pagina Enc Form</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link WebGeneratorMM.PaginaEncForm#getPreguntas <em>Preguntas</em>}</li>
 * </ul>
 *
 * @see WebGeneratorMM.WebGeneratorMMPackage#getPaginaEncForm()
 * @model abstract="true"
 *        annotation="MyDSLDoc Description='P\341gina de recogida de datos introducidos por el usuario. Es una clase abstracta que se convierte en una Encuesta o en un Formulario. Est\341 compuesta por una serie de preguntas que se realizan al usuario.'"
 * @generated
 */
public interface PaginaEncForm extends PaginaWeb {
	/**
	 * Returns the value of the '<em><b>Preguntas</b></em>' containment reference list.
	 * The list contents are of type {@link WebGeneratorMM.Pregunta}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Preguntas</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Preguntas</em>' containment reference list.
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getPaginaEncForm_Preguntas()
	 * @model containment="true"
	 *        annotation="gmf.compartment foo='bar' layout='list'"
	 * @generated
	 */
	EList<Pregunta> getPreguntas();

} // PaginaEncForm
