/**
 */
package WebGeneratorMM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Cuestionario</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see WebGeneratorMM.WebGeneratorMMPackage#getCuestionario()
 * @model annotation="MyDSLDoc Description='Representa al conjunto de cuestiones o preguntas que ser\341n contestadas por el usuario.'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore constraints='respuestas_corta_definidas respuestas_elegir_definidas respuestas_vf_definidas preguntas_elegir_solo_una_opcion_correcta'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot respuestas_corta_definidas='self.preguntas->select(oclIsTypeOf(PreguntaCorta)).oclAsType(PreguntaCorta)->\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tforAll(not solucion.oclIsUndefined() and solucion<>\'\')' respuestas_elegir_definidas='self.preguntas->select(oclIsTypeOf(PreguntaElegir)).oclAsType(PreguntaElegir)->\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tforAll(p: PreguntaElegir| p.opciones ->forAll(correcta=false or correcta=true))' respuestas_vf_definidas='self.preguntas->select(oclIsTypeOf(PreguntaVF)).oclAsType(PreguntaVF)->\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tforAll(solucion=false or solucion=true)' preguntas_elegir_solo_una_opcion_correcta='self.preguntas->select(oclIsTypeOf(PreguntaElegir)).\n\t\t\t\t\toclAsType(PreguntaElegir)->forAll(opciones->select(correcta=true)->size()=1)'"
 *        annotation="gmf.node label='name' color='137,223,249'"
 * @generated
 */
public interface Cuestionario extends PaginaEncForm {
} // Cuestionario
