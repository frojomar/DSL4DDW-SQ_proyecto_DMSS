/**
 */
package WebGeneratorMM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Creacion</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see WebGeneratorMM.WebGeneratorMMPackage#getCreacion()
 * @model annotation="MyDSLDoc Description='P\341gina que ofrece las herramientas necesarias para la creaci\363n de un nuevo elemento entidad.'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore constraints='no_permitidos_enlaces no_permitidas_conexiones_redSocial'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot no_permitidos_enlaces='self.enlaces->size()=0' no_permitidas_conexiones_redSocial='self.conexionredsocial->size()=0'"
 *        annotation="gmf.node label='name' color='170,242,152'"
 * @generated
 */
public interface Creacion extends PaginaEntidad {
} // Creacion
