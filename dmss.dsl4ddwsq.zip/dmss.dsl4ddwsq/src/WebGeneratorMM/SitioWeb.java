/**
 */
package WebGeneratorMM;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sitio Web</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link WebGeneratorMM.SitioWeb#getEntidadesModelo <em>Entidades Modelo</em>}</li>
 *   <li>{@link WebGeneratorMM.SitioWeb#getPaginasweb <em>Paginasweb</em>}</li>
 *   <li>{@link WebGeneratorMM.SitioWeb#getName <em>Name</em>}</li>
 *   <li>{@link WebGeneratorMM.SitioWeb#getImage <em>Image</em>}</li>
 * </ul>
 *
 * @see WebGeneratorMM.WebGeneratorMMPackage#getSitioWeb()
 * @model annotation="MyDSLDoc Description='Elemento Root del metamodelo que define el sitio que se va a modelar. Contiene tanto las p\341ginas web a dise\361ar como las entidades que se utilizar\341n en ellas.'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore constraints='sitio_debe_tener_nombre sitio_debe_tener_image no_mismo_nombre_entidades no_mismo_nombre_paginas una_pagina_home no_dos_indice_misma_entidad no_dos_detalle_misma_entidad no_dos_creacion_misma_entidad no_dos_borrado_misma_entidad no_dos_crud_misma_entidad no_crud_y_indice no_crud_y_detalle no_crud_y_creacion no_crud_y_borrado al_menos_un_cuestionario al_menos_una_encuesta indice_implica_detalle detalle_implica_indice al_menos_una_pagina_con_red_social home_enlaza_cruds_y_indices creacion_implica_indice borrado_implica_detalle ref_muchas_implica_no_muchas ref_no_muchos_unica_en_cada_entidad prohibidas_ref_no_muchos_unica_bidireccional paginas_todas_alcanzables'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot sitio_debe_tener_nombre='not self.name.oclIsUndefined() and self.name<>\'\'' sitio_debe_tener_image='not self.image.oclIsUndefined() and self.image<>\'\'' no_mismo_nombre_entidades='self.entidadesModelo->forAll(e1, e2: Entidad | e1=e2 or e1.name<>e2.name)' no_mismo_nombre_paginas='self.paginasweb ->forAll(p1, p2: PaginaWeb | p1=p2 or p1.name<>p2.name)' una_pagina_home='self.paginasweb->select(oclIsTypeOf(PaginaHome))->size()=1' no_dos_indice_misma_entidad='self.paginasweb->select(oclIsTypeOf(Indice)).oclAsType(Indice)->forAll(p1, p2: Indice| p1=p2 or p1.entidad<>p2.entidad)' no_dos_detalle_misma_entidad='self.paginasweb->select(oclIsTypeOf(Detalle)).oclAsType(Detalle)->forAll(p1, p2: Detalle| p1=p2 or p1.entidad<>p2.entidad)' no_dos_creacion_misma_entidad='self.paginasweb->select(oclIsTypeOf(Creacion)).oclAsType(Creacion)->forAll(p1, p2: Creacion| p1=p2 or p1.entidad<>p2.entidad)' no_dos_borrado_misma_entidad='self.paginasweb->select(oclIsTypeOf(Borrado)).oclAsType(Borrado)->forAll(p1, p2: Borrado| p1=p2 or p1.entidad<>p2.entidad)' no_dos_crud_misma_entidad='self.paginasweb->select(oclIsTypeOf(PaginaCRUD)).oclAsType(PaginaCRUD)->forAll(p1, p2: PaginaCRUD| p1=p2 or p1.entidad<>p2.entidad)' no_crud_y_indice='self.paginasweb->select(oclIsTypeOf(PaginaCRUD)).oclAsType(PaginaCRUD)->forAll(pC: PaginaCRUD |\n\t\t\t\t\t\tself.paginasweb->select(oclIsTypeOf(Indice)).oclAsType(Indice)->forAll(pI: Indice| pC.entidad<>pI.entidad))' no_crud_y_detalle='self.paginasweb->select(oclIsTypeOf(PaginaCRUD)).oclAsType(PaginaCRUD)->forAll(pC: PaginaCRUD |\n\t\t\t\t\t\tself.paginasweb->select(oclIsTypeOf(Detalle)).oclAsType(Detalle)->forAll(pD: Detalle| pC.entidad<>pD.entidad))' no_crud_y_creacion='self.paginasweb->select(oclIsTypeOf(PaginaCRUD)).oclAsType(PaginaCRUD)->forAll(pC: PaginaCRUD |\n\t\t\t\t\t\tself.paginasweb->select(oclIsTypeOf(Creacion)).oclAsType(Creacion)->forAll(pCreacion: Creacion| pC.entidad<>pCreacion.entidad))' no_crud_y_borrado='self.paginasweb->select(oclIsTypeOf(PaginaCRUD)).oclAsType(PaginaCRUD)->forAll(pC: PaginaCRUD |\n\t\t\t\t\t\tself.paginasweb->select(oclIsTypeOf(Borrado)).oclAsType(Borrado)->forAll(pB: Borrado| pC.entidad<>pB.entidad))' al_menos_un_cuestionario='self.paginasweb->select(oclIsTypeOf(Cuestionario))->size()>=1' al_menos_una_encuesta='self.paginasweb->select(oclIsTypeOf(Encuesta))->size()>=1' indice_implica_detalle='self.paginasweb->select(oclIsTypeOf(Indice)).oclAsType(Indice)->forAll(pI: Indice| \n\t\t\t\t\t\tself.paginasweb->select(oclIsTypeOf(Detalle)).oclAsType(Detalle)->exists(pD: Detalle| pI.entidad=pD.entidad))' detalle_implica_indice='self.paginasweb->select(oclIsTypeOf(Detalle)).oclAsType(Detalle)->forAll(pD: Detalle| \n\t\t\t\t\t\tself.paginasweb->select(oclIsTypeOf(Indice)).oclAsType(Indice)->exists(pI: Indice| pD.entidad=pI.entidad))' al_menos_una_pagina_con_red_social='self.paginasweb->select(conexionredsocial->size()>=1)->size()>=1' home_enlaza_cruds_y_indices='self.paginasweb->select(oclIsTypeOf(Indice) or oclIsTypeOf(PaginaCRUD))->\n\t\t\tforAll(p | self.paginasweb->select(oclIsTypeOf(PaginaHome)).enlaces->select(e|e.oclIsTypeOf(EnlaceInterno))->\n\t\t\t\tselect(e| e.oclAsType(EnlaceInterno).referencia=p)->size()>0\n\t\t\t)' creacion_implica_indice='self.paginasweb->select(oclIsTypeOf(Creacion)).oclAsType(Creacion)->forAll(pC: Creacion| \n\t\t\t\t\t\tself.paginasweb->select(oclIsTypeOf(Indice)).oclAsType(Indice)->exists(pI: Indice| pC.entidad=pI.entidad))' borrado_implica_detalle='self.paginasweb->select(oclIsTypeOf(Borrado)).oclAsType(Borrado)->forAll(pB: Borrado| \n\t\t\t\t\t\tself.paginasweb->select(oclIsTypeOf(Detalle)).oclAsType(Detalle)->exists(pD: Detalle| pB.entidad=pD.entidad))' ref_muchas_implica_no_muchas='self.entidadesModelo->forAll(e:Entidad | e.referencias->select(muchas=true)->\n\t\t\tforAll(r:Referencia| r.destino.referencias->exists(r2:Referencia|r2.destino=e and r2.muchas=false)))' ref_no_muchos_unica_en_cada_entidad='self.entidadesModelo->forAll(e:Entidad | e.referencias->select(muchas=false)->\n\t\t\tforAll(r1,r2 | r1=r2 or r1.destino<>r2.destino))' prohibidas_ref_no_muchos_unica_bidireccional='self.entidadesModelo->forAll(e:Entidad | e.referencias->select(muchas=false)->\n\t\t\tforAll(r:Referencia| not r.destino.referencias->exists(r2:Referencia|r2.destino=e and r2.muchas=false)))' paginas_todas_alcanzables='self.paginasweb->select(oclIsTypeOf(Indice) or oclIsTypeOf(PaginaCRUD) or oclIsKindOf(PaginaEncForm))->\n\t\t\tforAll(p|self.paginasweb.enlaces->select(oclIsTypeOf(EnlaceInterno)).oclAsType(EnlaceInterno)->\n\t\t\t\tselect(referencia=p)->size()>=1)'"
 * @generated
 */
public interface SitioWeb extends EObject {
	/**
	 * Returns the value of the '<em><b>Entidades Modelo</b></em>' containment reference list.
	 * The list contents are of type {@link WebGeneratorMM.Entidad}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Entidades Modelo</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Entidades Modelo</em>' containment reference list.
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getSitioWeb_EntidadesModelo()
	 * @model containment="true"
	 * @generated
	 */
	EList<Entidad> getEntidadesModelo();

	/**
	 * Returns the value of the '<em><b>Paginasweb</b></em>' containment reference list.
	 * The list contents are of type {@link WebGeneratorMM.PaginaWeb}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Paginasweb</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Paginasweb</em>' containment reference list.
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getSitioWeb_Paginasweb()
	 * @model containment="true"
	 * @generated
	 */
	EList<PaginaWeb> getPaginasweb();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getSitioWeb_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link WebGeneratorMM.SitioWeb#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Image</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Image</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Image</em>' attribute.
	 * @see #setImage(String)
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getSitioWeb_Image()
	 * @model
	 * @generated
	 */
	String getImage();

	/**
	 * Sets the value of the '{@link WebGeneratorMM.SitioWeb#getImage <em>Image</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Image</em>' attribute.
	 * @see #getImage()
	 * @generated
	 */
	void setImage(String value);

} // SitioWeb
