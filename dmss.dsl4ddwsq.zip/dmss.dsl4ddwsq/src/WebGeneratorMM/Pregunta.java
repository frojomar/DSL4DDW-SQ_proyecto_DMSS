/**
 */
package WebGeneratorMM;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pregunta</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link WebGeneratorMM.Pregunta#getNumOrden <em>Num Orden</em>}</li>
 *   <li>{@link WebGeneratorMM.Pregunta#getContent <em>Content</em>}</li>
 * </ul>
 *
 * @see WebGeneratorMM.WebGeneratorMMPackage#getPregunta()
 * @model abstract="true"
 *        annotation="MyDSLDoc Description='Clase abstracta que se materializa en una pregunta corta, una pregunta de elecci\363n m\372ltiple o una pregunta de verdadero/falso.'"
 * @generated
 */
public interface Pregunta extends EObject {
	/**
	 * Returns the value of the '<em><b>Num Orden</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Num Orden</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Num Orden</em>' attribute.
	 * @see #setNumOrden(int)
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getPregunta_NumOrden()
	 * @model
	 * @generated
	 */
	int getNumOrden();

	/**
	 * Sets the value of the '{@link WebGeneratorMM.Pregunta#getNumOrden <em>Num Orden</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Num Orden</em>' attribute.
	 * @see #getNumOrden()
	 * @generated
	 */
	void setNumOrden(int value);

	/**
	 * Returns the value of the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Content</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Content</em>' attribute.
	 * @see #setContent(String)
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getPregunta_Content()
	 * @model
	 * @generated
	 */
	String getContent();

	/**
	 * Sets the value of the '{@link WebGeneratorMM.Pregunta#getContent <em>Content</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Content</em>' attribute.
	 * @see #getContent()
	 * @generated
	 */
	void setContent(String value);

} // Pregunta
