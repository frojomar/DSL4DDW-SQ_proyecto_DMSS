/**
 */
package WebGeneratorMM;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Atributo</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link WebGeneratorMM.Atributo#getType <em>Type</em>}</li>
 *   <li>{@link WebGeneratorMM.Atributo#getName <em>Name</em>}</li>
 * </ul>
 *
 * @see WebGeneratorMM.WebGeneratorMMPackage#getAtributo()
 * @model annotation="MyDSLDoc Description='Representan variables de instancia, definidas con un tipo y un nombre. Cada objeto particular tendr\341 valores distintos para estas variables.'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore constraints='nombre_sin_espacios nombre_empieza_minusculas'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot nombre_sin_espacios='self.name=self.name.replaceAll(\' \',\'\')' nombre_empieza_minusculas='self.name.substring(1,1).toLower()=self.name.substring(1,1)'"
 *        annotation="gmf.node label='name' border.width='1' border.color='252,78,78' border.style='solid'"
 * @generated
 */
public interface Atributo extends EObject {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link WebGeneratorMM.ATRTYPE}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see WebGeneratorMM.ATRTYPE
	 * @see #setType(ATRTYPE)
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getAtributo_Type()
	 * @model
	 * @generated
	 */
	ATRTYPE getType();

	/**
	 * Sets the value of the '{@link WebGeneratorMM.Atributo#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see WebGeneratorMM.ATRTYPE
	 * @see #getType()
	 * @generated
	 */
	void setType(ATRTYPE value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getAtributo_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link WebGeneratorMM.Atributo#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

} // Atributo
