/**
 */
package WebGeneratorMM;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Referencia</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link WebGeneratorMM.Referencia#getDestino <em>Destino</em>}</li>
 *   <li>{@link WebGeneratorMM.Referencia#getName <em>Name</em>}</li>
 *   <li>{@link WebGeneratorMM.Referencia#isMuchas <em>Muchas</em>}</li>
 * </ul>
 *
 * @see WebGeneratorMM.WebGeneratorMMPackage#getReferencia()
 * @model annotation="MyDSLDoc Description='Indica la relaci\363n entre una clase origen y un destino. Se identificar\341 con un nombre y posee un atributo para indicar si la cardinalidad del destino es 1 o N.'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore constraints='nombre_sin_espacios nombre_empieza_minusculas'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot nombre_sin_espacios='self.name=self.name.replaceAll(\' \',\'\')' nombre_empieza_minusculas='self.name.substring(1,1).toLower()=self.name.substring(1,1)'"
 *        annotation="gmf.node label='name'"
 * @generated
 */
public interface Referencia extends EObject {
	/**
	 * Returns the value of the '<em><b>Destino</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Destino</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Destino</em>' reference.
	 * @see #setDestino(Entidad)
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getReferencia_Destino()
	 * @model required="true"
	 *        annotation="gmf.link target.decoration='arrow' color='178,140,1' style='dash' tool.name='Entidad a Entidad'"
	 * @generated
	 */
	Entidad getDestino();

	/**
	 * Sets the value of the '{@link WebGeneratorMM.Referencia#getDestino <em>Destino</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Destino</em>' reference.
	 * @see #getDestino()
	 * @generated
	 */
	void setDestino(Entidad value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getReferencia_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link WebGeneratorMM.Referencia#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Muchas</b></em>' attribute.
	 * The default value is <code>"false"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Muchas</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Muchas</em>' attribute.
	 * @see #setMuchas(boolean)
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getReferencia_Muchas()
	 * @model default="false"
	 * @generated
	 */
	boolean isMuchas();

	/**
	 * Sets the value of the '{@link WebGeneratorMM.Referencia#isMuchas <em>Muchas</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Muchas</em>' attribute.
	 * @see #isMuchas()
	 * @generated
	 */
	void setMuchas(boolean value);

} // Referencia
