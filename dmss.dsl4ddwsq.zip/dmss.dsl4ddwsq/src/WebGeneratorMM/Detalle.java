/**
 */
package WebGeneratorMM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Detalle</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see WebGeneratorMM.WebGeneratorMMPackage#getDetalle()
 * @model annotation="MyDSLDoc Description='Lee informaci\363n de la BD y la muestra en la p\341gina.'"
 *        annotation="gmf.node label='name' color='170,242,152'"
 * @generated
 */
public interface Detalle extends PaginaEntidad {
} // Detalle
