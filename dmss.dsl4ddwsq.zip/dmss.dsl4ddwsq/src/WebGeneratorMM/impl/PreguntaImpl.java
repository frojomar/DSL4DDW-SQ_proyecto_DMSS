/**
 */
package WebGeneratorMM.impl;

import WebGeneratorMM.Pregunta;
import WebGeneratorMM.WebGeneratorMMPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Pregunta</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link WebGeneratorMM.impl.PreguntaImpl#getNumOrden <em>Num Orden</em>}</li>
 *   <li>{@link WebGeneratorMM.impl.PreguntaImpl#getContent <em>Content</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class PreguntaImpl extends EObjectImpl implements Pregunta {
	/**
	 * The default value of the '{@link #getNumOrden() <em>Num Orden</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNumOrden()
	 * @generated
	 * @ordered
	 */
	protected static final int NUM_ORDEN_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getNumOrden() <em>Num Orden</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNumOrden()
	 * @generated
	 * @ordered
	 */
	protected int numOrden = NUM_ORDEN_EDEFAULT;

	/**
	 * The default value of the '{@link #getContent() <em>Content</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContent()
	 * @generated
	 * @ordered
	 */
	protected static final String CONTENT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getContent() <em>Content</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContent()
	 * @generated
	 * @ordered
	 */
	protected String content = CONTENT_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PreguntaImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WebGeneratorMMPackage.Literals.PREGUNTA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getNumOrden() {
		return numOrden;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNumOrden(int newNumOrden) {
		int oldNumOrden = numOrden;
		numOrden = newNumOrden;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WebGeneratorMMPackage.PREGUNTA__NUM_ORDEN, oldNumOrden, numOrden));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getContent() {
		return content;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setContent(String newContent) {
		String oldContent = content;
		content = newContent;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WebGeneratorMMPackage.PREGUNTA__CONTENT, oldContent, content));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case WebGeneratorMMPackage.PREGUNTA__NUM_ORDEN:
				return getNumOrden();
			case WebGeneratorMMPackage.PREGUNTA__CONTENT:
				return getContent();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case WebGeneratorMMPackage.PREGUNTA__NUM_ORDEN:
				setNumOrden((Integer)newValue);
				return;
			case WebGeneratorMMPackage.PREGUNTA__CONTENT:
				setContent((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case WebGeneratorMMPackage.PREGUNTA__NUM_ORDEN:
				setNumOrden(NUM_ORDEN_EDEFAULT);
				return;
			case WebGeneratorMMPackage.PREGUNTA__CONTENT:
				setContent(CONTENT_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case WebGeneratorMMPackage.PREGUNTA__NUM_ORDEN:
				return numOrden != NUM_ORDEN_EDEFAULT;
			case WebGeneratorMMPackage.PREGUNTA__CONTENT:
				return CONTENT_EDEFAULT == null ? content != null : !CONTENT_EDEFAULT.equals(content);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (numOrden: ");
		result.append(numOrden);
		result.append(", content: ");
		result.append(content);
		result.append(')');
		return result.toString();
	}

} //PreguntaImpl
