/**
 */
package WebGeneratorMM.impl;

import WebGeneratorMM.Creacion;
import WebGeneratorMM.WebGeneratorMMPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Creacion</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class CreacionImpl extends PaginaEntidadImpl implements Creacion {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CreacionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WebGeneratorMMPackage.Literals.CREACION;
	}

} //CreacionImpl
