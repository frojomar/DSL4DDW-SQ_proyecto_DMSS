/**
 */
package WebGeneratorMM.impl;

import WebGeneratorMM.Atributo;
import WebGeneratorMM.Borrado;
import WebGeneratorMM.ConexionRedSocial;
import WebGeneratorMM.Creacion;
import WebGeneratorMM.Cuestionario;
import WebGeneratorMM.Detalle;
import WebGeneratorMM.Encuesta;
import WebGeneratorMM.Enlace;
import WebGeneratorMM.EnlaceExterno;
import WebGeneratorMM.EnlaceInterno;
import WebGeneratorMM.Entidad;
import WebGeneratorMM.Indice;
import WebGeneratorMM.Opcion;
import WebGeneratorMM.PaginaCRUD;
import WebGeneratorMM.PaginaEncForm;
import WebGeneratorMM.PaginaEntidad;
import WebGeneratorMM.PaginaHome;
import WebGeneratorMM.PaginaWeb;
import WebGeneratorMM.Pregunta;
import WebGeneratorMM.PreguntaCorta;
import WebGeneratorMM.PreguntaElegir;
import WebGeneratorMM.PreguntaVF;
import WebGeneratorMM.Referencia;
import WebGeneratorMM.SitioWeb;
import WebGeneratorMM.WebGeneratorMMFactory;
import WebGeneratorMM.WebGeneratorMMPackage;

import WebGeneratorMM.util.WebGeneratorMMValidator;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EValidator;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class WebGeneratorMMPackageImpl extends EPackageImpl implements WebGeneratorMMPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sitioWebEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass paginaWebEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass entidadEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass referenciaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass atributoEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass indiceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass paginaCRUDEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass paginaEncFormEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass paginaHomeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass conexionRedSocialEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass preguntaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass preguntaCortaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass preguntaElegirEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass preguntaVFEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass encuestaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cuestionarioEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass enlaceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass enlaceExternoEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass enlaceInternoEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass opcionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass detalleEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass borradoEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass creacionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass paginaEntidadEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum reptypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum atrtypeEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see WebGeneratorMM.WebGeneratorMMPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private WebGeneratorMMPackageImpl() {
		super(eNS_URI, WebGeneratorMMFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link WebGeneratorMMPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static WebGeneratorMMPackage init() {
		if (isInited) return (WebGeneratorMMPackage)EPackage.Registry.INSTANCE.getEPackage(WebGeneratorMMPackage.eNS_URI);

		// Obtain or create and register package
		WebGeneratorMMPackageImpl theWebGeneratorMMPackage = (WebGeneratorMMPackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof WebGeneratorMMPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new WebGeneratorMMPackageImpl());

		isInited = true;

		// Create package meta-data objects
		theWebGeneratorMMPackage.createPackageContents();

		// Initialize created meta-data
		theWebGeneratorMMPackage.initializePackageContents();

		// Register package validator
		EValidator.Registry.INSTANCE.put
			(theWebGeneratorMMPackage, 
			 new EValidator.Descriptor() {
				 public EValidator getEValidator() {
					 return WebGeneratorMMValidator.INSTANCE;
				 }
			 });

		// Mark meta-data to indicate it can't be changed
		theWebGeneratorMMPackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(WebGeneratorMMPackage.eNS_URI, theWebGeneratorMMPackage);
		return theWebGeneratorMMPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSitioWeb() {
		return sitioWebEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSitioWeb_EntidadesModelo() {
		return (EReference)sitioWebEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSitioWeb_Paginasweb() {
		return (EReference)sitioWebEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSitioWeb_Name() {
		return (EAttribute)sitioWebEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSitioWeb_Image() {
		return (EAttribute)sitioWebEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPaginaWeb() {
		return paginaWebEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPaginaWeb_Name() {
		return (EAttribute)paginaWebEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPaginaWeb_Conexionredsocial() {
		return (EReference)paginaWebEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPaginaWeb_Enlaces() {
		return (EReference)paginaWebEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEntidad() {
		return entidadEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEntidad_Referencias() {
		return (EReference)entidadEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEntidad_Atributos() {
		return (EReference)entidadEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEntidad_Name() {
		return (EAttribute)entidadEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getReferencia() {
		return referenciaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getReferencia_Destino() {
		return (EReference)referenciaEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getReferencia_Name() {
		return (EAttribute)referenciaEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getReferencia_Muchas() {
		return (EAttribute)referenciaEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAtributo() {
		return atributoEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAtributo_Type() {
		return (EAttribute)atributoEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAtributo_Name() {
		return (EAttribute)atributoEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getIndice() {
		return indiceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPaginaCRUD() {
		return paginaCRUDEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPaginaEncForm() {
		return paginaEncFormEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPaginaEncForm_Preguntas() {
		return (EReference)paginaEncFormEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPaginaHome() {
		return paginaHomeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getConexionRedSocial() {
		return conexionRedSocialEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getConexionRedSocial_Script() {
		return (EAttribute)conexionRedSocialEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getConexionRedSocial_Tag() {
		return (EAttribute)conexionRedSocialEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPregunta() {
		return preguntaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPregunta_NumOrden() {
		return (EAttribute)preguntaEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPregunta_Content() {
		return (EAttribute)preguntaEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPreguntaCorta() {
		return preguntaCortaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPreguntaCorta_Solucion() {
		return (EAttribute)preguntaCortaEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPreguntaElegir() {
		return preguntaElegirEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPreguntaElegir_Opciones() {
		return (EReference)preguntaElegirEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPreguntaVF() {
		return preguntaVFEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPreguntaVF_Solucion() {
		return (EAttribute)preguntaVFEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEncuesta() {
		return encuestaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEncuesta_Representacion() {
		return (EAttribute)encuestaEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCuestionario() {
		return cuestionarioEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEnlace() {
		return enlaceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEnlace_Name() {
		return (EAttribute)enlaceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEnlaceExterno() {
		return enlaceExternoEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEnlaceExterno_Url() {
		return (EAttribute)enlaceExternoEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEnlaceInterno() {
		return enlaceInternoEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEnlaceInterno_Referencia() {
		return (EReference)enlaceInternoEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOpcion() {
		return opcionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOpcion_Content() {
		return (EAttribute)opcionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOpcion_Correcta() {
		return (EAttribute)opcionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDetalle() {
		return detalleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBorrado() {
		return borradoEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCreacion() {
		return creacionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPaginaEntidad() {
		return paginaEntidadEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPaginaEntidad_Entidad() {
		return (EReference)paginaEntidadEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getREPTYPE() {
		return reptypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getATRTYPE() {
		return atrtypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WebGeneratorMMFactory getWebGeneratorMMFactory() {
		return (WebGeneratorMMFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		sitioWebEClass = createEClass(SITIO_WEB);
		createEReference(sitioWebEClass, SITIO_WEB__ENTIDADES_MODELO);
		createEReference(sitioWebEClass, SITIO_WEB__PAGINASWEB);
		createEAttribute(sitioWebEClass, SITIO_WEB__NAME);
		createEAttribute(sitioWebEClass, SITIO_WEB__IMAGE);

		paginaWebEClass = createEClass(PAGINA_WEB);
		createEAttribute(paginaWebEClass, PAGINA_WEB__NAME);
		createEReference(paginaWebEClass, PAGINA_WEB__CONEXIONREDSOCIAL);
		createEReference(paginaWebEClass, PAGINA_WEB__ENLACES);

		entidadEClass = createEClass(ENTIDAD);
		createEReference(entidadEClass, ENTIDAD__REFERENCIAS);
		createEReference(entidadEClass, ENTIDAD__ATRIBUTOS);
		createEAttribute(entidadEClass, ENTIDAD__NAME);

		referenciaEClass = createEClass(REFERENCIA);
		createEReference(referenciaEClass, REFERENCIA__DESTINO);
		createEAttribute(referenciaEClass, REFERENCIA__NAME);
		createEAttribute(referenciaEClass, REFERENCIA__MUCHAS);

		atributoEClass = createEClass(ATRIBUTO);
		createEAttribute(atributoEClass, ATRIBUTO__TYPE);
		createEAttribute(atributoEClass, ATRIBUTO__NAME);

		indiceEClass = createEClass(INDICE);

		paginaCRUDEClass = createEClass(PAGINA_CRUD);

		paginaEncFormEClass = createEClass(PAGINA_ENC_FORM);
		createEReference(paginaEncFormEClass, PAGINA_ENC_FORM__PREGUNTAS);

		paginaHomeEClass = createEClass(PAGINA_HOME);

		conexionRedSocialEClass = createEClass(CONEXION_RED_SOCIAL);
		createEAttribute(conexionRedSocialEClass, CONEXION_RED_SOCIAL__SCRIPT);
		createEAttribute(conexionRedSocialEClass, CONEXION_RED_SOCIAL__TAG);

		preguntaEClass = createEClass(PREGUNTA);
		createEAttribute(preguntaEClass, PREGUNTA__NUM_ORDEN);
		createEAttribute(preguntaEClass, PREGUNTA__CONTENT);

		preguntaCortaEClass = createEClass(PREGUNTA_CORTA);
		createEAttribute(preguntaCortaEClass, PREGUNTA_CORTA__SOLUCION);

		preguntaElegirEClass = createEClass(PREGUNTA_ELEGIR);
		createEReference(preguntaElegirEClass, PREGUNTA_ELEGIR__OPCIONES);

		preguntaVFEClass = createEClass(PREGUNTA_VF);
		createEAttribute(preguntaVFEClass, PREGUNTA_VF__SOLUCION);

		encuestaEClass = createEClass(ENCUESTA);
		createEAttribute(encuestaEClass, ENCUESTA__REPRESENTACION);

		cuestionarioEClass = createEClass(CUESTIONARIO);

		enlaceEClass = createEClass(ENLACE);
		createEAttribute(enlaceEClass, ENLACE__NAME);

		enlaceExternoEClass = createEClass(ENLACE_EXTERNO);
		createEAttribute(enlaceExternoEClass, ENLACE_EXTERNO__URL);

		enlaceInternoEClass = createEClass(ENLACE_INTERNO);
		createEReference(enlaceInternoEClass, ENLACE_INTERNO__REFERENCIA);

		opcionEClass = createEClass(OPCION);
		createEAttribute(opcionEClass, OPCION__CONTENT);
		createEAttribute(opcionEClass, OPCION__CORRECTA);

		detalleEClass = createEClass(DETALLE);

		borradoEClass = createEClass(BORRADO);

		creacionEClass = createEClass(CREACION);

		paginaEntidadEClass = createEClass(PAGINA_ENTIDAD);
		createEReference(paginaEntidadEClass, PAGINA_ENTIDAD__ENTIDAD);

		// Create enums
		reptypeEEnum = createEEnum(REPTYPE);
		atrtypeEEnum = createEEnum(ATRTYPE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		indiceEClass.getESuperTypes().add(this.getPaginaEntidad());
		paginaCRUDEClass.getESuperTypes().add(this.getPaginaEntidad());
		paginaEncFormEClass.getESuperTypes().add(this.getPaginaWeb());
		paginaHomeEClass.getESuperTypes().add(this.getPaginaWeb());
		preguntaCortaEClass.getESuperTypes().add(this.getPregunta());
		preguntaElegirEClass.getESuperTypes().add(this.getPregunta());
		preguntaVFEClass.getESuperTypes().add(this.getPregunta());
		encuestaEClass.getESuperTypes().add(this.getPaginaEncForm());
		cuestionarioEClass.getESuperTypes().add(this.getPaginaEncForm());
		enlaceExternoEClass.getESuperTypes().add(this.getEnlace());
		enlaceInternoEClass.getESuperTypes().add(this.getEnlace());
		detalleEClass.getESuperTypes().add(this.getPaginaEntidad());
		borradoEClass.getESuperTypes().add(this.getPaginaEntidad());
		creacionEClass.getESuperTypes().add(this.getPaginaEntidad());
		paginaEntidadEClass.getESuperTypes().add(this.getPaginaWeb());

		// Initialize classes and features; add operations and parameters
		initEClass(sitioWebEClass, SitioWeb.class, "SitioWeb", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getSitioWeb_EntidadesModelo(), this.getEntidad(), null, "entidadesModelo", null, 0, -1, SitioWeb.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSitioWeb_Paginasweb(), this.getPaginaWeb(), null, "paginasweb", null, 0, -1, SitioWeb.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSitioWeb_Name(), ecorePackage.getEString(), "name", null, 0, 1, SitioWeb.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSitioWeb_Image(), ecorePackage.getEString(), "image", null, 0, 1, SitioWeb.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(paginaWebEClass, PaginaWeb.class, "PaginaWeb", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPaginaWeb_Name(), ecorePackage.getEString(), "name", null, 0, 1, PaginaWeb.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPaginaWeb_Conexionredsocial(), this.getConexionRedSocial(), null, "conexionredsocial", null, 0, -1, PaginaWeb.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPaginaWeb_Enlaces(), this.getEnlace(), null, "enlaces", null, 0, -1, PaginaWeb.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(entidadEClass, Entidad.class, "Entidad", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getEntidad_Referencias(), this.getReferencia(), null, "referencias", null, 0, -1, Entidad.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEntidad_Atributos(), this.getAtributo(), null, "atributos", null, 0, -1, Entidad.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getEntidad_Name(), ecorePackage.getEString(), "name", null, 0, 1, Entidad.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(referenciaEClass, Referencia.class, "Referencia", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getReferencia_Destino(), this.getEntidad(), null, "destino", null, 1, 1, Referencia.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getReferencia_Name(), ecorePackage.getEString(), "name", null, 0, 1, Referencia.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getReferencia_Muchas(), ecorePackage.getEBoolean(), "muchas", "false", 0, 1, Referencia.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(atributoEClass, Atributo.class, "Atributo", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAtributo_Type(), this.getATRTYPE(), "type", null, 0, 1, Atributo.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAtributo_Name(), ecorePackage.getEString(), "name", null, 0, 1, Atributo.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(indiceEClass, Indice.class, "Indice", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(paginaCRUDEClass, PaginaCRUD.class, "PaginaCRUD", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(paginaEncFormEClass, PaginaEncForm.class, "PaginaEncForm", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPaginaEncForm_Preguntas(), this.getPregunta(), null, "preguntas", null, 0, -1, PaginaEncForm.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(paginaHomeEClass, PaginaHome.class, "PaginaHome", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(conexionRedSocialEClass, ConexionRedSocial.class, "ConexionRedSocial", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getConexionRedSocial_Script(), ecorePackage.getEString(), "script", null, 0, 1, ConexionRedSocial.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getConexionRedSocial_Tag(), ecorePackage.getEString(), "tag", null, 0, 1, ConexionRedSocial.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(preguntaEClass, Pregunta.class, "Pregunta", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPregunta_NumOrden(), ecorePackage.getEInt(), "numOrden", null, 0, 1, Pregunta.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPregunta_Content(), ecorePackage.getEString(), "content", null, 0, 1, Pregunta.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(preguntaCortaEClass, PreguntaCorta.class, "PreguntaCorta", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPreguntaCorta_Solucion(), ecorePackage.getEString(), "solucion", null, 0, 1, PreguntaCorta.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(preguntaElegirEClass, PreguntaElegir.class, "PreguntaElegir", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPreguntaElegir_Opciones(), this.getOpcion(), null, "opciones", null, 2, -1, PreguntaElegir.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(preguntaVFEClass, PreguntaVF.class, "PreguntaVF", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPreguntaVF_Solucion(), ecorePackage.getEBoolean(), "solucion", null, 0, 1, PreguntaVF.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(encuestaEClass, Encuesta.class, "Encuesta", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getEncuesta_Representacion(), this.getREPTYPE(), "representacion", null, 0, 1, Encuesta.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(cuestionarioEClass, Cuestionario.class, "Cuestionario", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(enlaceEClass, Enlace.class, "Enlace", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getEnlace_Name(), ecorePackage.getEString(), "name", null, 0, 1, Enlace.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(enlaceExternoEClass, EnlaceExterno.class, "EnlaceExterno", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getEnlaceExterno_Url(), ecorePackage.getEString(), "url", null, 0, 1, EnlaceExterno.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(enlaceInternoEClass, EnlaceInterno.class, "EnlaceInterno", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getEnlaceInterno_Referencia(), this.getPaginaWeb(), null, "referencia", null, 1, 1, EnlaceInterno.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(opcionEClass, Opcion.class, "Opcion", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getOpcion_Content(), ecorePackage.getEString(), "content", null, 0, 1, Opcion.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getOpcion_Correcta(), ecorePackage.getEBoolean(), "correcta", null, 0, 1, Opcion.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(detalleEClass, Detalle.class, "Detalle", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(borradoEClass, Borrado.class, "Borrado", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(creacionEClass, Creacion.class, "Creacion", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(paginaEntidadEClass, PaginaEntidad.class, "PaginaEntidad", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPaginaEntidad_Entidad(), this.getEntidad(), null, "entidad", null, 1, 1, PaginaEntidad.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(reptypeEEnum, WebGeneratorMM.REPTYPE.class, "REPTYPE");
		addEEnumLiteral(reptypeEEnum, WebGeneratorMM.REPTYPE.BARRAS);
		addEEnumLiteral(reptypeEEnum, WebGeneratorMM.REPTYPE.TEXTO);
		addEEnumLiteral(reptypeEEnum, WebGeneratorMM.REPTYPE.TARTA);

		initEEnum(atrtypeEEnum, WebGeneratorMM.ATRTYPE.class, "ATRTYPE");
		addEEnumLiteral(atrtypeEEnum, WebGeneratorMM.ATRTYPE.INTEGER);
		addEEnumLiteral(atrtypeEEnum, WebGeneratorMM.ATRTYPE.FLOAT);
		addEEnumLiteral(atrtypeEEnum, WebGeneratorMM.ATRTYPE.BOOLEAN);
		addEEnumLiteral(atrtypeEEnum, WebGeneratorMM.ATRTYPE.STRING);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// gmf
		createGmfAnnotations();
		// MyDSLDoc
		createMyDSLDocAnnotations();
		// http://www.eclipse.org/OCL/Import
		createImportAnnotations();
		// http://www.eclipse.org/emf/2002/Ecore
		createEcoreAnnotations();
		// http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot
		createPivotAnnotations();
		// gmf.diagram
		createGmf_1Annotations();
		// gmf.node
		createGmf_2Annotations();
		// gmf.compartment
		createGmf_3Annotations();
		// gmf.link
		createGmf_4Annotations();
	}

	/**
	 * Initializes the annotations for <b>gmf</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createGmfAnnotations() {
		String source = "gmf";	
		addAnnotation
		  (this, 
		   source, 
		   new String[] {
		   });
	}

	/**
	 * Initializes the annotations for <b>MyDSLDoc</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createMyDSLDocAnnotations() {
		String source = "MyDSLDoc";	
		addAnnotation
		  (this, 
		   source, 
		   new String[] {
			 "Author", "Ruben Rentero Trejo, Francisco Javier Rojo Mart\u00edn"
		   });	
		addAnnotation
		  (sitioWebEClass, 
		   source, 
		   new String[] {
			 "Description", "Elemento Root del metamodelo que define el sitio que se va a modelar. Contiene tanto las p\u00e1ginas web a dise\u00f1ar como las entidades que se utilizar\u00e1n en ellas."
		   });	
		addAnnotation
		  (paginaWebEClass, 
		   source, 
		   new String[] {
			 "Description", "Elemento p\u00e1gina web que se traducir\u00e1 en una p\u00e1gina web real en HTML.\nUna p\u00e1gina web puede convertirse en la p\u00e1gina Home del sitio, una p\u00e1gina de entidad, o un formulario de recogida de datos.\nCada p\u00e1gina web contiene una serie de enlaces (internos o externos) y da la opci\u00f3n de establecer una conexi\u00f3n hacia una red social."
		   });	
		addAnnotation
		  (entidadEClass, 
		   source, 
		   new String[] {
			 "Description", "Representaci\u00f3n de un objeto o un concepto del mundo real. Ser\u00e1n clases que poseen un nombre para identificarlas junto con una serie de atributos y m\u00e9todos."
		   });	
		addAnnotation
		  (referenciaEClass, 
		   source, 
		   new String[] {
			 "Description", "Indica la relaci\u00f3n entre una clase origen y un destino. Se identificar\u00e1 con un nombre y posee un atributo para indicar si la cardinalidad del destino es 1 o N."
		   });	
		addAnnotation
		  (atributoEClass, 
		   source, 
		   new String[] {
			 "Description", "Representan variables de instancia, definidas con un tipo y un nombre. Cada objeto particular tendr\u00e1 valores distintos para estas variables."
		   });	
		addAnnotation
		  (indiceEClass, 
		   source, 
		   new String[] {
			 "Description", "Hereda de PaginaEntidad. Representa la p\u00e1gina \u00edndice donde se podr\u00e1n encontrar todas las referencias al resto de p\u00e1ginas para facilitar su ubicaci\u00f3n y f\u00e1cil acceso."
		   });	
		addAnnotation
		  (paginaCRUDEClass, 
		   source, 
		   new String[] {
			 "Description", "Representa una p\u00e1gina CRUD que se utiliza para las conexiones con la base de datos. Al ser CRUD, las opciones que se ofrecen son: Create, Read, Update y Delete. Al especificar este tipo de p\u00e1gina se crean las 4 p\u00e1ginas CRUD al mismo tiempo."
		   });	
		addAnnotation
		  (paginaEncFormEClass, 
		   source, 
		   new String[] {
			 "Description", "P\u00e1gina de recogida de datos introducidos por el usuario. Es una clase abstracta que se convierte en una Encuesta o en un Formulario. Est\u00e1 compuesta por una serie de preguntas que se realizan al usuario."
		   });	
		addAnnotation
		  (paginaHomeEClass, 
		   source, 
		   new String[] {
			 "Description", "P\u00e1gina principal del Sitio Web (index). Ser\u00e1 la primera p\u00e1gina a la que acceder\u00e1 un usuario al entrar al sitio."
		   });	
		addAnnotation
		  (conexionRedSocialEClass, 
		   source, 
		   new String[] {
			 "Description", "Contiene la informaci\u00f3n necesaria para establecer una conexi\u00f3n hacia una Red Social. Posee un atributo \\\"tag\\\" para identificar la red social destino, as\u00ed como un campo \\\"script\\\" donde se introduce el script particular predefinido que ofrecen las distintas redes sociales para facilitar su acceso."
		   });	
		addAnnotation
		  (preguntaEClass, 
		   source, 
		   new String[] {
			 "Description", "Clase abstracta que se materializa en una pregunta corta, una pregunta de elecci\u00f3n m\u00faltiple o una pregunta de verdadero/falso."
		   });	
		addAnnotation
		  (preguntaCortaEClass, 
		   source, 
		   new String[] {
			 "Description", "Se ofrece un texto con una pregunta al usuario y se da la opci\u00f3n de predefinir una soluci\u00f3n a dicha pregunta."
		   });	
		addAnnotation
		  (preguntaElegirEClass, 
		   source, 
		   new String[] {
			 "Description", "Se ofrece un texto con una pregunta para el usuario. Las respuestas a dicha pregunta ser\u00e1n una serie de opciones de las cuales s\u00f3lo se puede seleccionar una."
		   });	
		addAnnotation
		  (preguntaVFEClass, 
		   source, 
		   new String[] {
			 "Description", "Se ofrece un texto con una pregunta al usuario y la respuesta ser\u00e1 \u00fanicamente verdadero o falso."
		   });	
		addAnnotation
		  (encuestaEClass, 
		   source, 
		   new String[] {
			 "Description", "Representa un gr\u00e1fico donde se recoge la informaci\u00f3n de los cuestionarios (puntuaciones, edades, etc.)"
		   });	
		addAnnotation
		  (cuestionarioEClass, 
		   source, 
		   new String[] {
			 "Description", "Representa al conjunto de cuestiones o preguntas que ser\u00e1n contestadas por el usuario."
		   });	
		addAnnotation
		  (enlaceEClass, 
		   source, 
		   new String[] {
			 "Description", "Elemento que establece una conexi\u00f3n entre dos elementos del sitio web (enlace interno) o entre un elemento del sitio web y un elemento externo (enlace externo)."
		   });	
		addAnnotation
		  (enlaceExternoEClass, 
		   source, 
		   new String[] {
			 "Description", "Establece una conexi\u00f3n con un elemento externo al sitio web. En la URL se especifica la direcci\u00f3n del elemento."
		   });	
		addAnnotation
		  (enlaceInternoEClass, 
		   source, 
		   new String[] {
			 "Description", "Relaciona elementos pertenecientes al propio sitio web. En el campo \\\"referencia\\\" se indica la direcci\u00f3n destino."
		   });	
		addAnnotation
		  (opcionEClass, 
		   source, 
		   new String[] {
			 "Description", "Ofrece una descripci\u00f3n para detallar la opci\u00f3n y un atributo para especificar si es la opci\u00f3n correcta a la pregunta o no."
		   });	
		addAnnotation
		  (detalleEClass, 
		   source, 
		   new String[] {
			 "Description", "Lee informaci\u00f3n de la BD y la muestra en la p\u00e1gina."
		   });	
		addAnnotation
		  (borradoEClass, 
		   source, 
		   new String[] {
			 "Description", "P\u00e1gina donde se especifican los elementos de las entidades a borrar."
		   });	
		addAnnotation
		  (creacionEClass, 
		   source, 
		   new String[] {
			 "Description", "P\u00e1gina que ofrece las herramientas necesarias para la creaci\u00f3n de un nuevo elemento entidad."
		   });	
		addAnnotation
		  (paginaEntidadEClass, 
		   source, 
		   new String[] {
			 "Description", "Representa el conjunto de p\u00e1ginas: Creaci\u00f3n, borrado, detalle, \u00edndice y CRUD. Esta clase abstracta se convertir\u00e1 en una de ellas."
		   });
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/OCL/Import</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createImportAnnotations() {
		String source = "http://www.eclipse.org/OCL/Import";	
		addAnnotation
		  (this, 
		   source, 
		   new String[] {
			 "ecore", "http://www.eclipse.org/emf/2002/Ecore"
		   });
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createEcoreAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore";	
		addAnnotation
		  (this, 
		   source, 
		   new String[] {
			 "invocationDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
			 "settingDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
			 "validationDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot"
		   });	
		addAnnotation
		  (sitioWebEClass, 
		   source, 
		   new String[] {
			 "constraints", "sitio_debe_tener_nombre sitio_debe_tener_image no_mismo_nombre_entidades no_mismo_nombre_paginas una_pagina_home no_dos_indice_misma_entidad no_dos_detalle_misma_entidad no_dos_creacion_misma_entidad no_dos_borrado_misma_entidad no_dos_crud_misma_entidad no_crud_y_indice no_crud_y_detalle no_crud_y_creacion no_crud_y_borrado al_menos_un_cuestionario al_menos_una_encuesta indice_implica_detalle detalle_implica_indice al_menos_una_pagina_con_red_social home_enlaza_cruds_y_indices creacion_implica_indice borrado_implica_detalle ref_muchas_implica_no_muchas ref_no_muchos_unica_en_cada_entidad prohibidas_ref_no_muchos_unica_bidireccional paginas_todas_alcanzables"
		   });	
		addAnnotation
		  (paginaWebEClass, 
		   source, 
		   new String[] {
			 "constraints", "nombre_sin_espacios"
		   });	
		addAnnotation
		  (entidadEClass, 
		   source, 
		   new String[] {
			 "constraints", "name_es_string un_atributo_name id_es_integer un_atributo_id image_es_string un_atributo_image nombres_atributos_distintos nombre_sin_espacios"
		   });	
		addAnnotation
		  (referenciaEClass, 
		   source, 
		   new String[] {
			 "constraints", "nombre_sin_espacios nombre_empieza_minusculas"
		   });	
		addAnnotation
		  (atributoEClass, 
		   source, 
		   new String[] {
			 "constraints", "nombre_sin_espacios nombre_empieza_minusculas"
		   });	
		addAnnotation
		  (preguntaElegirEClass, 
		   source, 
		   new String[] {
			 "constraints", "al_menos_dos_opciones"
		   });	
		addAnnotation
		  (cuestionarioEClass, 
		   source, 
		   new String[] {
			 "constraints", "respuestas_corta_definidas respuestas_elegir_definidas respuestas_vf_definidas preguntas_elegir_solo_una_opcion_correcta"
		   });	
		addAnnotation
		  (enlaceExternoEClass, 
		   source, 
		   new String[] {
			 "constraints", "deben_comenzar_por_http"
		   });	
		addAnnotation
		  (enlaceInternoEClass, 
		   source, 
		   new String[] {
			 "constraints", "no_permitidos_a_detalle no_permitidos_a_borrado no_permitidos_a_home"
		   });	
		addAnnotation
		  (borradoEClass, 
		   source, 
		   new String[] {
			 "constraints", "no_permitidos_enlaces no_permitidas_conexiones_redSocial"
		   });	
		addAnnotation
		  (creacionEClass, 
		   source, 
		   new String[] {
			 "constraints", "no_permitidos_enlaces no_permitidas_conexiones_redSocial"
		   });
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createPivotAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot";	
		addAnnotation
		  (sitioWebEClass, 
		   source, 
		   new String[] {
			 "sitio_debe_tener_nombre", "not self.name.oclIsUndefined() and self.name<>\'\'",
			 "sitio_debe_tener_image", "not self.image.oclIsUndefined() and self.image<>\'\'",
			 "no_mismo_nombre_entidades", "self.entidadesModelo->forAll(e1, e2: Entidad | e1=e2 or e1.name<>e2.name)",
			 "no_mismo_nombre_paginas", "self.paginasweb ->forAll(p1, p2: PaginaWeb | p1=p2 or p1.name<>p2.name)",
			 "una_pagina_home", "self.paginasweb->select(oclIsTypeOf(PaginaHome))->size()=1",
			 "no_dos_indice_misma_entidad", "self.paginasweb->select(oclIsTypeOf(Indice)).oclAsType(Indice)->forAll(p1, p2: Indice| p1=p2 or p1.entidad<>p2.entidad)",
			 "no_dos_detalle_misma_entidad", "self.paginasweb->select(oclIsTypeOf(Detalle)).oclAsType(Detalle)->forAll(p1, p2: Detalle| p1=p2 or p1.entidad<>p2.entidad)",
			 "no_dos_creacion_misma_entidad", "self.paginasweb->select(oclIsTypeOf(Creacion)).oclAsType(Creacion)->forAll(p1, p2: Creacion| p1=p2 or p1.entidad<>p2.entidad)",
			 "no_dos_borrado_misma_entidad", "self.paginasweb->select(oclIsTypeOf(Borrado)).oclAsType(Borrado)->forAll(p1, p2: Borrado| p1=p2 or p1.entidad<>p2.entidad)",
			 "no_dos_crud_misma_entidad", "self.paginasweb->select(oclIsTypeOf(PaginaCRUD)).oclAsType(PaginaCRUD)->forAll(p1, p2: PaginaCRUD| p1=p2 or p1.entidad<>p2.entidad)",
			 "no_crud_y_indice", "self.paginasweb->select(oclIsTypeOf(PaginaCRUD)).oclAsType(PaginaCRUD)->forAll(pC: PaginaCRUD |\n\t\t\t\t\t\tself.paginasweb->select(oclIsTypeOf(Indice)).oclAsType(Indice)->forAll(pI: Indice| pC.entidad<>pI.entidad))",
			 "no_crud_y_detalle", "self.paginasweb->select(oclIsTypeOf(PaginaCRUD)).oclAsType(PaginaCRUD)->forAll(pC: PaginaCRUD |\n\t\t\t\t\t\tself.paginasweb->select(oclIsTypeOf(Detalle)).oclAsType(Detalle)->forAll(pD: Detalle| pC.entidad<>pD.entidad))",
			 "no_crud_y_creacion", "self.paginasweb->select(oclIsTypeOf(PaginaCRUD)).oclAsType(PaginaCRUD)->forAll(pC: PaginaCRUD |\n\t\t\t\t\t\tself.paginasweb->select(oclIsTypeOf(Creacion)).oclAsType(Creacion)->forAll(pCreacion: Creacion| pC.entidad<>pCreacion.entidad))",
			 "no_crud_y_borrado", "self.paginasweb->select(oclIsTypeOf(PaginaCRUD)).oclAsType(PaginaCRUD)->forAll(pC: PaginaCRUD |\n\t\t\t\t\t\tself.paginasweb->select(oclIsTypeOf(Borrado)).oclAsType(Borrado)->forAll(pB: Borrado| pC.entidad<>pB.entidad))",
			 "al_menos_un_cuestionario", "self.paginasweb->select(oclIsTypeOf(Cuestionario))->size()>=1",
			 "al_menos_una_encuesta", "self.paginasweb->select(oclIsTypeOf(Encuesta))->size()>=1",
			 "indice_implica_detalle", "self.paginasweb->select(oclIsTypeOf(Indice)).oclAsType(Indice)->forAll(pI: Indice| \n\t\t\t\t\t\tself.paginasweb->select(oclIsTypeOf(Detalle)).oclAsType(Detalle)->exists(pD: Detalle| pI.entidad=pD.entidad))",
			 "detalle_implica_indice", "self.paginasweb->select(oclIsTypeOf(Detalle)).oclAsType(Detalle)->forAll(pD: Detalle| \n\t\t\t\t\t\tself.paginasweb->select(oclIsTypeOf(Indice)).oclAsType(Indice)->exists(pI: Indice| pD.entidad=pI.entidad))",
			 "al_menos_una_pagina_con_red_social", "self.paginasweb->select(conexionredsocial->size()>=1)->size()>=1",
			 "home_enlaza_cruds_y_indices", "self.paginasweb->select(oclIsTypeOf(Indice) or oclIsTypeOf(PaginaCRUD))->\n\t\t\tforAll(p | self.paginasweb->select(oclIsTypeOf(PaginaHome)).enlaces->select(e|e.oclIsTypeOf(EnlaceInterno))->\n\t\t\t\tselect(e| e.oclAsType(EnlaceInterno).referencia=p)->size()>0\n\t\t\t)",
			 "creacion_implica_indice", "self.paginasweb->select(oclIsTypeOf(Creacion)).oclAsType(Creacion)->forAll(pC: Creacion| \n\t\t\t\t\t\tself.paginasweb->select(oclIsTypeOf(Indice)).oclAsType(Indice)->exists(pI: Indice| pC.entidad=pI.entidad))",
			 "borrado_implica_detalle", "self.paginasweb->select(oclIsTypeOf(Borrado)).oclAsType(Borrado)->forAll(pB: Borrado| \n\t\t\t\t\t\tself.paginasweb->select(oclIsTypeOf(Detalle)).oclAsType(Detalle)->exists(pD: Detalle| pB.entidad=pD.entidad))",
			 "ref_muchas_implica_no_muchas", "self.entidadesModelo->forAll(e:Entidad | e.referencias->select(muchas=true)->\n\t\t\tforAll(r:Referencia| r.destino.referencias->exists(r2:Referencia|r2.destino=e and r2.muchas=false)))",
			 "ref_no_muchos_unica_en_cada_entidad", "self.entidadesModelo->forAll(e:Entidad | e.referencias->select(muchas=false)->\n\t\t\tforAll(r1,r2 | r1=r2 or r1.destino<>r2.destino))",
			 "prohibidas_ref_no_muchos_unica_bidireccional", "self.entidadesModelo->forAll(e:Entidad | e.referencias->select(muchas=false)->\n\t\t\tforAll(r:Referencia| not r.destino.referencias->exists(r2:Referencia|r2.destino=e and r2.muchas=false)))",
			 "paginas_todas_alcanzables", "self.paginasweb->select(oclIsTypeOf(Indice) or oclIsTypeOf(PaginaCRUD) or oclIsKindOf(PaginaEncForm))->\n\t\t\tforAll(p|self.paginasweb.enlaces->select(oclIsTypeOf(EnlaceInterno)).oclAsType(EnlaceInterno)->\n\t\t\t\tselect(referencia=p)->size()>=1)"
		   });	
		addAnnotation
		  (paginaWebEClass, 
		   source, 
		   new String[] {
			 "nombre_sin_espacios", "self.name=self.name.replaceAll(\' \',\'\')"
		   });	
		addAnnotation
		  (entidadEClass, 
		   source, 
		   new String[] {
			 "name_es_string", "self.atributos->select(name=\'name\')->forAll(type=ATRTYPE::String)",
			 "un_atributo_name", "self.atributos->select(name=\'name\')->size()=1",
			 "id_es_integer", "self.atributos->select(name=(\'id_\'.concat(self.name)))->forAll(type=ATRTYPE::Integer)",
			 "un_atributo_id", "self.atributos->select(name=(\'id_\'.concat(self.name)))->size()=1",
			 "image_es_string", "self.atributos->select(name=\'image\')->forAll(type=ATRTYPE::String)",
			 "un_atributo_image", "self.atributos->select(name=\'image\')->size()=1",
			 "nombres_atributos_distintos", "self.atributos->forAll(a1, a2: Atributo | a1=a2 or a1.name<>a2.name)",
			 "nombre_sin_espacios", "self.name=self.name.replaceAll(\' \',\'\')"
		   });	
		addAnnotation
		  (referenciaEClass, 
		   source, 
		   new String[] {
			 "nombre_sin_espacios", "self.name=self.name.replaceAll(\' \',\'\')",
			 "nombre_empieza_minusculas", "self.name.substring(1,1).toLower()=self.name.substring(1,1)"
		   });	
		addAnnotation
		  (atributoEClass, 
		   source, 
		   new String[] {
			 "nombre_sin_espacios", "self.name=self.name.replaceAll(\' \',\'\')",
			 "nombre_empieza_minusculas", "self.name.substring(1,1).toLower()=self.name.substring(1,1)"
		   });	
		addAnnotation
		  (preguntaElegirEClass, 
		   source, 
		   new String[] {
			 "al_menos_dos_opciones", "self.opciones->size()>1"
		   });	
		addAnnotation
		  (cuestionarioEClass, 
		   source, 
		   new String[] {
			 "respuestas_corta_definidas", "self.preguntas->select(oclIsTypeOf(PreguntaCorta)).oclAsType(PreguntaCorta)->\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tforAll(not solucion.oclIsUndefined() and solucion<>\'\')",
			 "respuestas_elegir_definidas", "self.preguntas->select(oclIsTypeOf(PreguntaElegir)).oclAsType(PreguntaElegir)->\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tforAll(p: PreguntaElegir| p.opciones ->forAll(correcta=false or correcta=true))",
			 "respuestas_vf_definidas", "self.preguntas->select(oclIsTypeOf(PreguntaVF)).oclAsType(PreguntaVF)->\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tforAll(solucion=false or solucion=true)",
			 "preguntas_elegir_solo_una_opcion_correcta", "self.preguntas->select(oclIsTypeOf(PreguntaElegir)).\n\t\t\t\t\toclAsType(PreguntaElegir)->forAll(opciones->select(correcta=true)->size()=1)"
		   });	
		addAnnotation
		  (enlaceExternoEClass, 
		   source, 
		   new String[] {
			 "deben_comenzar_por_http", "self.url.startsWith(\'http\')"
		   });	
		addAnnotation
		  (enlaceInternoEClass, 
		   source, 
		   new String[] {
			 "no_permitidos_a_detalle", "not self.referencia.oclIsTypeOf(Detalle)",
			 "no_permitidos_a_borrado", "not self.referencia.oclIsTypeOf(Borrado)",
			 "no_permitidos_a_home", "not self.referencia.oclIsTypeOf(PaginaHome)"
		   });	
		addAnnotation
		  (borradoEClass, 
		   source, 
		   new String[] {
			 "no_permitidos_enlaces", "self.enlaces->size()=0",
			 "no_permitidas_conexiones_redSocial", "self.conexionredsocial->size()=0"
		   });	
		addAnnotation
		  (creacionEClass, 
		   source, 
		   new String[] {
			 "no_permitidos_enlaces", "self.enlaces->size()=0",
			 "no_permitidas_conexiones_redSocial", "self.conexionredsocial->size()=0"
		   });
	}

	/**
	 * Initializes the annotations for <b>gmf.diagram</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createGmf_1Annotations() {
		String source = "gmf.diagram";	
		addAnnotation
		  (sitioWebEClass, 
		   source, 
		   new String[] {
		   });
	}

	/**
	 * Initializes the annotations for <b>gmf.node</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createGmf_2Annotations() {
		String source = "gmf.node";	
		addAnnotation
		  (paginaWebEClass, 
		   source, 
		   new String[] {
			 "label", "name",
			 "color", "255,206,147",
			 "border.width", "3",
			 "border.style", "solid"
		   });	
		addAnnotation
		  (entidadEClass, 
		   source, 
		   new String[] {
			 "label", "name",
			 "color", "249,247,112",
			 "border.width", "3",
			 "border.style", "solid"
		   });	
		addAnnotation
		  (referenciaEClass, 
		   source, 
		   new String[] {
			 "label", "name"
		   });	
		addAnnotation
		  (atributoEClass, 
		   source, 
		   new String[] {
			 "label", "name",
			 "border.width", "1",
			 "border.color", "252,78,78",
			 "border.style", "solid"
		   });	
		addAnnotation
		  (indiceEClass, 
		   source, 
		   new String[] {
			 "label", "name",
			 "color", "170,242,152"
		   });	
		addAnnotation
		  (paginaCRUDEClass, 
		   source, 
		   new String[] {
			 "label", "name",
			 "color", "170,242,152"
		   });	
		addAnnotation
		  (paginaHomeEClass, 
		   source, 
		   new String[] {
			 "label", "name",
			 "figure", "svg",
			 "svg.uri", "platform:/plugin/dmss.dsl4ddwsq/img/home.svg"
		   });	
		addAnnotation
		  (conexionRedSocialEClass, 
		   source, 
		   new String[] {
			 "label", "tag",
			 "color", "229,251,252",
			 "border.width", "1",
			 "border.style", "dot"
		   });	
		addAnnotation
		  (preguntaCortaEClass, 
		   source, 
		   new String[] {
			 "label", "content",
			 "color", "197,225,234"
		   });	
		addAnnotation
		  (preguntaElegirEClass, 
		   source, 
		   new String[] {
			 "label", "content",
			 "color", "197,225,234"
		   });	
		addAnnotation
		  (preguntaVFEClass, 
		   source, 
		   new String[] {
			 "label", "content",
			 "color", "197,225,234"
		   });	
		addAnnotation
		  (encuestaEClass, 
		   source, 
		   new String[] {
			 "label", "name",
			 "color", "137,223,249"
		   });	
		addAnnotation
		  (cuestionarioEClass, 
		   source, 
		   new String[] {
			 "label", "name",
			 "color", "137,223,249"
		   });	
		addAnnotation
		  (enlaceExternoEClass, 
		   source, 
		   new String[] {
			 "label", "name",
			 "color", "229,251,252",
			 "border.width", "1",
			 "border.style", "dot"
		   });	
		addAnnotation
		  (enlaceInternoEClass, 
		   source, 
		   new String[] {
			 "label", "name",
			 "color", "229,251,252",
			 "border.width", "1",
			 "border.style", "dot"
		   });	
		addAnnotation
		  (opcionEClass, 
		   source, 
		   new String[] {
			 "label", "content"
		   });	
		addAnnotation
		  (detalleEClass, 
		   source, 
		   new String[] {
			 "label", "name",
			 "color", "170,242,152"
		   });	
		addAnnotation
		  (borradoEClass, 
		   source, 
		   new String[] {
			 "label", "name",
			 "color", "170,242,152"
		   });	
		addAnnotation
		  (creacionEClass, 
		   source, 
		   new String[] {
			 "label", "name",
			 "color", "170,242,152"
		   });
	}

	/**
	 * Initializes the annotations for <b>gmf.compartment</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createGmf_3Annotations() {
		String source = "gmf.compartment";	
		addAnnotation
		  (getPaginaWeb_Conexionredsocial(), 
		   source, 
		   new String[] {
			 "foo", "bar",
			 "layout", "list"
		   });	
		addAnnotation
		  (getPaginaWeb_Enlaces(), 
		   source, 
		   new String[] {
			 "foo", "bar",
			 "layout", "list"
		   });	
		addAnnotation
		  (getEntidad_Referencias(), 
		   source, 
		   new String[] {
			 "foo", "bar",
			 "layout", "list"
		   });	
		addAnnotation
		  (getEntidad_Atributos(), 
		   source, 
		   new String[] {
			 "foo", "bar",
			 "layout", "list"
		   });	
		addAnnotation
		  (getPaginaEncForm_Preguntas(), 
		   source, 
		   new String[] {
			 "foo", "bar",
			 "layout", "list"
		   });	
		addAnnotation
		  (getPreguntaElegir_Opciones(), 
		   source, 
		   new String[] {
			 "foo", "bar",
			 "layout", "list"
		   });
	}

	/**
	 * Initializes the annotations for <b>gmf.link</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createGmf_4Annotations() {
		String source = "gmf.link";	
		addAnnotation
		  (getReferencia_Destino(), 
		   source, 
		   new String[] {
			 "target.decoration", "arrow",
			 "color", "178,140,1",
			 "style", "dash",
			 "tool.name", "Entidad a Entidad"
		   });	
		addAnnotation
		  (getEnlaceInterno_Referencia(), 
		   source, 
		   new String[] {
			 "target.decoration", "arrow",
			 "style", "dash",
			 "tool.name", "Enlace interno a pagina"
		   });	
		addAnnotation
		  (getPaginaEntidad_Entidad(), 
		   source, 
		   new String[] {
			 "target.decoration", "square",
			 "style", "dash",
			 "tool.name", "Pagina de Entidad"
		   });
	}

} //WebGeneratorMMPackageImpl
