/**
 */
package WebGeneratorMM.impl;

import WebGeneratorMM.Cuestionario;
import WebGeneratorMM.WebGeneratorMMPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Cuestionario</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class CuestionarioImpl extends PaginaEncFormImpl implements Cuestionario {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CuestionarioImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WebGeneratorMMPackage.Literals.CUESTIONARIO;
	}

} //CuestionarioImpl
