/**
 */
package WebGeneratorMM.impl;

import WebGeneratorMM.Indice;
import WebGeneratorMM.WebGeneratorMMPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Indice</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class IndiceImpl extends PaginaEntidadImpl implements Indice {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected IndiceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WebGeneratorMMPackage.Literals.INDICE;
	}

} //IndiceImpl
