/**
 */
package WebGeneratorMM.impl;

import WebGeneratorMM.PreguntaVF;
import WebGeneratorMM.WebGeneratorMMPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Pregunta VF</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link WebGeneratorMM.impl.PreguntaVFImpl#isSolucion <em>Solucion</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PreguntaVFImpl extends PreguntaImpl implements PreguntaVF {
	/**
	 * The default value of the '{@link #isSolucion() <em>Solucion</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSolucion()
	 * @generated
	 * @ordered
	 */
	protected static final boolean SOLUCION_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isSolucion() <em>Solucion</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSolucion()
	 * @generated
	 * @ordered
	 */
	protected boolean solucion = SOLUCION_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PreguntaVFImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WebGeneratorMMPackage.Literals.PREGUNTA_VF;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSolucion() {
		return solucion;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSolucion(boolean newSolucion) {
		boolean oldSolucion = solucion;
		solucion = newSolucion;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WebGeneratorMMPackage.PREGUNTA_VF__SOLUCION, oldSolucion, solucion));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case WebGeneratorMMPackage.PREGUNTA_VF__SOLUCION:
				return isSolucion();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case WebGeneratorMMPackage.PREGUNTA_VF__SOLUCION:
				setSolucion((Boolean)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case WebGeneratorMMPackage.PREGUNTA_VF__SOLUCION:
				setSolucion(SOLUCION_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case WebGeneratorMMPackage.PREGUNTA_VF__SOLUCION:
				return solucion != SOLUCION_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (solucion: ");
		result.append(solucion);
		result.append(')');
		return result.toString();
	}

} //PreguntaVFImpl
