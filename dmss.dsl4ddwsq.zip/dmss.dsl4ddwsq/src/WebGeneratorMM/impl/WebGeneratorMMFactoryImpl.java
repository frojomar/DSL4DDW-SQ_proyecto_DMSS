/**
 */
package WebGeneratorMM.impl;

import WebGeneratorMM.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class WebGeneratorMMFactoryImpl extends EFactoryImpl implements WebGeneratorMMFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static WebGeneratorMMFactory init() {
		try {
			WebGeneratorMMFactory theWebGeneratorMMFactory = (WebGeneratorMMFactory)EPackage.Registry.INSTANCE.getEFactory(WebGeneratorMMPackage.eNS_URI);
			if (theWebGeneratorMMFactory != null) {
				return theWebGeneratorMMFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new WebGeneratorMMFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WebGeneratorMMFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case WebGeneratorMMPackage.SITIO_WEB: return createSitioWeb();
			case WebGeneratorMMPackage.ENTIDAD: return createEntidad();
			case WebGeneratorMMPackage.REFERENCIA: return createReferencia();
			case WebGeneratorMMPackage.ATRIBUTO: return createAtributo();
			case WebGeneratorMMPackage.INDICE: return createIndice();
			case WebGeneratorMMPackage.PAGINA_CRUD: return createPaginaCRUD();
			case WebGeneratorMMPackage.PAGINA_HOME: return createPaginaHome();
			case WebGeneratorMMPackage.CONEXION_RED_SOCIAL: return createConexionRedSocial();
			case WebGeneratorMMPackage.PREGUNTA_CORTA: return createPreguntaCorta();
			case WebGeneratorMMPackage.PREGUNTA_ELEGIR: return createPreguntaElegir();
			case WebGeneratorMMPackage.PREGUNTA_VF: return createPreguntaVF();
			case WebGeneratorMMPackage.ENCUESTA: return createEncuesta();
			case WebGeneratorMMPackage.CUESTIONARIO: return createCuestionario();
			case WebGeneratorMMPackage.ENLACE_EXTERNO: return createEnlaceExterno();
			case WebGeneratorMMPackage.ENLACE_INTERNO: return createEnlaceInterno();
			case WebGeneratorMMPackage.OPCION: return createOpcion();
			case WebGeneratorMMPackage.DETALLE: return createDetalle();
			case WebGeneratorMMPackage.BORRADO: return createBorrado();
			case WebGeneratorMMPackage.CREACION: return createCreacion();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
			case WebGeneratorMMPackage.REPTYPE:
				return createREPTYPEFromString(eDataType, initialValue);
			case WebGeneratorMMPackage.ATRTYPE:
				return createATRTYPEFromString(eDataType, initialValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
			case WebGeneratorMMPackage.REPTYPE:
				return convertREPTYPEToString(eDataType, instanceValue);
			case WebGeneratorMMPackage.ATRTYPE:
				return convertATRTYPEToString(eDataType, instanceValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SitioWeb createSitioWeb() {
		SitioWebImpl sitioWeb = new SitioWebImpl();
		return sitioWeb;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Entidad createEntidad() {
		EntidadImpl entidad = new EntidadImpl();
		return entidad;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Referencia createReferencia() {
		ReferenciaImpl referencia = new ReferenciaImpl();
		return referencia;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Atributo createAtributo() {
		AtributoImpl atributo = new AtributoImpl();
		return atributo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Indice createIndice() {
		IndiceImpl indice = new IndiceImpl();
		return indice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PaginaCRUD createPaginaCRUD() {
		PaginaCRUDImpl paginaCRUD = new PaginaCRUDImpl();
		return paginaCRUD;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PaginaHome createPaginaHome() {
		PaginaHomeImpl paginaHome = new PaginaHomeImpl();
		return paginaHome;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConexionRedSocial createConexionRedSocial() {
		ConexionRedSocialImpl conexionRedSocial = new ConexionRedSocialImpl();
		return conexionRedSocial;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PreguntaCorta createPreguntaCorta() {
		PreguntaCortaImpl preguntaCorta = new PreguntaCortaImpl();
		return preguntaCorta;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PreguntaElegir createPreguntaElegir() {
		PreguntaElegirImpl preguntaElegir = new PreguntaElegirImpl();
		return preguntaElegir;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PreguntaVF createPreguntaVF() {
		PreguntaVFImpl preguntaVF = new PreguntaVFImpl();
		return preguntaVF;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Encuesta createEncuesta() {
		EncuestaImpl encuesta = new EncuestaImpl();
		return encuesta;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Cuestionario createCuestionario() {
		CuestionarioImpl cuestionario = new CuestionarioImpl();
		return cuestionario;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EnlaceExterno createEnlaceExterno() {
		EnlaceExternoImpl enlaceExterno = new EnlaceExternoImpl();
		return enlaceExterno;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EnlaceInterno createEnlaceInterno() {
		EnlaceInternoImpl enlaceInterno = new EnlaceInternoImpl();
		return enlaceInterno;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Opcion createOpcion() {
		OpcionImpl opcion = new OpcionImpl();
		return opcion;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Detalle createDetalle() {
		DetalleImpl detalle = new DetalleImpl();
		return detalle;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Borrado createBorrado() {
		BorradoImpl borrado = new BorradoImpl();
		return borrado;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Creacion createCreacion() {
		CreacionImpl creacion = new CreacionImpl();
		return creacion;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public REPTYPE createREPTYPEFromString(EDataType eDataType, String initialValue) {
		REPTYPE result = REPTYPE.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertREPTYPEToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ATRTYPE createATRTYPEFromString(EDataType eDataType, String initialValue) {
		ATRTYPE result = ATRTYPE.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertATRTYPEToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WebGeneratorMMPackage getWebGeneratorMMPackage() {
		return (WebGeneratorMMPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static WebGeneratorMMPackage getPackage() {
		return WebGeneratorMMPackage.eINSTANCE;
	}

} //WebGeneratorMMFactoryImpl
