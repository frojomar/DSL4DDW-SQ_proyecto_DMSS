/**
 */
package WebGeneratorMM.impl;

import WebGeneratorMM.PaginaHome;
import WebGeneratorMM.WebGeneratorMMPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Pagina Home</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PaginaHomeImpl extends PaginaWebImpl implements PaginaHome {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PaginaHomeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WebGeneratorMMPackage.Literals.PAGINA_HOME;
	}

} //PaginaHomeImpl
