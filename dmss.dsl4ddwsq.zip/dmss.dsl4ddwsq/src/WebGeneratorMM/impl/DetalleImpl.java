/**
 */
package WebGeneratorMM.impl;

import WebGeneratorMM.Detalle;
import WebGeneratorMM.WebGeneratorMMPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Detalle</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class DetalleImpl extends PaginaEntidadImpl implements Detalle {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DetalleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WebGeneratorMMPackage.Literals.DETALLE;
	}

} //DetalleImpl
