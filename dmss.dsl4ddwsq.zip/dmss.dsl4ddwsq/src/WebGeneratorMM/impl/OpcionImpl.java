/**
 */
package WebGeneratorMM.impl;

import WebGeneratorMM.Opcion;
import WebGeneratorMM.WebGeneratorMMPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Opcion</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link WebGeneratorMM.impl.OpcionImpl#getContent <em>Content</em>}</li>
 *   <li>{@link WebGeneratorMM.impl.OpcionImpl#isCorrecta <em>Correcta</em>}</li>
 * </ul>
 *
 * @generated
 */
public class OpcionImpl extends EObjectImpl implements Opcion {
	/**
	 * The default value of the '{@link #getContent() <em>Content</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContent()
	 * @generated
	 * @ordered
	 */
	protected static final String CONTENT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getContent() <em>Content</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContent()
	 * @generated
	 * @ordered
	 */
	protected String content = CONTENT_EDEFAULT;

	/**
	 * The default value of the '{@link #isCorrecta() <em>Correcta</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isCorrecta()
	 * @generated
	 * @ordered
	 */
	protected static final boolean CORRECTA_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isCorrecta() <em>Correcta</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isCorrecta()
	 * @generated
	 * @ordered
	 */
	protected boolean correcta = CORRECTA_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OpcionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WebGeneratorMMPackage.Literals.OPCION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getContent() {
		return content;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setContent(String newContent) {
		String oldContent = content;
		content = newContent;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WebGeneratorMMPackage.OPCION__CONTENT, oldContent, content));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isCorrecta() {
		return correcta;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCorrecta(boolean newCorrecta) {
		boolean oldCorrecta = correcta;
		correcta = newCorrecta;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WebGeneratorMMPackage.OPCION__CORRECTA, oldCorrecta, correcta));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case WebGeneratorMMPackage.OPCION__CONTENT:
				return getContent();
			case WebGeneratorMMPackage.OPCION__CORRECTA:
				return isCorrecta();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case WebGeneratorMMPackage.OPCION__CONTENT:
				setContent((String)newValue);
				return;
			case WebGeneratorMMPackage.OPCION__CORRECTA:
				setCorrecta((Boolean)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case WebGeneratorMMPackage.OPCION__CONTENT:
				setContent(CONTENT_EDEFAULT);
				return;
			case WebGeneratorMMPackage.OPCION__CORRECTA:
				setCorrecta(CORRECTA_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case WebGeneratorMMPackage.OPCION__CONTENT:
				return CONTENT_EDEFAULT == null ? content != null : !CONTENT_EDEFAULT.equals(content);
			case WebGeneratorMMPackage.OPCION__CORRECTA:
				return correcta != CORRECTA_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (content: ");
		result.append(content);
		result.append(", correcta: ");
		result.append(correcta);
		result.append(')');
		return result.toString();
	}

} //OpcionImpl
