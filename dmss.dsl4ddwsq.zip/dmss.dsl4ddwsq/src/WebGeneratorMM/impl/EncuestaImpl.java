/**
 */
package WebGeneratorMM.impl;

import WebGeneratorMM.Encuesta;
import WebGeneratorMM.REPTYPE;
import WebGeneratorMM.WebGeneratorMMPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Encuesta</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link WebGeneratorMM.impl.EncuestaImpl#getRepresentacion <em>Representacion</em>}</li>
 * </ul>
 *
 * @generated
 */
public class EncuestaImpl extends PaginaEncFormImpl implements Encuesta {
	/**
	 * The default value of the '{@link #getRepresentacion() <em>Representacion</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRepresentacion()
	 * @generated
	 * @ordered
	 */
	protected static final REPTYPE REPRESENTACION_EDEFAULT = REPTYPE.BARRAS;

	/**
	 * The cached value of the '{@link #getRepresentacion() <em>Representacion</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRepresentacion()
	 * @generated
	 * @ordered
	 */
	protected REPTYPE representacion = REPRESENTACION_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EncuestaImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WebGeneratorMMPackage.Literals.ENCUESTA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public REPTYPE getRepresentacion() {
		return representacion;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRepresentacion(REPTYPE newRepresentacion) {
		REPTYPE oldRepresentacion = representacion;
		representacion = newRepresentacion == null ? REPRESENTACION_EDEFAULT : newRepresentacion;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WebGeneratorMMPackage.ENCUESTA__REPRESENTACION, oldRepresentacion, representacion));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case WebGeneratorMMPackage.ENCUESTA__REPRESENTACION:
				return getRepresentacion();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case WebGeneratorMMPackage.ENCUESTA__REPRESENTACION:
				setRepresentacion((REPTYPE)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case WebGeneratorMMPackage.ENCUESTA__REPRESENTACION:
				setRepresentacion(REPRESENTACION_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case WebGeneratorMMPackage.ENCUESTA__REPRESENTACION:
				return representacion != REPRESENTACION_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (representacion: ");
		result.append(representacion);
		result.append(')');
		return result.toString();
	}

} //EncuestaImpl
