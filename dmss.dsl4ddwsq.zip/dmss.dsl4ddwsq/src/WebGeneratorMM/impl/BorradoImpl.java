/**
 */
package WebGeneratorMM.impl;

import WebGeneratorMM.Borrado;
import WebGeneratorMM.WebGeneratorMMPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Borrado</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class BorradoImpl extends PaginaEntidadImpl implements Borrado {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BorradoImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WebGeneratorMMPackage.Literals.BORRADO;
	}

} //BorradoImpl
