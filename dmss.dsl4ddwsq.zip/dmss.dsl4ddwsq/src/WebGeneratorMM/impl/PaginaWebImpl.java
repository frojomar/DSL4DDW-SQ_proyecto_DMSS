/**
 */
package WebGeneratorMM.impl;

import WebGeneratorMM.ConexionRedSocial;
import WebGeneratorMM.Enlace;
import WebGeneratorMM.PaginaWeb;
import WebGeneratorMM.WebGeneratorMMPackage;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Pagina Web</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link WebGeneratorMM.impl.PaginaWebImpl#getName <em>Name</em>}</li>
 *   <li>{@link WebGeneratorMM.impl.PaginaWebImpl#getConexionredsocial <em>Conexionredsocial</em>}</li>
 *   <li>{@link WebGeneratorMM.impl.PaginaWebImpl#getEnlaces <em>Enlaces</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class PaginaWebImpl extends EObjectImpl implements PaginaWeb {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getConexionredsocial() <em>Conexionredsocial</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConexionredsocial()
	 * @generated
	 * @ordered
	 */
	protected EList<ConexionRedSocial> conexionredsocial;

	/**
	 * The cached value of the '{@link #getEnlaces() <em>Enlaces</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEnlaces()
	 * @generated
	 * @ordered
	 */
	protected EList<Enlace> enlaces;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PaginaWebImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WebGeneratorMMPackage.Literals.PAGINA_WEB;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WebGeneratorMMPackage.PAGINA_WEB__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ConexionRedSocial> getConexionredsocial() {
		if (conexionredsocial == null) {
			conexionredsocial = new EObjectContainmentEList<ConexionRedSocial>(ConexionRedSocial.class, this, WebGeneratorMMPackage.PAGINA_WEB__CONEXIONREDSOCIAL);
		}
		return conexionredsocial;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Enlace> getEnlaces() {
		if (enlaces == null) {
			enlaces = new EObjectContainmentEList<Enlace>(Enlace.class, this, WebGeneratorMMPackage.PAGINA_WEB__ENLACES);
		}
		return enlaces;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case WebGeneratorMMPackage.PAGINA_WEB__CONEXIONREDSOCIAL:
				return ((InternalEList<?>)getConexionredsocial()).basicRemove(otherEnd, msgs);
			case WebGeneratorMMPackage.PAGINA_WEB__ENLACES:
				return ((InternalEList<?>)getEnlaces()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case WebGeneratorMMPackage.PAGINA_WEB__NAME:
				return getName();
			case WebGeneratorMMPackage.PAGINA_WEB__CONEXIONREDSOCIAL:
				return getConexionredsocial();
			case WebGeneratorMMPackage.PAGINA_WEB__ENLACES:
				return getEnlaces();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case WebGeneratorMMPackage.PAGINA_WEB__NAME:
				setName((String)newValue);
				return;
			case WebGeneratorMMPackage.PAGINA_WEB__CONEXIONREDSOCIAL:
				getConexionredsocial().clear();
				getConexionredsocial().addAll((Collection<? extends ConexionRedSocial>)newValue);
				return;
			case WebGeneratorMMPackage.PAGINA_WEB__ENLACES:
				getEnlaces().clear();
				getEnlaces().addAll((Collection<? extends Enlace>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case WebGeneratorMMPackage.PAGINA_WEB__NAME:
				setName(NAME_EDEFAULT);
				return;
			case WebGeneratorMMPackage.PAGINA_WEB__CONEXIONREDSOCIAL:
				getConexionredsocial().clear();
				return;
			case WebGeneratorMMPackage.PAGINA_WEB__ENLACES:
				getEnlaces().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case WebGeneratorMMPackage.PAGINA_WEB__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case WebGeneratorMMPackage.PAGINA_WEB__CONEXIONREDSOCIAL:
				return conexionredsocial != null && !conexionredsocial.isEmpty();
			case WebGeneratorMMPackage.PAGINA_WEB__ENLACES:
				return enlaces != null && !enlaces.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //PaginaWebImpl
