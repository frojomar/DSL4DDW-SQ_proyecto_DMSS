/**
 */
package WebGeneratorMM.impl;

import WebGeneratorMM.Entidad;
import WebGeneratorMM.PaginaWeb;
import WebGeneratorMM.SitioWeb;
import WebGeneratorMM.WebGeneratorMMPackage;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Sitio Web</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link WebGeneratorMM.impl.SitioWebImpl#getEntidadesModelo <em>Entidades Modelo</em>}</li>
 *   <li>{@link WebGeneratorMM.impl.SitioWebImpl#getPaginasweb <em>Paginasweb</em>}</li>
 *   <li>{@link WebGeneratorMM.impl.SitioWebImpl#getName <em>Name</em>}</li>
 *   <li>{@link WebGeneratorMM.impl.SitioWebImpl#getImage <em>Image</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SitioWebImpl extends EObjectImpl implements SitioWeb {
	/**
	 * The cached value of the '{@link #getEntidadesModelo() <em>Entidades Modelo</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEntidadesModelo()
	 * @generated
	 * @ordered
	 */
	protected EList<Entidad> entidadesModelo;

	/**
	 * The cached value of the '{@link #getPaginasweb() <em>Paginasweb</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPaginasweb()
	 * @generated
	 * @ordered
	 */
	protected EList<PaginaWeb> paginasweb;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getImage() <em>Image</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getImage()
	 * @generated
	 * @ordered
	 */
	protected static final String IMAGE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getImage() <em>Image</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getImage()
	 * @generated
	 * @ordered
	 */
	protected String image = IMAGE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SitioWebImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WebGeneratorMMPackage.Literals.SITIO_WEB;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Entidad> getEntidadesModelo() {
		if (entidadesModelo == null) {
			entidadesModelo = new EObjectContainmentEList<Entidad>(Entidad.class, this, WebGeneratorMMPackage.SITIO_WEB__ENTIDADES_MODELO);
		}
		return entidadesModelo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<PaginaWeb> getPaginasweb() {
		if (paginasweb == null) {
			paginasweb = new EObjectContainmentEList<PaginaWeb>(PaginaWeb.class, this, WebGeneratorMMPackage.SITIO_WEB__PAGINASWEB);
		}
		return paginasweb;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WebGeneratorMMPackage.SITIO_WEB__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getImage() {
		return image;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setImage(String newImage) {
		String oldImage = image;
		image = newImage;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WebGeneratorMMPackage.SITIO_WEB__IMAGE, oldImage, image));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case WebGeneratorMMPackage.SITIO_WEB__ENTIDADES_MODELO:
				return ((InternalEList<?>)getEntidadesModelo()).basicRemove(otherEnd, msgs);
			case WebGeneratorMMPackage.SITIO_WEB__PAGINASWEB:
				return ((InternalEList<?>)getPaginasweb()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case WebGeneratorMMPackage.SITIO_WEB__ENTIDADES_MODELO:
				return getEntidadesModelo();
			case WebGeneratorMMPackage.SITIO_WEB__PAGINASWEB:
				return getPaginasweb();
			case WebGeneratorMMPackage.SITIO_WEB__NAME:
				return getName();
			case WebGeneratorMMPackage.SITIO_WEB__IMAGE:
				return getImage();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case WebGeneratorMMPackage.SITIO_WEB__ENTIDADES_MODELO:
				getEntidadesModelo().clear();
				getEntidadesModelo().addAll((Collection<? extends Entidad>)newValue);
				return;
			case WebGeneratorMMPackage.SITIO_WEB__PAGINASWEB:
				getPaginasweb().clear();
				getPaginasweb().addAll((Collection<? extends PaginaWeb>)newValue);
				return;
			case WebGeneratorMMPackage.SITIO_WEB__NAME:
				setName((String)newValue);
				return;
			case WebGeneratorMMPackage.SITIO_WEB__IMAGE:
				setImage((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case WebGeneratorMMPackage.SITIO_WEB__ENTIDADES_MODELO:
				getEntidadesModelo().clear();
				return;
			case WebGeneratorMMPackage.SITIO_WEB__PAGINASWEB:
				getPaginasweb().clear();
				return;
			case WebGeneratorMMPackage.SITIO_WEB__NAME:
				setName(NAME_EDEFAULT);
				return;
			case WebGeneratorMMPackage.SITIO_WEB__IMAGE:
				setImage(IMAGE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case WebGeneratorMMPackage.SITIO_WEB__ENTIDADES_MODELO:
				return entidadesModelo != null && !entidadesModelo.isEmpty();
			case WebGeneratorMMPackage.SITIO_WEB__PAGINASWEB:
				return paginasweb != null && !paginasweb.isEmpty();
			case WebGeneratorMMPackage.SITIO_WEB__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case WebGeneratorMMPackage.SITIO_WEB__IMAGE:
				return IMAGE_EDEFAULT == null ? image != null : !IMAGE_EDEFAULT.equals(image);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", image: ");
		result.append(image);
		result.append(')');
		return result.toString();
	}

} //SitioWebImpl
