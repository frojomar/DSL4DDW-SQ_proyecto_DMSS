/**
 */
package WebGeneratorMM.impl;

import WebGeneratorMM.Opcion;
import WebGeneratorMM.PreguntaElegir;
import WebGeneratorMM.WebGeneratorMMPackage;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Pregunta Elegir</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link WebGeneratorMM.impl.PreguntaElegirImpl#getOpciones <em>Opciones</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PreguntaElegirImpl extends PreguntaImpl implements PreguntaElegir {
	/**
	 * The cached value of the '{@link #getOpciones() <em>Opciones</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOpciones()
	 * @generated
	 * @ordered
	 */
	protected EList<Opcion> opciones;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PreguntaElegirImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WebGeneratorMMPackage.Literals.PREGUNTA_ELEGIR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Opcion> getOpciones() {
		if (opciones == null) {
			opciones = new EObjectContainmentEList<Opcion>(Opcion.class, this, WebGeneratorMMPackage.PREGUNTA_ELEGIR__OPCIONES);
		}
		return opciones;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case WebGeneratorMMPackage.PREGUNTA_ELEGIR__OPCIONES:
				return ((InternalEList<?>)getOpciones()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case WebGeneratorMMPackage.PREGUNTA_ELEGIR__OPCIONES:
				return getOpciones();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case WebGeneratorMMPackage.PREGUNTA_ELEGIR__OPCIONES:
				getOpciones().clear();
				getOpciones().addAll((Collection<? extends Opcion>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case WebGeneratorMMPackage.PREGUNTA_ELEGIR__OPCIONES:
				getOpciones().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case WebGeneratorMMPackage.PREGUNTA_ELEGIR__OPCIONES:
				return opciones != null && !opciones.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //PreguntaElegirImpl
