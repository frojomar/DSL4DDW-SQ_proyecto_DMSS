/**
 */
package WebGeneratorMM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Enlace Interno</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link WebGeneratorMM.EnlaceInterno#getReferencia <em>Referencia</em>}</li>
 * </ul>
 *
 * @see WebGeneratorMM.WebGeneratorMMPackage#getEnlaceInterno()
 * @model annotation="MyDSLDoc Description='Relaciona elementos pertenecientes al propio sitio web. En el campo \\\"referencia\\\" se indica la direcci\363n destino.'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore constraints='no_permitidos_a_detalle no_permitidos_a_borrado no_permitidos_a_home'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot no_permitidos_a_detalle='not self.referencia.oclIsTypeOf(Detalle)' no_permitidos_a_borrado='not self.referencia.oclIsTypeOf(Borrado)' no_permitidos_a_home='not self.referencia.oclIsTypeOf(PaginaHome)'"
 *        annotation="gmf.node label='name' color='229,251,252' border.width='1' border.style='dot'"
 * @generated
 */
public interface EnlaceInterno extends Enlace {
	/**
	 * Returns the value of the '<em><b>Referencia</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Referencia</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Referencia</em>' reference.
	 * @see #setReferencia(PaginaWeb)
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getEnlaceInterno_Referencia()
	 * @model required="true"
	 *        annotation="gmf.link target.decoration='arrow' style='dash' tool.name='Enlace interno a pagina'"
	 * @generated
	 */
	PaginaWeb getReferencia();

	/**
	 * Sets the value of the '{@link WebGeneratorMM.EnlaceInterno#getReferencia <em>Referencia</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Referencia</em>' reference.
	 * @see #getReferencia()
	 * @generated
	 */
	void setReferencia(PaginaWeb value);

} // EnlaceInterno
