/**
 */
package WebGeneratorMM;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see WebGeneratorMM.WebGeneratorMMFactory
 * @model kind="package"
 *        annotation="MyDSLDoc Author='Ruben Rentero Trejo, Francisco Javier Rojo Mart\355n'"
 *        annotation="http://www.eclipse.org/OCL/Import ecore='http://www.eclipse.org/emf/2002/Ecore'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore invocationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot' settingDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot' validationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot'"
 * @generated
 */
public interface WebGeneratorMMPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "WebGeneratorMM";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.unex.es/dmss/WebGeneratorMM";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "WebGeneratorMM";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	WebGeneratorMMPackage eINSTANCE = WebGeneratorMM.impl.WebGeneratorMMPackageImpl.init();

	/**
	 * The meta object id for the '{@link WebGeneratorMM.impl.SitioWebImpl <em>Sitio Web</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see WebGeneratorMM.impl.SitioWebImpl
	 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getSitioWeb()
	 * @generated
	 */
	int SITIO_WEB = 0;

	/**
	 * The feature id for the '<em><b>Entidades Modelo</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SITIO_WEB__ENTIDADES_MODELO = 0;

	/**
	 * The feature id for the '<em><b>Paginasweb</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SITIO_WEB__PAGINASWEB = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SITIO_WEB__NAME = 2;

	/**
	 * The feature id for the '<em><b>Image</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SITIO_WEB__IMAGE = 3;

	/**
	 * The number of structural features of the '<em>Sitio Web</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SITIO_WEB_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link WebGeneratorMM.impl.PaginaWebImpl <em>Pagina Web</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see WebGeneratorMM.impl.PaginaWebImpl
	 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getPaginaWeb()
	 * @generated
	 */
	int PAGINA_WEB = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA_WEB__NAME = 0;

	/**
	 * The feature id for the '<em><b>Conexionredsocial</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA_WEB__CONEXIONREDSOCIAL = 1;

	/**
	 * The feature id for the '<em><b>Enlaces</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA_WEB__ENLACES = 2;

	/**
	 * The number of structural features of the '<em>Pagina Web</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA_WEB_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link WebGeneratorMM.impl.EntidadImpl <em>Entidad</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see WebGeneratorMM.impl.EntidadImpl
	 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getEntidad()
	 * @generated
	 */
	int ENTIDAD = 2;

	/**
	 * The feature id for the '<em><b>Referencias</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTIDAD__REFERENCIAS = 0;

	/**
	 * The feature id for the '<em><b>Atributos</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTIDAD__ATRIBUTOS = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTIDAD__NAME = 2;

	/**
	 * The number of structural features of the '<em>Entidad</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTIDAD_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link WebGeneratorMM.impl.ReferenciaImpl <em>Referencia</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see WebGeneratorMM.impl.ReferenciaImpl
	 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getReferencia()
	 * @generated
	 */
	int REFERENCIA = 3;

	/**
	 * The feature id for the '<em><b>Destino</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCIA__DESTINO = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCIA__NAME = 1;

	/**
	 * The feature id for the '<em><b>Muchas</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCIA__MUCHAS = 2;

	/**
	 * The number of structural features of the '<em>Referencia</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCIA_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link WebGeneratorMM.impl.AtributoImpl <em>Atributo</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see WebGeneratorMM.impl.AtributoImpl
	 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getAtributo()
	 * @generated
	 */
	int ATRIBUTO = 4;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATRIBUTO__TYPE = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATRIBUTO__NAME = 1;

	/**
	 * The number of structural features of the '<em>Atributo</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATRIBUTO_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link WebGeneratorMM.impl.PaginaEntidadImpl <em>Pagina Entidad</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see WebGeneratorMM.impl.PaginaEntidadImpl
	 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getPaginaEntidad()
	 * @generated
	 */
	int PAGINA_ENTIDAD = 23;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA_ENTIDAD__NAME = PAGINA_WEB__NAME;

	/**
	 * The feature id for the '<em><b>Conexionredsocial</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA_ENTIDAD__CONEXIONREDSOCIAL = PAGINA_WEB__CONEXIONREDSOCIAL;

	/**
	 * The feature id for the '<em><b>Enlaces</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA_ENTIDAD__ENLACES = PAGINA_WEB__ENLACES;

	/**
	 * The feature id for the '<em><b>Entidad</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA_ENTIDAD__ENTIDAD = PAGINA_WEB_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Pagina Entidad</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA_ENTIDAD_FEATURE_COUNT = PAGINA_WEB_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link WebGeneratorMM.impl.IndiceImpl <em>Indice</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see WebGeneratorMM.impl.IndiceImpl
	 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getIndice()
	 * @generated
	 */
	int INDICE = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INDICE__NAME = PAGINA_ENTIDAD__NAME;

	/**
	 * The feature id for the '<em><b>Conexionredsocial</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INDICE__CONEXIONREDSOCIAL = PAGINA_ENTIDAD__CONEXIONREDSOCIAL;

	/**
	 * The feature id for the '<em><b>Enlaces</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INDICE__ENLACES = PAGINA_ENTIDAD__ENLACES;

	/**
	 * The feature id for the '<em><b>Entidad</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INDICE__ENTIDAD = PAGINA_ENTIDAD__ENTIDAD;

	/**
	 * The number of structural features of the '<em>Indice</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INDICE_FEATURE_COUNT = PAGINA_ENTIDAD_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link WebGeneratorMM.impl.PaginaCRUDImpl <em>Pagina CRUD</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see WebGeneratorMM.impl.PaginaCRUDImpl
	 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getPaginaCRUD()
	 * @generated
	 */
	int PAGINA_CRUD = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA_CRUD__NAME = PAGINA_ENTIDAD__NAME;

	/**
	 * The feature id for the '<em><b>Conexionredsocial</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA_CRUD__CONEXIONREDSOCIAL = PAGINA_ENTIDAD__CONEXIONREDSOCIAL;

	/**
	 * The feature id for the '<em><b>Enlaces</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA_CRUD__ENLACES = PAGINA_ENTIDAD__ENLACES;

	/**
	 * The feature id for the '<em><b>Entidad</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA_CRUD__ENTIDAD = PAGINA_ENTIDAD__ENTIDAD;

	/**
	 * The number of structural features of the '<em>Pagina CRUD</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA_CRUD_FEATURE_COUNT = PAGINA_ENTIDAD_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link WebGeneratorMM.impl.PaginaEncFormImpl <em>Pagina Enc Form</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see WebGeneratorMM.impl.PaginaEncFormImpl
	 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getPaginaEncForm()
	 * @generated
	 */
	int PAGINA_ENC_FORM = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA_ENC_FORM__NAME = PAGINA_WEB__NAME;

	/**
	 * The feature id for the '<em><b>Conexionredsocial</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA_ENC_FORM__CONEXIONREDSOCIAL = PAGINA_WEB__CONEXIONREDSOCIAL;

	/**
	 * The feature id for the '<em><b>Enlaces</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA_ENC_FORM__ENLACES = PAGINA_WEB__ENLACES;

	/**
	 * The feature id for the '<em><b>Preguntas</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA_ENC_FORM__PREGUNTAS = PAGINA_WEB_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Pagina Enc Form</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA_ENC_FORM_FEATURE_COUNT = PAGINA_WEB_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link WebGeneratorMM.impl.PaginaHomeImpl <em>Pagina Home</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see WebGeneratorMM.impl.PaginaHomeImpl
	 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getPaginaHome()
	 * @generated
	 */
	int PAGINA_HOME = 8;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA_HOME__NAME = PAGINA_WEB__NAME;

	/**
	 * The feature id for the '<em><b>Conexionredsocial</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA_HOME__CONEXIONREDSOCIAL = PAGINA_WEB__CONEXIONREDSOCIAL;

	/**
	 * The feature id for the '<em><b>Enlaces</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA_HOME__ENLACES = PAGINA_WEB__ENLACES;

	/**
	 * The number of structural features of the '<em>Pagina Home</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA_HOME_FEATURE_COUNT = PAGINA_WEB_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link WebGeneratorMM.impl.ConexionRedSocialImpl <em>Conexion Red Social</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see WebGeneratorMM.impl.ConexionRedSocialImpl
	 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getConexionRedSocial()
	 * @generated
	 */
	int CONEXION_RED_SOCIAL = 9;

	/**
	 * The feature id for the '<em><b>Script</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONEXION_RED_SOCIAL__SCRIPT = 0;

	/**
	 * The feature id for the '<em><b>Tag</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONEXION_RED_SOCIAL__TAG = 1;

	/**
	 * The number of structural features of the '<em>Conexion Red Social</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONEXION_RED_SOCIAL_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link WebGeneratorMM.impl.PreguntaImpl <em>Pregunta</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see WebGeneratorMM.impl.PreguntaImpl
	 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getPregunta()
	 * @generated
	 */
	int PREGUNTA = 10;

	/**
	 * The feature id for the '<em><b>Num Orden</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREGUNTA__NUM_ORDEN = 0;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREGUNTA__CONTENT = 1;

	/**
	 * The number of structural features of the '<em>Pregunta</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREGUNTA_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link WebGeneratorMM.impl.PreguntaCortaImpl <em>Pregunta Corta</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see WebGeneratorMM.impl.PreguntaCortaImpl
	 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getPreguntaCorta()
	 * @generated
	 */
	int PREGUNTA_CORTA = 11;

	/**
	 * The feature id for the '<em><b>Num Orden</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREGUNTA_CORTA__NUM_ORDEN = PREGUNTA__NUM_ORDEN;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREGUNTA_CORTA__CONTENT = PREGUNTA__CONTENT;

	/**
	 * The feature id for the '<em><b>Solucion</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREGUNTA_CORTA__SOLUCION = PREGUNTA_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Pregunta Corta</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREGUNTA_CORTA_FEATURE_COUNT = PREGUNTA_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link WebGeneratorMM.impl.PreguntaElegirImpl <em>Pregunta Elegir</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see WebGeneratorMM.impl.PreguntaElegirImpl
	 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getPreguntaElegir()
	 * @generated
	 */
	int PREGUNTA_ELEGIR = 12;

	/**
	 * The feature id for the '<em><b>Num Orden</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREGUNTA_ELEGIR__NUM_ORDEN = PREGUNTA__NUM_ORDEN;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREGUNTA_ELEGIR__CONTENT = PREGUNTA__CONTENT;

	/**
	 * The feature id for the '<em><b>Opciones</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREGUNTA_ELEGIR__OPCIONES = PREGUNTA_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Pregunta Elegir</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREGUNTA_ELEGIR_FEATURE_COUNT = PREGUNTA_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link WebGeneratorMM.impl.PreguntaVFImpl <em>Pregunta VF</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see WebGeneratorMM.impl.PreguntaVFImpl
	 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getPreguntaVF()
	 * @generated
	 */
	int PREGUNTA_VF = 13;

	/**
	 * The feature id for the '<em><b>Num Orden</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREGUNTA_VF__NUM_ORDEN = PREGUNTA__NUM_ORDEN;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREGUNTA_VF__CONTENT = PREGUNTA__CONTENT;

	/**
	 * The feature id for the '<em><b>Solucion</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREGUNTA_VF__SOLUCION = PREGUNTA_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Pregunta VF</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREGUNTA_VF_FEATURE_COUNT = PREGUNTA_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link WebGeneratorMM.impl.EncuestaImpl <em>Encuesta</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see WebGeneratorMM.impl.EncuestaImpl
	 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getEncuesta()
	 * @generated
	 */
	int ENCUESTA = 14;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENCUESTA__NAME = PAGINA_ENC_FORM__NAME;

	/**
	 * The feature id for the '<em><b>Conexionredsocial</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENCUESTA__CONEXIONREDSOCIAL = PAGINA_ENC_FORM__CONEXIONREDSOCIAL;

	/**
	 * The feature id for the '<em><b>Enlaces</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENCUESTA__ENLACES = PAGINA_ENC_FORM__ENLACES;

	/**
	 * The feature id for the '<em><b>Preguntas</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENCUESTA__PREGUNTAS = PAGINA_ENC_FORM__PREGUNTAS;

	/**
	 * The feature id for the '<em><b>Representacion</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENCUESTA__REPRESENTACION = PAGINA_ENC_FORM_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Encuesta</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENCUESTA_FEATURE_COUNT = PAGINA_ENC_FORM_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link WebGeneratorMM.impl.CuestionarioImpl <em>Cuestionario</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see WebGeneratorMM.impl.CuestionarioImpl
	 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getCuestionario()
	 * @generated
	 */
	int CUESTIONARIO = 15;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUESTIONARIO__NAME = PAGINA_ENC_FORM__NAME;

	/**
	 * The feature id for the '<em><b>Conexionredsocial</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUESTIONARIO__CONEXIONREDSOCIAL = PAGINA_ENC_FORM__CONEXIONREDSOCIAL;

	/**
	 * The feature id for the '<em><b>Enlaces</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUESTIONARIO__ENLACES = PAGINA_ENC_FORM__ENLACES;

	/**
	 * The feature id for the '<em><b>Preguntas</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUESTIONARIO__PREGUNTAS = PAGINA_ENC_FORM__PREGUNTAS;

	/**
	 * The number of structural features of the '<em>Cuestionario</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUESTIONARIO_FEATURE_COUNT = PAGINA_ENC_FORM_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link WebGeneratorMM.impl.EnlaceImpl <em>Enlace</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see WebGeneratorMM.impl.EnlaceImpl
	 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getEnlace()
	 * @generated
	 */
	int ENLACE = 16;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENLACE__NAME = 0;

	/**
	 * The number of structural features of the '<em>Enlace</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENLACE_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link WebGeneratorMM.impl.EnlaceExternoImpl <em>Enlace Externo</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see WebGeneratorMM.impl.EnlaceExternoImpl
	 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getEnlaceExterno()
	 * @generated
	 */
	int ENLACE_EXTERNO = 17;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENLACE_EXTERNO__NAME = ENLACE__NAME;

	/**
	 * The feature id for the '<em><b>Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENLACE_EXTERNO__URL = ENLACE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Enlace Externo</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENLACE_EXTERNO_FEATURE_COUNT = ENLACE_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link WebGeneratorMM.impl.EnlaceInternoImpl <em>Enlace Interno</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see WebGeneratorMM.impl.EnlaceInternoImpl
	 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getEnlaceInterno()
	 * @generated
	 */
	int ENLACE_INTERNO = 18;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENLACE_INTERNO__NAME = ENLACE__NAME;

	/**
	 * The feature id for the '<em><b>Referencia</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENLACE_INTERNO__REFERENCIA = ENLACE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Enlace Interno</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENLACE_INTERNO_FEATURE_COUNT = ENLACE_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link WebGeneratorMM.impl.OpcionImpl <em>Opcion</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see WebGeneratorMM.impl.OpcionImpl
	 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getOpcion()
	 * @generated
	 */
	int OPCION = 19;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPCION__CONTENT = 0;

	/**
	 * The feature id for the '<em><b>Correcta</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPCION__CORRECTA = 1;

	/**
	 * The number of structural features of the '<em>Opcion</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPCION_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link WebGeneratorMM.impl.DetalleImpl <em>Detalle</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see WebGeneratorMM.impl.DetalleImpl
	 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getDetalle()
	 * @generated
	 */
	int DETALLE = 20;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DETALLE__NAME = PAGINA_ENTIDAD__NAME;

	/**
	 * The feature id for the '<em><b>Conexionredsocial</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DETALLE__CONEXIONREDSOCIAL = PAGINA_ENTIDAD__CONEXIONREDSOCIAL;

	/**
	 * The feature id for the '<em><b>Enlaces</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DETALLE__ENLACES = PAGINA_ENTIDAD__ENLACES;

	/**
	 * The feature id for the '<em><b>Entidad</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DETALLE__ENTIDAD = PAGINA_ENTIDAD__ENTIDAD;

	/**
	 * The number of structural features of the '<em>Detalle</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DETALLE_FEATURE_COUNT = PAGINA_ENTIDAD_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link WebGeneratorMM.impl.BorradoImpl <em>Borrado</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see WebGeneratorMM.impl.BorradoImpl
	 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getBorrado()
	 * @generated
	 */
	int BORRADO = 21;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BORRADO__NAME = PAGINA_ENTIDAD__NAME;

	/**
	 * The feature id for the '<em><b>Conexionredsocial</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BORRADO__CONEXIONREDSOCIAL = PAGINA_ENTIDAD__CONEXIONREDSOCIAL;

	/**
	 * The feature id for the '<em><b>Enlaces</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BORRADO__ENLACES = PAGINA_ENTIDAD__ENLACES;

	/**
	 * The feature id for the '<em><b>Entidad</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BORRADO__ENTIDAD = PAGINA_ENTIDAD__ENTIDAD;

	/**
	 * The number of structural features of the '<em>Borrado</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BORRADO_FEATURE_COUNT = PAGINA_ENTIDAD_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link WebGeneratorMM.impl.CreacionImpl <em>Creacion</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see WebGeneratorMM.impl.CreacionImpl
	 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getCreacion()
	 * @generated
	 */
	int CREACION = 22;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREACION__NAME = PAGINA_ENTIDAD__NAME;

	/**
	 * The feature id for the '<em><b>Conexionredsocial</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREACION__CONEXIONREDSOCIAL = PAGINA_ENTIDAD__CONEXIONREDSOCIAL;

	/**
	 * The feature id for the '<em><b>Enlaces</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREACION__ENLACES = PAGINA_ENTIDAD__ENLACES;

	/**
	 * The feature id for the '<em><b>Entidad</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREACION__ENTIDAD = PAGINA_ENTIDAD__ENTIDAD;

	/**
	 * The number of structural features of the '<em>Creacion</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREACION_FEATURE_COUNT = PAGINA_ENTIDAD_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link WebGeneratorMM.REPTYPE <em>REPTYPE</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see WebGeneratorMM.REPTYPE
	 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getREPTYPE()
	 * @generated
	 */
	int REPTYPE = 24;

	/**
	 * The meta object id for the '{@link WebGeneratorMM.ATRTYPE <em>ATRTYPE</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see WebGeneratorMM.ATRTYPE
	 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getATRTYPE()
	 * @generated
	 */
	int ATRTYPE = 25;


	/**
	 * Returns the meta object for class '{@link WebGeneratorMM.SitioWeb <em>Sitio Web</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sitio Web</em>'.
	 * @see WebGeneratorMM.SitioWeb
	 * @generated
	 */
	EClass getSitioWeb();

	/**
	 * Returns the meta object for the containment reference list '{@link WebGeneratorMM.SitioWeb#getEntidadesModelo <em>Entidades Modelo</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Entidades Modelo</em>'.
	 * @see WebGeneratorMM.SitioWeb#getEntidadesModelo()
	 * @see #getSitioWeb()
	 * @generated
	 */
	EReference getSitioWeb_EntidadesModelo();

	/**
	 * Returns the meta object for the containment reference list '{@link WebGeneratorMM.SitioWeb#getPaginasweb <em>Paginasweb</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Paginasweb</em>'.
	 * @see WebGeneratorMM.SitioWeb#getPaginasweb()
	 * @see #getSitioWeb()
	 * @generated
	 */
	EReference getSitioWeb_Paginasweb();

	/**
	 * Returns the meta object for the attribute '{@link WebGeneratorMM.SitioWeb#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see WebGeneratorMM.SitioWeb#getName()
	 * @see #getSitioWeb()
	 * @generated
	 */
	EAttribute getSitioWeb_Name();

	/**
	 * Returns the meta object for the attribute '{@link WebGeneratorMM.SitioWeb#getImage <em>Image</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Image</em>'.
	 * @see WebGeneratorMM.SitioWeb#getImage()
	 * @see #getSitioWeb()
	 * @generated
	 */
	EAttribute getSitioWeb_Image();

	/**
	 * Returns the meta object for class '{@link WebGeneratorMM.PaginaWeb <em>Pagina Web</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Pagina Web</em>'.
	 * @see WebGeneratorMM.PaginaWeb
	 * @generated
	 */
	EClass getPaginaWeb();

	/**
	 * Returns the meta object for the attribute '{@link WebGeneratorMM.PaginaWeb#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see WebGeneratorMM.PaginaWeb#getName()
	 * @see #getPaginaWeb()
	 * @generated
	 */
	EAttribute getPaginaWeb_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link WebGeneratorMM.PaginaWeb#getConexionredsocial <em>Conexionredsocial</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Conexionredsocial</em>'.
	 * @see WebGeneratorMM.PaginaWeb#getConexionredsocial()
	 * @see #getPaginaWeb()
	 * @generated
	 */
	EReference getPaginaWeb_Conexionredsocial();

	/**
	 * Returns the meta object for the containment reference list '{@link WebGeneratorMM.PaginaWeb#getEnlaces <em>Enlaces</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Enlaces</em>'.
	 * @see WebGeneratorMM.PaginaWeb#getEnlaces()
	 * @see #getPaginaWeb()
	 * @generated
	 */
	EReference getPaginaWeb_Enlaces();

	/**
	 * Returns the meta object for class '{@link WebGeneratorMM.Entidad <em>Entidad</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Entidad</em>'.
	 * @see WebGeneratorMM.Entidad
	 * @generated
	 */
	EClass getEntidad();

	/**
	 * Returns the meta object for the containment reference list '{@link WebGeneratorMM.Entidad#getReferencias <em>Referencias</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Referencias</em>'.
	 * @see WebGeneratorMM.Entidad#getReferencias()
	 * @see #getEntidad()
	 * @generated
	 */
	EReference getEntidad_Referencias();

	/**
	 * Returns the meta object for the containment reference list '{@link WebGeneratorMM.Entidad#getAtributos <em>Atributos</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Atributos</em>'.
	 * @see WebGeneratorMM.Entidad#getAtributos()
	 * @see #getEntidad()
	 * @generated
	 */
	EReference getEntidad_Atributos();

	/**
	 * Returns the meta object for the attribute '{@link WebGeneratorMM.Entidad#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see WebGeneratorMM.Entidad#getName()
	 * @see #getEntidad()
	 * @generated
	 */
	EAttribute getEntidad_Name();

	/**
	 * Returns the meta object for class '{@link WebGeneratorMM.Referencia <em>Referencia</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Referencia</em>'.
	 * @see WebGeneratorMM.Referencia
	 * @generated
	 */
	EClass getReferencia();

	/**
	 * Returns the meta object for the reference '{@link WebGeneratorMM.Referencia#getDestino <em>Destino</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Destino</em>'.
	 * @see WebGeneratorMM.Referencia#getDestino()
	 * @see #getReferencia()
	 * @generated
	 */
	EReference getReferencia_Destino();

	/**
	 * Returns the meta object for the attribute '{@link WebGeneratorMM.Referencia#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see WebGeneratorMM.Referencia#getName()
	 * @see #getReferencia()
	 * @generated
	 */
	EAttribute getReferencia_Name();

	/**
	 * Returns the meta object for the attribute '{@link WebGeneratorMM.Referencia#isMuchas <em>Muchas</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Muchas</em>'.
	 * @see WebGeneratorMM.Referencia#isMuchas()
	 * @see #getReferencia()
	 * @generated
	 */
	EAttribute getReferencia_Muchas();

	/**
	 * Returns the meta object for class '{@link WebGeneratorMM.Atributo <em>Atributo</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Atributo</em>'.
	 * @see WebGeneratorMM.Atributo
	 * @generated
	 */
	EClass getAtributo();

	/**
	 * Returns the meta object for the attribute '{@link WebGeneratorMM.Atributo#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see WebGeneratorMM.Atributo#getType()
	 * @see #getAtributo()
	 * @generated
	 */
	EAttribute getAtributo_Type();

	/**
	 * Returns the meta object for the attribute '{@link WebGeneratorMM.Atributo#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see WebGeneratorMM.Atributo#getName()
	 * @see #getAtributo()
	 * @generated
	 */
	EAttribute getAtributo_Name();

	/**
	 * Returns the meta object for class '{@link WebGeneratorMM.Indice <em>Indice</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Indice</em>'.
	 * @see WebGeneratorMM.Indice
	 * @generated
	 */
	EClass getIndice();

	/**
	 * Returns the meta object for class '{@link WebGeneratorMM.PaginaCRUD <em>Pagina CRUD</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Pagina CRUD</em>'.
	 * @see WebGeneratorMM.PaginaCRUD
	 * @generated
	 */
	EClass getPaginaCRUD();

	/**
	 * Returns the meta object for class '{@link WebGeneratorMM.PaginaEncForm <em>Pagina Enc Form</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Pagina Enc Form</em>'.
	 * @see WebGeneratorMM.PaginaEncForm
	 * @generated
	 */
	EClass getPaginaEncForm();

	/**
	 * Returns the meta object for the containment reference list '{@link WebGeneratorMM.PaginaEncForm#getPreguntas <em>Preguntas</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Preguntas</em>'.
	 * @see WebGeneratorMM.PaginaEncForm#getPreguntas()
	 * @see #getPaginaEncForm()
	 * @generated
	 */
	EReference getPaginaEncForm_Preguntas();

	/**
	 * Returns the meta object for class '{@link WebGeneratorMM.PaginaHome <em>Pagina Home</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Pagina Home</em>'.
	 * @see WebGeneratorMM.PaginaHome
	 * @generated
	 */
	EClass getPaginaHome();

	/**
	 * Returns the meta object for class '{@link WebGeneratorMM.ConexionRedSocial <em>Conexion Red Social</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Conexion Red Social</em>'.
	 * @see WebGeneratorMM.ConexionRedSocial
	 * @generated
	 */
	EClass getConexionRedSocial();

	/**
	 * Returns the meta object for the attribute '{@link WebGeneratorMM.ConexionRedSocial#getScript <em>Script</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Script</em>'.
	 * @see WebGeneratorMM.ConexionRedSocial#getScript()
	 * @see #getConexionRedSocial()
	 * @generated
	 */
	EAttribute getConexionRedSocial_Script();

	/**
	 * Returns the meta object for the attribute '{@link WebGeneratorMM.ConexionRedSocial#getTag <em>Tag</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Tag</em>'.
	 * @see WebGeneratorMM.ConexionRedSocial#getTag()
	 * @see #getConexionRedSocial()
	 * @generated
	 */
	EAttribute getConexionRedSocial_Tag();

	/**
	 * Returns the meta object for class '{@link WebGeneratorMM.Pregunta <em>Pregunta</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Pregunta</em>'.
	 * @see WebGeneratorMM.Pregunta
	 * @generated
	 */
	EClass getPregunta();

	/**
	 * Returns the meta object for the attribute '{@link WebGeneratorMM.Pregunta#getNumOrden <em>Num Orden</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Num Orden</em>'.
	 * @see WebGeneratorMM.Pregunta#getNumOrden()
	 * @see #getPregunta()
	 * @generated
	 */
	EAttribute getPregunta_NumOrden();

	/**
	 * Returns the meta object for the attribute '{@link WebGeneratorMM.Pregunta#getContent <em>Content</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Content</em>'.
	 * @see WebGeneratorMM.Pregunta#getContent()
	 * @see #getPregunta()
	 * @generated
	 */
	EAttribute getPregunta_Content();

	/**
	 * Returns the meta object for class '{@link WebGeneratorMM.PreguntaCorta <em>Pregunta Corta</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Pregunta Corta</em>'.
	 * @see WebGeneratorMM.PreguntaCorta
	 * @generated
	 */
	EClass getPreguntaCorta();

	/**
	 * Returns the meta object for the attribute '{@link WebGeneratorMM.PreguntaCorta#getSolucion <em>Solucion</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Solucion</em>'.
	 * @see WebGeneratorMM.PreguntaCorta#getSolucion()
	 * @see #getPreguntaCorta()
	 * @generated
	 */
	EAttribute getPreguntaCorta_Solucion();

	/**
	 * Returns the meta object for class '{@link WebGeneratorMM.PreguntaElegir <em>Pregunta Elegir</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Pregunta Elegir</em>'.
	 * @see WebGeneratorMM.PreguntaElegir
	 * @generated
	 */
	EClass getPreguntaElegir();

	/**
	 * Returns the meta object for the containment reference list '{@link WebGeneratorMM.PreguntaElegir#getOpciones <em>Opciones</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Opciones</em>'.
	 * @see WebGeneratorMM.PreguntaElegir#getOpciones()
	 * @see #getPreguntaElegir()
	 * @generated
	 */
	EReference getPreguntaElegir_Opciones();

	/**
	 * Returns the meta object for class '{@link WebGeneratorMM.PreguntaVF <em>Pregunta VF</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Pregunta VF</em>'.
	 * @see WebGeneratorMM.PreguntaVF
	 * @generated
	 */
	EClass getPreguntaVF();

	/**
	 * Returns the meta object for the attribute '{@link WebGeneratorMM.PreguntaVF#isSolucion <em>Solucion</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Solucion</em>'.
	 * @see WebGeneratorMM.PreguntaVF#isSolucion()
	 * @see #getPreguntaVF()
	 * @generated
	 */
	EAttribute getPreguntaVF_Solucion();

	/**
	 * Returns the meta object for class '{@link WebGeneratorMM.Encuesta <em>Encuesta</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Encuesta</em>'.
	 * @see WebGeneratorMM.Encuesta
	 * @generated
	 */
	EClass getEncuesta();

	/**
	 * Returns the meta object for the attribute '{@link WebGeneratorMM.Encuesta#getRepresentacion <em>Representacion</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Representacion</em>'.
	 * @see WebGeneratorMM.Encuesta#getRepresentacion()
	 * @see #getEncuesta()
	 * @generated
	 */
	EAttribute getEncuesta_Representacion();

	/**
	 * Returns the meta object for class '{@link WebGeneratorMM.Cuestionario <em>Cuestionario</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Cuestionario</em>'.
	 * @see WebGeneratorMM.Cuestionario
	 * @generated
	 */
	EClass getCuestionario();

	/**
	 * Returns the meta object for class '{@link WebGeneratorMM.Enlace <em>Enlace</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Enlace</em>'.
	 * @see WebGeneratorMM.Enlace
	 * @generated
	 */
	EClass getEnlace();

	/**
	 * Returns the meta object for the attribute '{@link WebGeneratorMM.Enlace#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see WebGeneratorMM.Enlace#getName()
	 * @see #getEnlace()
	 * @generated
	 */
	EAttribute getEnlace_Name();

	/**
	 * Returns the meta object for class '{@link WebGeneratorMM.EnlaceExterno <em>Enlace Externo</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Enlace Externo</em>'.
	 * @see WebGeneratorMM.EnlaceExterno
	 * @generated
	 */
	EClass getEnlaceExterno();

	/**
	 * Returns the meta object for the attribute '{@link WebGeneratorMM.EnlaceExterno#getUrl <em>Url</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Url</em>'.
	 * @see WebGeneratorMM.EnlaceExterno#getUrl()
	 * @see #getEnlaceExterno()
	 * @generated
	 */
	EAttribute getEnlaceExterno_Url();

	/**
	 * Returns the meta object for class '{@link WebGeneratorMM.EnlaceInterno <em>Enlace Interno</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Enlace Interno</em>'.
	 * @see WebGeneratorMM.EnlaceInterno
	 * @generated
	 */
	EClass getEnlaceInterno();

	/**
	 * Returns the meta object for the reference '{@link WebGeneratorMM.EnlaceInterno#getReferencia <em>Referencia</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Referencia</em>'.
	 * @see WebGeneratorMM.EnlaceInterno#getReferencia()
	 * @see #getEnlaceInterno()
	 * @generated
	 */
	EReference getEnlaceInterno_Referencia();

	/**
	 * Returns the meta object for class '{@link WebGeneratorMM.Opcion <em>Opcion</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Opcion</em>'.
	 * @see WebGeneratorMM.Opcion
	 * @generated
	 */
	EClass getOpcion();

	/**
	 * Returns the meta object for the attribute '{@link WebGeneratorMM.Opcion#getContent <em>Content</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Content</em>'.
	 * @see WebGeneratorMM.Opcion#getContent()
	 * @see #getOpcion()
	 * @generated
	 */
	EAttribute getOpcion_Content();

	/**
	 * Returns the meta object for the attribute '{@link WebGeneratorMM.Opcion#isCorrecta <em>Correcta</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Correcta</em>'.
	 * @see WebGeneratorMM.Opcion#isCorrecta()
	 * @see #getOpcion()
	 * @generated
	 */
	EAttribute getOpcion_Correcta();

	/**
	 * Returns the meta object for class '{@link WebGeneratorMM.Detalle <em>Detalle</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Detalle</em>'.
	 * @see WebGeneratorMM.Detalle
	 * @generated
	 */
	EClass getDetalle();

	/**
	 * Returns the meta object for class '{@link WebGeneratorMM.Borrado <em>Borrado</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Borrado</em>'.
	 * @see WebGeneratorMM.Borrado
	 * @generated
	 */
	EClass getBorrado();

	/**
	 * Returns the meta object for class '{@link WebGeneratorMM.Creacion <em>Creacion</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Creacion</em>'.
	 * @see WebGeneratorMM.Creacion
	 * @generated
	 */
	EClass getCreacion();

	/**
	 * Returns the meta object for class '{@link WebGeneratorMM.PaginaEntidad <em>Pagina Entidad</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Pagina Entidad</em>'.
	 * @see WebGeneratorMM.PaginaEntidad
	 * @generated
	 */
	EClass getPaginaEntidad();

	/**
	 * Returns the meta object for the reference '{@link WebGeneratorMM.PaginaEntidad#getEntidad <em>Entidad</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Entidad</em>'.
	 * @see WebGeneratorMM.PaginaEntidad#getEntidad()
	 * @see #getPaginaEntidad()
	 * @generated
	 */
	EReference getPaginaEntidad_Entidad();

	/**
	 * Returns the meta object for enum '{@link WebGeneratorMM.REPTYPE <em>REPTYPE</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>REPTYPE</em>'.
	 * @see WebGeneratorMM.REPTYPE
	 * @generated
	 */
	EEnum getREPTYPE();

	/**
	 * Returns the meta object for enum '{@link WebGeneratorMM.ATRTYPE <em>ATRTYPE</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>ATRTYPE</em>'.
	 * @see WebGeneratorMM.ATRTYPE
	 * @generated
	 */
	EEnum getATRTYPE();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	WebGeneratorMMFactory getWebGeneratorMMFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link WebGeneratorMM.impl.SitioWebImpl <em>Sitio Web</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see WebGeneratorMM.impl.SitioWebImpl
		 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getSitioWeb()
		 * @generated
		 */
		EClass SITIO_WEB = eINSTANCE.getSitioWeb();

		/**
		 * The meta object literal for the '<em><b>Entidades Modelo</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SITIO_WEB__ENTIDADES_MODELO = eINSTANCE.getSitioWeb_EntidadesModelo();

		/**
		 * The meta object literal for the '<em><b>Paginasweb</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SITIO_WEB__PAGINASWEB = eINSTANCE.getSitioWeb_Paginasweb();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SITIO_WEB__NAME = eINSTANCE.getSitioWeb_Name();

		/**
		 * The meta object literal for the '<em><b>Image</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SITIO_WEB__IMAGE = eINSTANCE.getSitioWeb_Image();

		/**
		 * The meta object literal for the '{@link WebGeneratorMM.impl.PaginaWebImpl <em>Pagina Web</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see WebGeneratorMM.impl.PaginaWebImpl
		 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getPaginaWeb()
		 * @generated
		 */
		EClass PAGINA_WEB = eINSTANCE.getPaginaWeb();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PAGINA_WEB__NAME = eINSTANCE.getPaginaWeb_Name();

		/**
		 * The meta object literal for the '<em><b>Conexionredsocial</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAGINA_WEB__CONEXIONREDSOCIAL = eINSTANCE.getPaginaWeb_Conexionredsocial();

		/**
		 * The meta object literal for the '<em><b>Enlaces</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAGINA_WEB__ENLACES = eINSTANCE.getPaginaWeb_Enlaces();

		/**
		 * The meta object literal for the '{@link WebGeneratorMM.impl.EntidadImpl <em>Entidad</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see WebGeneratorMM.impl.EntidadImpl
		 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getEntidad()
		 * @generated
		 */
		EClass ENTIDAD = eINSTANCE.getEntidad();

		/**
		 * The meta object literal for the '<em><b>Referencias</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENTIDAD__REFERENCIAS = eINSTANCE.getEntidad_Referencias();

		/**
		 * The meta object literal for the '<em><b>Atributos</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENTIDAD__ATRIBUTOS = eINSTANCE.getEntidad_Atributos();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENTIDAD__NAME = eINSTANCE.getEntidad_Name();

		/**
		 * The meta object literal for the '{@link WebGeneratorMM.impl.ReferenciaImpl <em>Referencia</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see WebGeneratorMM.impl.ReferenciaImpl
		 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getReferencia()
		 * @generated
		 */
		EClass REFERENCIA = eINSTANCE.getReferencia();

		/**
		 * The meta object literal for the '<em><b>Destino</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REFERENCIA__DESTINO = eINSTANCE.getReferencia_Destino();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REFERENCIA__NAME = eINSTANCE.getReferencia_Name();

		/**
		 * The meta object literal for the '<em><b>Muchas</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REFERENCIA__MUCHAS = eINSTANCE.getReferencia_Muchas();

		/**
		 * The meta object literal for the '{@link WebGeneratorMM.impl.AtributoImpl <em>Atributo</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see WebGeneratorMM.impl.AtributoImpl
		 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getAtributo()
		 * @generated
		 */
		EClass ATRIBUTO = eINSTANCE.getAtributo();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATRIBUTO__TYPE = eINSTANCE.getAtributo_Type();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATRIBUTO__NAME = eINSTANCE.getAtributo_Name();

		/**
		 * The meta object literal for the '{@link WebGeneratorMM.impl.IndiceImpl <em>Indice</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see WebGeneratorMM.impl.IndiceImpl
		 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getIndice()
		 * @generated
		 */
		EClass INDICE = eINSTANCE.getIndice();

		/**
		 * The meta object literal for the '{@link WebGeneratorMM.impl.PaginaCRUDImpl <em>Pagina CRUD</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see WebGeneratorMM.impl.PaginaCRUDImpl
		 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getPaginaCRUD()
		 * @generated
		 */
		EClass PAGINA_CRUD = eINSTANCE.getPaginaCRUD();

		/**
		 * The meta object literal for the '{@link WebGeneratorMM.impl.PaginaEncFormImpl <em>Pagina Enc Form</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see WebGeneratorMM.impl.PaginaEncFormImpl
		 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getPaginaEncForm()
		 * @generated
		 */
		EClass PAGINA_ENC_FORM = eINSTANCE.getPaginaEncForm();

		/**
		 * The meta object literal for the '<em><b>Preguntas</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAGINA_ENC_FORM__PREGUNTAS = eINSTANCE.getPaginaEncForm_Preguntas();

		/**
		 * The meta object literal for the '{@link WebGeneratorMM.impl.PaginaHomeImpl <em>Pagina Home</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see WebGeneratorMM.impl.PaginaHomeImpl
		 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getPaginaHome()
		 * @generated
		 */
		EClass PAGINA_HOME = eINSTANCE.getPaginaHome();

		/**
		 * The meta object literal for the '{@link WebGeneratorMM.impl.ConexionRedSocialImpl <em>Conexion Red Social</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see WebGeneratorMM.impl.ConexionRedSocialImpl
		 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getConexionRedSocial()
		 * @generated
		 */
		EClass CONEXION_RED_SOCIAL = eINSTANCE.getConexionRedSocial();

		/**
		 * The meta object literal for the '<em><b>Script</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONEXION_RED_SOCIAL__SCRIPT = eINSTANCE.getConexionRedSocial_Script();

		/**
		 * The meta object literal for the '<em><b>Tag</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONEXION_RED_SOCIAL__TAG = eINSTANCE.getConexionRedSocial_Tag();

		/**
		 * The meta object literal for the '{@link WebGeneratorMM.impl.PreguntaImpl <em>Pregunta</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see WebGeneratorMM.impl.PreguntaImpl
		 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getPregunta()
		 * @generated
		 */
		EClass PREGUNTA = eINSTANCE.getPregunta();

		/**
		 * The meta object literal for the '<em><b>Num Orden</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PREGUNTA__NUM_ORDEN = eINSTANCE.getPregunta_NumOrden();

		/**
		 * The meta object literal for the '<em><b>Content</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PREGUNTA__CONTENT = eINSTANCE.getPregunta_Content();

		/**
		 * The meta object literal for the '{@link WebGeneratorMM.impl.PreguntaCortaImpl <em>Pregunta Corta</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see WebGeneratorMM.impl.PreguntaCortaImpl
		 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getPreguntaCorta()
		 * @generated
		 */
		EClass PREGUNTA_CORTA = eINSTANCE.getPreguntaCorta();

		/**
		 * The meta object literal for the '<em><b>Solucion</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PREGUNTA_CORTA__SOLUCION = eINSTANCE.getPreguntaCorta_Solucion();

		/**
		 * The meta object literal for the '{@link WebGeneratorMM.impl.PreguntaElegirImpl <em>Pregunta Elegir</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see WebGeneratorMM.impl.PreguntaElegirImpl
		 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getPreguntaElegir()
		 * @generated
		 */
		EClass PREGUNTA_ELEGIR = eINSTANCE.getPreguntaElegir();

		/**
		 * The meta object literal for the '<em><b>Opciones</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PREGUNTA_ELEGIR__OPCIONES = eINSTANCE.getPreguntaElegir_Opciones();

		/**
		 * The meta object literal for the '{@link WebGeneratorMM.impl.PreguntaVFImpl <em>Pregunta VF</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see WebGeneratorMM.impl.PreguntaVFImpl
		 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getPreguntaVF()
		 * @generated
		 */
		EClass PREGUNTA_VF = eINSTANCE.getPreguntaVF();

		/**
		 * The meta object literal for the '<em><b>Solucion</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PREGUNTA_VF__SOLUCION = eINSTANCE.getPreguntaVF_Solucion();

		/**
		 * The meta object literal for the '{@link WebGeneratorMM.impl.EncuestaImpl <em>Encuesta</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see WebGeneratorMM.impl.EncuestaImpl
		 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getEncuesta()
		 * @generated
		 */
		EClass ENCUESTA = eINSTANCE.getEncuesta();

		/**
		 * The meta object literal for the '<em><b>Representacion</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENCUESTA__REPRESENTACION = eINSTANCE.getEncuesta_Representacion();

		/**
		 * The meta object literal for the '{@link WebGeneratorMM.impl.CuestionarioImpl <em>Cuestionario</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see WebGeneratorMM.impl.CuestionarioImpl
		 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getCuestionario()
		 * @generated
		 */
		EClass CUESTIONARIO = eINSTANCE.getCuestionario();

		/**
		 * The meta object literal for the '{@link WebGeneratorMM.impl.EnlaceImpl <em>Enlace</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see WebGeneratorMM.impl.EnlaceImpl
		 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getEnlace()
		 * @generated
		 */
		EClass ENLACE = eINSTANCE.getEnlace();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENLACE__NAME = eINSTANCE.getEnlace_Name();

		/**
		 * The meta object literal for the '{@link WebGeneratorMM.impl.EnlaceExternoImpl <em>Enlace Externo</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see WebGeneratorMM.impl.EnlaceExternoImpl
		 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getEnlaceExterno()
		 * @generated
		 */
		EClass ENLACE_EXTERNO = eINSTANCE.getEnlaceExterno();

		/**
		 * The meta object literal for the '<em><b>Url</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENLACE_EXTERNO__URL = eINSTANCE.getEnlaceExterno_Url();

		/**
		 * The meta object literal for the '{@link WebGeneratorMM.impl.EnlaceInternoImpl <em>Enlace Interno</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see WebGeneratorMM.impl.EnlaceInternoImpl
		 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getEnlaceInterno()
		 * @generated
		 */
		EClass ENLACE_INTERNO = eINSTANCE.getEnlaceInterno();

		/**
		 * The meta object literal for the '<em><b>Referencia</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENLACE_INTERNO__REFERENCIA = eINSTANCE.getEnlaceInterno_Referencia();

		/**
		 * The meta object literal for the '{@link WebGeneratorMM.impl.OpcionImpl <em>Opcion</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see WebGeneratorMM.impl.OpcionImpl
		 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getOpcion()
		 * @generated
		 */
		EClass OPCION = eINSTANCE.getOpcion();

		/**
		 * The meta object literal for the '<em><b>Content</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OPCION__CONTENT = eINSTANCE.getOpcion_Content();

		/**
		 * The meta object literal for the '<em><b>Correcta</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OPCION__CORRECTA = eINSTANCE.getOpcion_Correcta();

		/**
		 * The meta object literal for the '{@link WebGeneratorMM.impl.DetalleImpl <em>Detalle</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see WebGeneratorMM.impl.DetalleImpl
		 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getDetalle()
		 * @generated
		 */
		EClass DETALLE = eINSTANCE.getDetalle();

		/**
		 * The meta object literal for the '{@link WebGeneratorMM.impl.BorradoImpl <em>Borrado</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see WebGeneratorMM.impl.BorradoImpl
		 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getBorrado()
		 * @generated
		 */
		EClass BORRADO = eINSTANCE.getBorrado();

		/**
		 * The meta object literal for the '{@link WebGeneratorMM.impl.CreacionImpl <em>Creacion</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see WebGeneratorMM.impl.CreacionImpl
		 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getCreacion()
		 * @generated
		 */
		EClass CREACION = eINSTANCE.getCreacion();

		/**
		 * The meta object literal for the '{@link WebGeneratorMM.impl.PaginaEntidadImpl <em>Pagina Entidad</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see WebGeneratorMM.impl.PaginaEntidadImpl
		 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getPaginaEntidad()
		 * @generated
		 */
		EClass PAGINA_ENTIDAD = eINSTANCE.getPaginaEntidad();

		/**
		 * The meta object literal for the '<em><b>Entidad</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAGINA_ENTIDAD__ENTIDAD = eINSTANCE.getPaginaEntidad_Entidad();

		/**
		 * The meta object literal for the '{@link WebGeneratorMM.REPTYPE <em>REPTYPE</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see WebGeneratorMM.REPTYPE
		 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getREPTYPE()
		 * @generated
		 */
		EEnum REPTYPE = eINSTANCE.getREPTYPE();

		/**
		 * The meta object literal for the '{@link WebGeneratorMM.ATRTYPE <em>ATRTYPE</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see WebGeneratorMM.ATRTYPE
		 * @see WebGeneratorMM.impl.WebGeneratorMMPackageImpl#getATRTYPE()
		 * @generated
		 */
		EEnum ATRTYPE = eINSTANCE.getATRTYPE();

	}

} //WebGeneratorMMPackage
