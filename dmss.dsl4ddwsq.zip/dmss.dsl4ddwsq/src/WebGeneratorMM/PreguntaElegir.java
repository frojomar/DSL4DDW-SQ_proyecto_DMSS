/**
 */
package WebGeneratorMM;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pregunta Elegir</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link WebGeneratorMM.PreguntaElegir#getOpciones <em>Opciones</em>}</li>
 * </ul>
 *
 * @see WebGeneratorMM.WebGeneratorMMPackage#getPreguntaElegir()
 * @model annotation="MyDSLDoc Description='Se ofrece un texto con una pregunta para el usuario. Las respuestas a dicha pregunta ser\341n una serie de opciones de las cuales s\363lo se puede seleccionar una.'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore constraints='al_menos_dos_opciones'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot al_menos_dos_opciones='self.opciones->size()>1'"
 *        annotation="gmf.node label='content' color='197,225,234'"
 * @generated
 */
public interface PreguntaElegir extends Pregunta {
	/**
	 * Returns the value of the '<em><b>Opciones</b></em>' containment reference list.
	 * The list contents are of type {@link WebGeneratorMM.Opcion}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Opciones</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Opciones</em>' containment reference list.
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getPreguntaElegir_Opciones()
	 * @model containment="true" lower="2"
	 *        annotation="gmf.compartment foo='bar' layout='list'"
	 * @generated
	 */
	EList<Opcion> getOpciones();

} // PreguntaElegir
