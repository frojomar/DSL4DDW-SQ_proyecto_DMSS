/**
 */
package WebGeneratorMM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pregunta VF</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link WebGeneratorMM.PreguntaVF#isSolucion <em>Solucion</em>}</li>
 * </ul>
 *
 * @see WebGeneratorMM.WebGeneratorMMPackage#getPreguntaVF()
 * @model annotation="MyDSLDoc Description='Se ofrece un texto con una pregunta al usuario y la respuesta ser\341 \372nicamente verdadero o falso.'"
 *        annotation="gmf.node label='content' color='197,225,234'"
 * @generated
 */
public interface PreguntaVF extends Pregunta {
	/**
	 * Returns the value of the '<em><b>Solucion</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Solucion</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Solucion</em>' attribute.
	 * @see #setSolucion(boolean)
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getPreguntaVF_Solucion()
	 * @model
	 * @generated
	 */
	boolean isSolucion();

	/**
	 * Sets the value of the '{@link WebGeneratorMM.PreguntaVF#isSolucion <em>Solucion</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Solucion</em>' attribute.
	 * @see #isSolucion()
	 * @generated
	 */
	void setSolucion(boolean value);

} // PreguntaVF
