/**
 */
package WebGeneratorMM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pagina Entidad</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link WebGeneratorMM.PaginaEntidad#getEntidad <em>Entidad</em>}</li>
 * </ul>
 *
 * @see WebGeneratorMM.WebGeneratorMMPackage#getPaginaEntidad()
 * @model abstract="true"
 *        annotation="MyDSLDoc Description='Representa el conjunto de p\341ginas: Creaci\363n, borrado, detalle, \355ndice y CRUD. Esta clase abstracta se convertir\341 en una de ellas.'"
 * @generated
 */
public interface PaginaEntidad extends PaginaWeb {
	/**
	 * Returns the value of the '<em><b>Entidad</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Entidad</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Entidad</em>' reference.
	 * @see #setEntidad(Entidad)
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getPaginaEntidad_Entidad()
	 * @model required="true"
	 *        annotation="gmf.link target.decoration='square' style='dash' tool.name='Pagina de Entidad'"
	 * @generated
	 */
	Entidad getEntidad();

	/**
	 * Sets the value of the '{@link WebGeneratorMM.PaginaEntidad#getEntidad <em>Entidad</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Entidad</em>' reference.
	 * @see #getEntidad()
	 * @generated
	 */
	void setEntidad(Entidad value);

} // PaginaEntidad
