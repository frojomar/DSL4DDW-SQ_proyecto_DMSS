/**
 */
package WebGeneratorMM.util;

import WebGeneratorMM.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see WebGeneratorMM.WebGeneratorMMPackage
 * @generated
 */
public class WebGeneratorMMAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static WebGeneratorMMPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WebGeneratorMMAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = WebGeneratorMMPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject)object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected WebGeneratorMMSwitch<Adapter> modelSwitch =
		new WebGeneratorMMSwitch<Adapter>() {
			@Override
			public Adapter caseSitioWeb(SitioWeb object) {
				return createSitioWebAdapter();
			}
			@Override
			public Adapter casePaginaWeb(PaginaWeb object) {
				return createPaginaWebAdapter();
			}
			@Override
			public Adapter caseEntidad(Entidad object) {
				return createEntidadAdapter();
			}
			@Override
			public Adapter caseReferencia(Referencia object) {
				return createReferenciaAdapter();
			}
			@Override
			public Adapter caseAtributo(Atributo object) {
				return createAtributoAdapter();
			}
			@Override
			public Adapter caseIndice(Indice object) {
				return createIndiceAdapter();
			}
			@Override
			public Adapter casePaginaCRUD(PaginaCRUD object) {
				return createPaginaCRUDAdapter();
			}
			@Override
			public Adapter casePaginaEncForm(PaginaEncForm object) {
				return createPaginaEncFormAdapter();
			}
			@Override
			public Adapter casePaginaHome(PaginaHome object) {
				return createPaginaHomeAdapter();
			}
			@Override
			public Adapter caseConexionRedSocial(ConexionRedSocial object) {
				return createConexionRedSocialAdapter();
			}
			@Override
			public Adapter casePregunta(Pregunta object) {
				return createPreguntaAdapter();
			}
			@Override
			public Adapter casePreguntaCorta(PreguntaCorta object) {
				return createPreguntaCortaAdapter();
			}
			@Override
			public Adapter casePreguntaElegir(PreguntaElegir object) {
				return createPreguntaElegirAdapter();
			}
			@Override
			public Adapter casePreguntaVF(PreguntaVF object) {
				return createPreguntaVFAdapter();
			}
			@Override
			public Adapter caseEncuesta(Encuesta object) {
				return createEncuestaAdapter();
			}
			@Override
			public Adapter caseCuestionario(Cuestionario object) {
				return createCuestionarioAdapter();
			}
			@Override
			public Adapter caseEnlace(Enlace object) {
				return createEnlaceAdapter();
			}
			@Override
			public Adapter caseEnlaceExterno(EnlaceExterno object) {
				return createEnlaceExternoAdapter();
			}
			@Override
			public Adapter caseEnlaceInterno(EnlaceInterno object) {
				return createEnlaceInternoAdapter();
			}
			@Override
			public Adapter caseOpcion(Opcion object) {
				return createOpcionAdapter();
			}
			@Override
			public Adapter caseDetalle(Detalle object) {
				return createDetalleAdapter();
			}
			@Override
			public Adapter caseBorrado(Borrado object) {
				return createBorradoAdapter();
			}
			@Override
			public Adapter caseCreacion(Creacion object) {
				return createCreacionAdapter();
			}
			@Override
			public Adapter casePaginaEntidad(PaginaEntidad object) {
				return createPaginaEntidadAdapter();
			}
			@Override
			public Adapter defaultCase(EObject object) {
				return createEObjectAdapter();
			}
		};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject)target);
	}


	/**
	 * Creates a new adapter for an object of class '{@link WebGeneratorMM.SitioWeb <em>Sitio Web</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see WebGeneratorMM.SitioWeb
	 * @generated
	 */
	public Adapter createSitioWebAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link WebGeneratorMM.PaginaWeb <em>Pagina Web</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see WebGeneratorMM.PaginaWeb
	 * @generated
	 */
	public Adapter createPaginaWebAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link WebGeneratorMM.Entidad <em>Entidad</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see WebGeneratorMM.Entidad
	 * @generated
	 */
	public Adapter createEntidadAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link WebGeneratorMM.Referencia <em>Referencia</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see WebGeneratorMM.Referencia
	 * @generated
	 */
	public Adapter createReferenciaAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link WebGeneratorMM.Atributo <em>Atributo</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see WebGeneratorMM.Atributo
	 * @generated
	 */
	public Adapter createAtributoAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link WebGeneratorMM.Indice <em>Indice</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see WebGeneratorMM.Indice
	 * @generated
	 */
	public Adapter createIndiceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link WebGeneratorMM.PaginaCRUD <em>Pagina CRUD</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see WebGeneratorMM.PaginaCRUD
	 * @generated
	 */
	public Adapter createPaginaCRUDAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link WebGeneratorMM.PaginaEncForm <em>Pagina Enc Form</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see WebGeneratorMM.PaginaEncForm
	 * @generated
	 */
	public Adapter createPaginaEncFormAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link WebGeneratorMM.PaginaHome <em>Pagina Home</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see WebGeneratorMM.PaginaHome
	 * @generated
	 */
	public Adapter createPaginaHomeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link WebGeneratorMM.ConexionRedSocial <em>Conexion Red Social</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see WebGeneratorMM.ConexionRedSocial
	 * @generated
	 */
	public Adapter createConexionRedSocialAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link WebGeneratorMM.Pregunta <em>Pregunta</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see WebGeneratorMM.Pregunta
	 * @generated
	 */
	public Adapter createPreguntaAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link WebGeneratorMM.PreguntaCorta <em>Pregunta Corta</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see WebGeneratorMM.PreguntaCorta
	 * @generated
	 */
	public Adapter createPreguntaCortaAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link WebGeneratorMM.PreguntaElegir <em>Pregunta Elegir</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see WebGeneratorMM.PreguntaElegir
	 * @generated
	 */
	public Adapter createPreguntaElegirAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link WebGeneratorMM.PreguntaVF <em>Pregunta VF</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see WebGeneratorMM.PreguntaVF
	 * @generated
	 */
	public Adapter createPreguntaVFAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link WebGeneratorMM.Encuesta <em>Encuesta</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see WebGeneratorMM.Encuesta
	 * @generated
	 */
	public Adapter createEncuestaAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link WebGeneratorMM.Cuestionario <em>Cuestionario</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see WebGeneratorMM.Cuestionario
	 * @generated
	 */
	public Adapter createCuestionarioAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link WebGeneratorMM.Enlace <em>Enlace</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see WebGeneratorMM.Enlace
	 * @generated
	 */
	public Adapter createEnlaceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link WebGeneratorMM.EnlaceExterno <em>Enlace Externo</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see WebGeneratorMM.EnlaceExterno
	 * @generated
	 */
	public Adapter createEnlaceExternoAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link WebGeneratorMM.EnlaceInterno <em>Enlace Interno</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see WebGeneratorMM.EnlaceInterno
	 * @generated
	 */
	public Adapter createEnlaceInternoAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link WebGeneratorMM.Opcion <em>Opcion</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see WebGeneratorMM.Opcion
	 * @generated
	 */
	public Adapter createOpcionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link WebGeneratorMM.Detalle <em>Detalle</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see WebGeneratorMM.Detalle
	 * @generated
	 */
	public Adapter createDetalleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link WebGeneratorMM.Borrado <em>Borrado</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see WebGeneratorMM.Borrado
	 * @generated
	 */
	public Adapter createBorradoAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link WebGeneratorMM.Creacion <em>Creacion</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see WebGeneratorMM.Creacion
	 * @generated
	 */
	public Adapter createCreacionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link WebGeneratorMM.PaginaEntidad <em>Pagina Entidad</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see WebGeneratorMM.PaginaEntidad
	 * @generated
	 */
	public Adapter createPaginaEntidadAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //WebGeneratorMMAdapterFactory
