/**
 */
package WebGeneratorMM.util;

import WebGeneratorMM.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see WebGeneratorMM.WebGeneratorMMPackage
 * @generated
 */
public class WebGeneratorMMSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static WebGeneratorMMPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WebGeneratorMMSwitch() {
		if (modelPackage == null) {
			modelPackage = WebGeneratorMMPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
			case WebGeneratorMMPackage.SITIO_WEB: {
				SitioWeb sitioWeb = (SitioWeb)theEObject;
				T result = caseSitioWeb(sitioWeb);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case WebGeneratorMMPackage.PAGINA_WEB: {
				PaginaWeb paginaWeb = (PaginaWeb)theEObject;
				T result = casePaginaWeb(paginaWeb);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case WebGeneratorMMPackage.ENTIDAD: {
				Entidad entidad = (Entidad)theEObject;
				T result = caseEntidad(entidad);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case WebGeneratorMMPackage.REFERENCIA: {
				Referencia referencia = (Referencia)theEObject;
				T result = caseReferencia(referencia);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case WebGeneratorMMPackage.ATRIBUTO: {
				Atributo atributo = (Atributo)theEObject;
				T result = caseAtributo(atributo);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case WebGeneratorMMPackage.INDICE: {
				Indice indice = (Indice)theEObject;
				T result = caseIndice(indice);
				if (result == null) result = casePaginaEntidad(indice);
				if (result == null) result = casePaginaWeb(indice);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case WebGeneratorMMPackage.PAGINA_CRUD: {
				PaginaCRUD paginaCRUD = (PaginaCRUD)theEObject;
				T result = casePaginaCRUD(paginaCRUD);
				if (result == null) result = casePaginaEntidad(paginaCRUD);
				if (result == null) result = casePaginaWeb(paginaCRUD);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case WebGeneratorMMPackage.PAGINA_ENC_FORM: {
				PaginaEncForm paginaEncForm = (PaginaEncForm)theEObject;
				T result = casePaginaEncForm(paginaEncForm);
				if (result == null) result = casePaginaWeb(paginaEncForm);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case WebGeneratorMMPackage.PAGINA_HOME: {
				PaginaHome paginaHome = (PaginaHome)theEObject;
				T result = casePaginaHome(paginaHome);
				if (result == null) result = casePaginaWeb(paginaHome);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case WebGeneratorMMPackage.CONEXION_RED_SOCIAL: {
				ConexionRedSocial conexionRedSocial = (ConexionRedSocial)theEObject;
				T result = caseConexionRedSocial(conexionRedSocial);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case WebGeneratorMMPackage.PREGUNTA: {
				Pregunta pregunta = (Pregunta)theEObject;
				T result = casePregunta(pregunta);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case WebGeneratorMMPackage.PREGUNTA_CORTA: {
				PreguntaCorta preguntaCorta = (PreguntaCorta)theEObject;
				T result = casePreguntaCorta(preguntaCorta);
				if (result == null) result = casePregunta(preguntaCorta);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case WebGeneratorMMPackage.PREGUNTA_ELEGIR: {
				PreguntaElegir preguntaElegir = (PreguntaElegir)theEObject;
				T result = casePreguntaElegir(preguntaElegir);
				if (result == null) result = casePregunta(preguntaElegir);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case WebGeneratorMMPackage.PREGUNTA_VF: {
				PreguntaVF preguntaVF = (PreguntaVF)theEObject;
				T result = casePreguntaVF(preguntaVF);
				if (result == null) result = casePregunta(preguntaVF);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case WebGeneratorMMPackage.ENCUESTA: {
				Encuesta encuesta = (Encuesta)theEObject;
				T result = caseEncuesta(encuesta);
				if (result == null) result = casePaginaEncForm(encuesta);
				if (result == null) result = casePaginaWeb(encuesta);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case WebGeneratorMMPackage.CUESTIONARIO: {
				Cuestionario cuestionario = (Cuestionario)theEObject;
				T result = caseCuestionario(cuestionario);
				if (result == null) result = casePaginaEncForm(cuestionario);
				if (result == null) result = casePaginaWeb(cuestionario);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case WebGeneratorMMPackage.ENLACE: {
				Enlace enlace = (Enlace)theEObject;
				T result = caseEnlace(enlace);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case WebGeneratorMMPackage.ENLACE_EXTERNO: {
				EnlaceExterno enlaceExterno = (EnlaceExterno)theEObject;
				T result = caseEnlaceExterno(enlaceExterno);
				if (result == null) result = caseEnlace(enlaceExterno);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case WebGeneratorMMPackage.ENLACE_INTERNO: {
				EnlaceInterno enlaceInterno = (EnlaceInterno)theEObject;
				T result = caseEnlaceInterno(enlaceInterno);
				if (result == null) result = caseEnlace(enlaceInterno);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case WebGeneratorMMPackage.OPCION: {
				Opcion opcion = (Opcion)theEObject;
				T result = caseOpcion(opcion);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case WebGeneratorMMPackage.DETALLE: {
				Detalle detalle = (Detalle)theEObject;
				T result = caseDetalle(detalle);
				if (result == null) result = casePaginaEntidad(detalle);
				if (result == null) result = casePaginaWeb(detalle);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case WebGeneratorMMPackage.BORRADO: {
				Borrado borrado = (Borrado)theEObject;
				T result = caseBorrado(borrado);
				if (result == null) result = casePaginaEntidad(borrado);
				if (result == null) result = casePaginaWeb(borrado);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case WebGeneratorMMPackage.CREACION: {
				Creacion creacion = (Creacion)theEObject;
				T result = caseCreacion(creacion);
				if (result == null) result = casePaginaEntidad(creacion);
				if (result == null) result = casePaginaWeb(creacion);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case WebGeneratorMMPackage.PAGINA_ENTIDAD: {
				PaginaEntidad paginaEntidad = (PaginaEntidad)theEObject;
				T result = casePaginaEntidad(paginaEntidad);
				if (result == null) result = casePaginaWeb(paginaEntidad);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			default: return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Sitio Web</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSitioWeb(SitioWeb object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Pagina Web</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Pagina Web</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePaginaWeb(PaginaWeb object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Entidad</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Entidad</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseEntidad(Entidad object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Referencia</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Referencia</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseReferencia(Referencia object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Atributo</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Atributo</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAtributo(Atributo object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Indice</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Indice</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseIndice(Indice object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Pagina CRUD</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Pagina CRUD</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePaginaCRUD(PaginaCRUD object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Pagina Enc Form</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Pagina Enc Form</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePaginaEncForm(PaginaEncForm object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Pagina Home</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Pagina Home</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePaginaHome(PaginaHome object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Conexion Red Social</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Conexion Red Social</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConexionRedSocial(ConexionRedSocial object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Pregunta</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Pregunta</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePregunta(Pregunta object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Pregunta Corta</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Pregunta Corta</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePreguntaCorta(PreguntaCorta object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Pregunta Elegir</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Pregunta Elegir</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePreguntaElegir(PreguntaElegir object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Pregunta VF</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Pregunta VF</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePreguntaVF(PreguntaVF object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Encuesta</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Encuesta</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseEncuesta(Encuesta object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Cuestionario</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Cuestionario</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCuestionario(Cuestionario object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Enlace</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Enlace</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseEnlace(Enlace object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Enlace Externo</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Enlace Externo</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseEnlaceExterno(EnlaceExterno object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Enlace Interno</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Enlace Interno</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseEnlaceInterno(EnlaceInterno object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Opcion</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Opcion</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOpcion(Opcion object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Detalle</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Detalle</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDetalle(Detalle object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Borrado</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Borrado</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBorrado(Borrado object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Creacion</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Creacion</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCreacion(Creacion object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Pagina Entidad</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Pagina Entidad</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePaginaEntidad(PaginaEntidad object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //WebGeneratorMMSwitch
