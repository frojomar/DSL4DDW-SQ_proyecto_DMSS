/**
 */
package WebGeneratorMM.util;

import WebGeneratorMM.*;

import java.util.Map;

import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.EObjectValidator;

/**
 * <!-- begin-user-doc -->
 * The <b>Validator</b> for the model.
 * <!-- end-user-doc -->
 * @see WebGeneratorMM.WebGeneratorMMPackage
 * @generated
 */
public class WebGeneratorMMValidator extends EObjectValidator {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final WebGeneratorMMValidator INSTANCE = new WebGeneratorMMValidator();

	/**
	 * A constant for the {@link org.eclipse.emf.common.util.Diagnostic#getSource() source} of diagnostic {@link org.eclipse.emf.common.util.Diagnostic#getCode() codes} from this package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.common.util.Diagnostic#getSource()
	 * @see org.eclipse.emf.common.util.Diagnostic#getCode()
	 * @generated
	 */
	public static final String DIAGNOSTIC_SOURCE = "WebGeneratorMM";

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final int GENERATED_DIAGNOSTIC_CODE_COUNT = 0;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants in a derived class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final int DIAGNOSTIC_CODE_COUNT = GENERATED_DIAGNOSTIC_CODE_COUNT;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WebGeneratorMMValidator() {
		super();
	}

	/**
	 * Returns the package of this validator switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EPackage getEPackage() {
	  return WebGeneratorMMPackage.eINSTANCE;
	}

	/**
	 * Calls <code>validateXXX</code> for the corresponding classifier of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean validate(int classifierID, Object value, DiagnosticChain diagnostics, Map<Object, Object> context) {
		switch (classifierID) {
			case WebGeneratorMMPackage.SITIO_WEB:
				return validateSitioWeb((SitioWeb)value, diagnostics, context);
			case WebGeneratorMMPackage.PAGINA_WEB:
				return validatePaginaWeb((PaginaWeb)value, diagnostics, context);
			case WebGeneratorMMPackage.ENTIDAD:
				return validateEntidad((Entidad)value, diagnostics, context);
			case WebGeneratorMMPackage.REFERENCIA:
				return validateReferencia((Referencia)value, diagnostics, context);
			case WebGeneratorMMPackage.ATRIBUTO:
				return validateAtributo((Atributo)value, diagnostics, context);
			case WebGeneratorMMPackage.INDICE:
				return validateIndice((Indice)value, diagnostics, context);
			case WebGeneratorMMPackage.PAGINA_CRUD:
				return validatePaginaCRUD((PaginaCRUD)value, diagnostics, context);
			case WebGeneratorMMPackage.PAGINA_ENC_FORM:
				return validatePaginaEncForm((PaginaEncForm)value, diagnostics, context);
			case WebGeneratorMMPackage.PAGINA_HOME:
				return validatePaginaHome((PaginaHome)value, diagnostics, context);
			case WebGeneratorMMPackage.CONEXION_RED_SOCIAL:
				return validateConexionRedSocial((ConexionRedSocial)value, diagnostics, context);
			case WebGeneratorMMPackage.PREGUNTA:
				return validatePregunta((Pregunta)value, diagnostics, context);
			case WebGeneratorMMPackage.PREGUNTA_CORTA:
				return validatePreguntaCorta((PreguntaCorta)value, diagnostics, context);
			case WebGeneratorMMPackage.PREGUNTA_ELEGIR:
				return validatePreguntaElegir((PreguntaElegir)value, diagnostics, context);
			case WebGeneratorMMPackage.PREGUNTA_VF:
				return validatePreguntaVF((PreguntaVF)value, diagnostics, context);
			case WebGeneratorMMPackage.ENCUESTA:
				return validateEncuesta((Encuesta)value, diagnostics, context);
			case WebGeneratorMMPackage.CUESTIONARIO:
				return validateCuestionario((Cuestionario)value, diagnostics, context);
			case WebGeneratorMMPackage.ENLACE:
				return validateEnlace((Enlace)value, diagnostics, context);
			case WebGeneratorMMPackage.ENLACE_EXTERNO:
				return validateEnlaceExterno((EnlaceExterno)value, diagnostics, context);
			case WebGeneratorMMPackage.ENLACE_INTERNO:
				return validateEnlaceInterno((EnlaceInterno)value, diagnostics, context);
			case WebGeneratorMMPackage.OPCION:
				return validateOpcion((Opcion)value, diagnostics, context);
			case WebGeneratorMMPackage.DETALLE:
				return validateDetalle((Detalle)value, diagnostics, context);
			case WebGeneratorMMPackage.BORRADO:
				return validateBorrado((Borrado)value, diagnostics, context);
			case WebGeneratorMMPackage.CREACION:
				return validateCreacion((Creacion)value, diagnostics, context);
			case WebGeneratorMMPackage.PAGINA_ENTIDAD:
				return validatePaginaEntidad((PaginaEntidad)value, diagnostics, context);
			case WebGeneratorMMPackage.REPTYPE:
				return validateREPTYPE((REPTYPE)value, diagnostics, context);
			case WebGeneratorMMPackage.ATRTYPE:
				return validateATRTYPE((ATRTYPE)value, diagnostics, context);
			default:
				return true;
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(sitioWeb, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validateSitioWeb_sitio_debe_tener_nombre(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validateSitioWeb_sitio_debe_tener_image(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validateSitioWeb_no_mismo_nombre_entidades(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validateSitioWeb_no_mismo_nombre_paginas(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validateSitioWeb_una_pagina_home(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validateSitioWeb_no_dos_indice_misma_entidad(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validateSitioWeb_no_dos_detalle_misma_entidad(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validateSitioWeb_no_dos_creacion_misma_entidad(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validateSitioWeb_no_dos_borrado_misma_entidad(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validateSitioWeb_no_dos_crud_misma_entidad(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validateSitioWeb_no_crud_y_indice(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validateSitioWeb_no_crud_y_detalle(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validateSitioWeb_no_crud_y_creacion(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validateSitioWeb_no_crud_y_borrado(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validateSitioWeb_al_menos_un_cuestionario(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validateSitioWeb_al_menos_una_encuesta(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validateSitioWeb_indice_implica_detalle(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validateSitioWeb_detalle_implica_indice(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validateSitioWeb_al_menos_una_pagina_con_red_social(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validateSitioWeb_home_enlaza_cruds_y_indices(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validateSitioWeb_creacion_implica_indice(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validateSitioWeb_borrado_implica_detalle(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validateSitioWeb_ref_muchas_implica_no_muchas(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validateSitioWeb_ref_no_muchos_unica_en_cada_entidad(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validateSitioWeb_prohibidas_ref_no_muchos_unica_bidireccional(sitioWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validateSitioWeb_paginas_todas_alcanzables(sitioWeb, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the sitio_debe_tener_nombre constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SITIO_WEB__SITIO_DEBE_TENER_NOMBRE__EEXPRESSION = "not self.name.oclIsUndefined() and self.name<>''";

	/**
	 * Validates the sitio_debe_tener_nombre constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb_sitio_debe_tener_nombre(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.SITIO_WEB,
				 sitioWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "sitio_debe_tener_nombre",
				 SITIO_WEB__SITIO_DEBE_TENER_NOMBRE__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the sitio_debe_tener_image constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SITIO_WEB__SITIO_DEBE_TENER_IMAGE__EEXPRESSION = "not self.image.oclIsUndefined() and self.image<>''";

	/**
	 * Validates the sitio_debe_tener_image constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb_sitio_debe_tener_image(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.SITIO_WEB,
				 sitioWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "sitio_debe_tener_image",
				 SITIO_WEB__SITIO_DEBE_TENER_IMAGE__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the no_mismo_nombre_entidades constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SITIO_WEB__NO_MISMO_NOMBRE_ENTIDADES__EEXPRESSION = "self.entidadesModelo->forAll(e1, e2: Entidad | e1=e2 or e1.name<>e2.name)";

	/**
	 * Validates the no_mismo_nombre_entidades constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb_no_mismo_nombre_entidades(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.SITIO_WEB,
				 sitioWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "no_mismo_nombre_entidades",
				 SITIO_WEB__NO_MISMO_NOMBRE_ENTIDADES__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the no_mismo_nombre_paginas constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SITIO_WEB__NO_MISMO_NOMBRE_PAGINAS__EEXPRESSION = "self.paginasweb ->forAll(p1, p2: PaginaWeb | p1=p2 or p1.name<>p2.name)";

	/**
	 * Validates the no_mismo_nombre_paginas constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb_no_mismo_nombre_paginas(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.SITIO_WEB,
				 sitioWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "no_mismo_nombre_paginas",
				 SITIO_WEB__NO_MISMO_NOMBRE_PAGINAS__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the una_pagina_home constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SITIO_WEB__UNA_PAGINA_HOME__EEXPRESSION = "self.paginasweb->select(oclIsTypeOf(PaginaHome))->size()=1";

	/**
	 * Validates the una_pagina_home constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb_una_pagina_home(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.SITIO_WEB,
				 sitioWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "una_pagina_home",
				 SITIO_WEB__UNA_PAGINA_HOME__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the no_dos_indice_misma_entidad constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SITIO_WEB__NO_DOS_INDICE_MISMA_ENTIDAD__EEXPRESSION = "self.paginasweb->select(oclIsTypeOf(Indice)).oclAsType(Indice)->forAll(p1, p2: Indice| p1=p2 or p1.entidad<>p2.entidad)";

	/**
	 * Validates the no_dos_indice_misma_entidad constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb_no_dos_indice_misma_entidad(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.SITIO_WEB,
				 sitioWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "no_dos_indice_misma_entidad",
				 SITIO_WEB__NO_DOS_INDICE_MISMA_ENTIDAD__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the no_dos_detalle_misma_entidad constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SITIO_WEB__NO_DOS_DETALLE_MISMA_ENTIDAD__EEXPRESSION = "self.paginasweb->select(oclIsTypeOf(Detalle)).oclAsType(Detalle)->forAll(p1, p2: Detalle| p1=p2 or p1.entidad<>p2.entidad)";

	/**
	 * Validates the no_dos_detalle_misma_entidad constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb_no_dos_detalle_misma_entidad(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.SITIO_WEB,
				 sitioWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "no_dos_detalle_misma_entidad",
				 SITIO_WEB__NO_DOS_DETALLE_MISMA_ENTIDAD__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the no_dos_creacion_misma_entidad constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SITIO_WEB__NO_DOS_CREACION_MISMA_ENTIDAD__EEXPRESSION = "self.paginasweb->select(oclIsTypeOf(Creacion)).oclAsType(Creacion)->forAll(p1, p2: Creacion| p1=p2 or p1.entidad<>p2.entidad)";

	/**
	 * Validates the no_dos_creacion_misma_entidad constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb_no_dos_creacion_misma_entidad(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.SITIO_WEB,
				 sitioWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "no_dos_creacion_misma_entidad",
				 SITIO_WEB__NO_DOS_CREACION_MISMA_ENTIDAD__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the no_dos_borrado_misma_entidad constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SITIO_WEB__NO_DOS_BORRADO_MISMA_ENTIDAD__EEXPRESSION = "self.paginasweb->select(oclIsTypeOf(Borrado)).oclAsType(Borrado)->forAll(p1, p2: Borrado| p1=p2 or p1.entidad<>p2.entidad)";

	/**
	 * Validates the no_dos_borrado_misma_entidad constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb_no_dos_borrado_misma_entidad(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.SITIO_WEB,
				 sitioWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "no_dos_borrado_misma_entidad",
				 SITIO_WEB__NO_DOS_BORRADO_MISMA_ENTIDAD__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the no_dos_crud_misma_entidad constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SITIO_WEB__NO_DOS_CRUD_MISMA_ENTIDAD__EEXPRESSION = "self.paginasweb->select(oclIsTypeOf(PaginaCRUD)).oclAsType(PaginaCRUD)->forAll(p1, p2: PaginaCRUD| p1=p2 or p1.entidad<>p2.entidad)";

	/**
	 * Validates the no_dos_crud_misma_entidad constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb_no_dos_crud_misma_entidad(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.SITIO_WEB,
				 sitioWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "no_dos_crud_misma_entidad",
				 SITIO_WEB__NO_DOS_CRUD_MISMA_ENTIDAD__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the no_crud_y_indice constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SITIO_WEB__NO_CRUD_YINDICE__EEXPRESSION = "self.paginasweb->select(oclIsTypeOf(PaginaCRUD)).oclAsType(PaginaCRUD)->forAll(pC: PaginaCRUD |\n" +
		"\t\t\t\t\t\tself.paginasweb->select(oclIsTypeOf(Indice)).oclAsType(Indice)->forAll(pI: Indice| pC.entidad<>pI.entidad))";

	/**
	 * Validates the no_crud_y_indice constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb_no_crud_y_indice(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.SITIO_WEB,
				 sitioWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "no_crud_y_indice",
				 SITIO_WEB__NO_CRUD_YINDICE__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the no_crud_y_detalle constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SITIO_WEB__NO_CRUD_YDETALLE__EEXPRESSION = "self.paginasweb->select(oclIsTypeOf(PaginaCRUD)).oclAsType(PaginaCRUD)->forAll(pC: PaginaCRUD |\n" +
		"\t\t\t\t\t\tself.paginasweb->select(oclIsTypeOf(Detalle)).oclAsType(Detalle)->forAll(pD: Detalle| pC.entidad<>pD.entidad))";

	/**
	 * Validates the no_crud_y_detalle constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb_no_crud_y_detalle(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.SITIO_WEB,
				 sitioWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "no_crud_y_detalle",
				 SITIO_WEB__NO_CRUD_YDETALLE__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the no_crud_y_creacion constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SITIO_WEB__NO_CRUD_YCREACION__EEXPRESSION = "self.paginasweb->select(oclIsTypeOf(PaginaCRUD)).oclAsType(PaginaCRUD)->forAll(pC: PaginaCRUD |\n" +
		"\t\t\t\t\t\tself.paginasweb->select(oclIsTypeOf(Creacion)).oclAsType(Creacion)->forAll(pCreacion: Creacion| pC.entidad<>pCreacion.entidad))";

	/**
	 * Validates the no_crud_y_creacion constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb_no_crud_y_creacion(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.SITIO_WEB,
				 sitioWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "no_crud_y_creacion",
				 SITIO_WEB__NO_CRUD_YCREACION__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the no_crud_y_borrado constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SITIO_WEB__NO_CRUD_YBORRADO__EEXPRESSION = "self.paginasweb->select(oclIsTypeOf(PaginaCRUD)).oclAsType(PaginaCRUD)->forAll(pC: PaginaCRUD |\n" +
		"\t\t\t\t\t\tself.paginasweb->select(oclIsTypeOf(Borrado)).oclAsType(Borrado)->forAll(pB: Borrado| pC.entidad<>pB.entidad))";

	/**
	 * Validates the no_crud_y_borrado constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb_no_crud_y_borrado(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.SITIO_WEB,
				 sitioWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "no_crud_y_borrado",
				 SITIO_WEB__NO_CRUD_YBORRADO__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the al_menos_un_cuestionario constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SITIO_WEB__AL_MENOS_UN_CUESTIONARIO__EEXPRESSION = "self.paginasweb->select(oclIsTypeOf(Cuestionario))->size()>=1";

	/**
	 * Validates the al_menos_un_cuestionario constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb_al_menos_un_cuestionario(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.SITIO_WEB,
				 sitioWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "al_menos_un_cuestionario",
				 SITIO_WEB__AL_MENOS_UN_CUESTIONARIO__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the al_menos_una_encuesta constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SITIO_WEB__AL_MENOS_UNA_ENCUESTA__EEXPRESSION = "self.paginasweb->select(oclIsTypeOf(Encuesta))->size()>=1";

	/**
	 * Validates the al_menos_una_encuesta constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb_al_menos_una_encuesta(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.SITIO_WEB,
				 sitioWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "al_menos_una_encuesta",
				 SITIO_WEB__AL_MENOS_UNA_ENCUESTA__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the indice_implica_detalle constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SITIO_WEB__INDICE_IMPLICA_DETALLE__EEXPRESSION = "self.paginasweb->select(oclIsTypeOf(Indice)).oclAsType(Indice)->forAll(pI: Indice| \n" +
		"\t\t\t\t\t\tself.paginasweb->select(oclIsTypeOf(Detalle)).oclAsType(Detalle)->exists(pD: Detalle| pI.entidad=pD.entidad))";

	/**
	 * Validates the indice_implica_detalle constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb_indice_implica_detalle(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.SITIO_WEB,
				 sitioWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "indice_implica_detalle",
				 SITIO_WEB__INDICE_IMPLICA_DETALLE__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the detalle_implica_indice constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SITIO_WEB__DETALLE_IMPLICA_INDICE__EEXPRESSION = "self.paginasweb->select(oclIsTypeOf(Detalle)).oclAsType(Detalle)->forAll(pD: Detalle| \n" +
		"\t\t\t\t\t\tself.paginasweb->select(oclIsTypeOf(Indice)).oclAsType(Indice)->exists(pI: Indice| pD.entidad=pI.entidad))";

	/**
	 * Validates the detalle_implica_indice constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb_detalle_implica_indice(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.SITIO_WEB,
				 sitioWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "detalle_implica_indice",
				 SITIO_WEB__DETALLE_IMPLICA_INDICE__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the al_menos_una_pagina_con_red_social constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SITIO_WEB__AL_MENOS_UNA_PAGINA_CON_RED_SOCIAL__EEXPRESSION = "self.paginasweb->select(conexionredsocial->size()>=1)->size()>=1";

	/**
	 * Validates the al_menos_una_pagina_con_red_social constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb_al_menos_una_pagina_con_red_social(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.SITIO_WEB,
				 sitioWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "al_menos_una_pagina_con_red_social",
				 SITIO_WEB__AL_MENOS_UNA_PAGINA_CON_RED_SOCIAL__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the home_enlaza_cruds_y_indices constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SITIO_WEB__HOME_ENLAZA_CRUDS_YINDICES__EEXPRESSION = "self.paginasweb->select(oclIsTypeOf(Indice) or oclIsTypeOf(PaginaCRUD))->\n" +
		"\t\t\tforAll(p | self.paginasweb->select(oclIsTypeOf(PaginaHome)).enlaces->select(e|e.oclIsTypeOf(EnlaceInterno))->\n" +
		"\t\t\t\tselect(e| e.oclAsType(EnlaceInterno).referencia=p)->size()>0\n" +
		"\t\t\t)";

	/**
	 * Validates the home_enlaza_cruds_y_indices constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb_home_enlaza_cruds_y_indices(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.SITIO_WEB,
				 sitioWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "home_enlaza_cruds_y_indices",
				 SITIO_WEB__HOME_ENLAZA_CRUDS_YINDICES__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the creacion_implica_indice constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SITIO_WEB__CREACION_IMPLICA_INDICE__EEXPRESSION = "self.paginasweb->select(oclIsTypeOf(Creacion)).oclAsType(Creacion)->forAll(pC: Creacion| \n" +
		"\t\t\t\t\t\tself.paginasweb->select(oclIsTypeOf(Indice)).oclAsType(Indice)->exists(pI: Indice| pC.entidad=pI.entidad))";

	/**
	 * Validates the creacion_implica_indice constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb_creacion_implica_indice(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.SITIO_WEB,
				 sitioWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "creacion_implica_indice",
				 SITIO_WEB__CREACION_IMPLICA_INDICE__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the borrado_implica_detalle constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SITIO_WEB__BORRADO_IMPLICA_DETALLE__EEXPRESSION = "self.paginasweb->select(oclIsTypeOf(Borrado)).oclAsType(Borrado)->forAll(pB: Borrado| \n" +
		"\t\t\t\t\t\tself.paginasweb->select(oclIsTypeOf(Detalle)).oclAsType(Detalle)->exists(pD: Detalle| pB.entidad=pD.entidad))";

	/**
	 * Validates the borrado_implica_detalle constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb_borrado_implica_detalle(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.SITIO_WEB,
				 sitioWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "borrado_implica_detalle",
				 SITIO_WEB__BORRADO_IMPLICA_DETALLE__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the ref_muchas_implica_no_muchas constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SITIO_WEB__REF_MUCHAS_IMPLICA_NO_MUCHAS__EEXPRESSION = "self.entidadesModelo->forAll(e:Entidad | e.referencias->select(muchas=true)->\n" +
		"\t\t\tforAll(r:Referencia| r.destino.referencias->exists(r2:Referencia|r2.destino=e and r2.muchas=false)))";

	/**
	 * Validates the ref_muchas_implica_no_muchas constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb_ref_muchas_implica_no_muchas(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.SITIO_WEB,
				 sitioWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "ref_muchas_implica_no_muchas",
				 SITIO_WEB__REF_MUCHAS_IMPLICA_NO_MUCHAS__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the ref_no_muchos_unica_en_cada_entidad constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SITIO_WEB__REF_NO_MUCHOS_UNICA_EN_CADA_ENTIDAD__EEXPRESSION = "self.entidadesModelo->forAll(e:Entidad | e.referencias->select(muchas=false)->\n" +
		"\t\t\tforAll(r1,r2 | r1=r2 or r1.destino<>r2.destino))";

	/**
	 * Validates the ref_no_muchos_unica_en_cada_entidad constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb_ref_no_muchos_unica_en_cada_entidad(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.SITIO_WEB,
				 sitioWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "ref_no_muchos_unica_en_cada_entidad",
				 SITIO_WEB__REF_NO_MUCHOS_UNICA_EN_CADA_ENTIDAD__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the prohibidas_ref_no_muchos_unica_bidireccional constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SITIO_WEB__PROHIBIDAS_REF_NO_MUCHOS_UNICA_BIDIRECCIONAL__EEXPRESSION = "self.entidadesModelo->forAll(e:Entidad | e.referencias->select(muchas=false)->\n" +
		"\t\t\tforAll(r:Referencia| not r.destino.referencias->exists(r2:Referencia|r2.destino=e and r2.muchas=false)))";

	/**
	 * Validates the prohibidas_ref_no_muchos_unica_bidireccional constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb_prohibidas_ref_no_muchos_unica_bidireccional(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.SITIO_WEB,
				 sitioWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "prohibidas_ref_no_muchos_unica_bidireccional",
				 SITIO_WEB__PROHIBIDAS_REF_NO_MUCHOS_UNICA_BIDIRECCIONAL__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the paginas_todas_alcanzables constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SITIO_WEB__PAGINAS_TODAS_ALCANZABLES__EEXPRESSION = "self.paginasweb->select(oclIsTypeOf(Indice) or oclIsTypeOf(PaginaCRUD) or oclIsKindOf(PaginaEncForm))->\n" +
		"\t\t\tforAll(p|self.paginasweb.enlaces->select(oclIsTypeOf(EnlaceInterno)).oclAsType(EnlaceInterno)->\n" +
		"\t\t\t\tselect(referencia=p)->size()>=1)";

	/**
	 * Validates the paginas_todas_alcanzables constraint of '<em>Sitio Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSitioWeb_paginas_todas_alcanzables(SitioWeb sitioWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.SITIO_WEB,
				 sitioWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "paginas_todas_alcanzables",
				 SITIO_WEB__PAGINAS_TODAS_ALCANZABLES__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePaginaWeb(PaginaWeb paginaWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(paginaWeb, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(paginaWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(paginaWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(paginaWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(paginaWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(paginaWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(paginaWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(paginaWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(paginaWeb, diagnostics, context);
		if (result || diagnostics != null) result &= validatePaginaWeb_nombre_sin_espacios(paginaWeb, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the nombre_sin_espacios constraint of '<em>Pagina Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String PAGINA_WEB__NOMBRE_SIN_ESPACIOS__EEXPRESSION = "self.name=self.name.replaceAll(' ','')";

	/**
	 * Validates the nombre_sin_espacios constraint of '<em>Pagina Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePaginaWeb_nombre_sin_espacios(PaginaWeb paginaWeb, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.PAGINA_WEB,
				 paginaWeb,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "nombre_sin_espacios",
				 PAGINA_WEB__NOMBRE_SIN_ESPACIOS__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEntidad(Entidad entidad, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(entidad, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(entidad, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(entidad, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(entidad, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(entidad, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(entidad, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(entidad, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(entidad, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(entidad, diagnostics, context);
		if (result || diagnostics != null) result &= validateEntidad_name_es_string(entidad, diagnostics, context);
		if (result || diagnostics != null) result &= validateEntidad_un_atributo_name(entidad, diagnostics, context);
		if (result || diagnostics != null) result &= validateEntidad_id_es_integer(entidad, diagnostics, context);
		if (result || diagnostics != null) result &= validateEntidad_un_atributo_id(entidad, diagnostics, context);
		if (result || diagnostics != null) result &= validateEntidad_image_es_string(entidad, diagnostics, context);
		if (result || diagnostics != null) result &= validateEntidad_un_atributo_image(entidad, diagnostics, context);
		if (result || diagnostics != null) result &= validateEntidad_nombres_atributos_distintos(entidad, diagnostics, context);
		if (result || diagnostics != null) result &= validateEntidad_nombre_sin_espacios(entidad, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the name_es_string constraint of '<em>Entidad</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String ENTIDAD__NAME_ES_STRING__EEXPRESSION = "self.atributos->select(name='name')->forAll(type=ATRTYPE::String)";

	/**
	 * Validates the name_es_string constraint of '<em>Entidad</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEntidad_name_es_string(Entidad entidad, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.ENTIDAD,
				 entidad,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "name_es_string",
				 ENTIDAD__NAME_ES_STRING__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the un_atributo_name constraint of '<em>Entidad</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String ENTIDAD__UN_ATRIBUTO_NAME__EEXPRESSION = "self.atributos->select(name='name')->size()=1";

	/**
	 * Validates the un_atributo_name constraint of '<em>Entidad</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEntidad_un_atributo_name(Entidad entidad, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.ENTIDAD,
				 entidad,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "un_atributo_name",
				 ENTIDAD__UN_ATRIBUTO_NAME__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the id_es_integer constraint of '<em>Entidad</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String ENTIDAD__ID_ES_INTEGER__EEXPRESSION = "self.atributos->select(name=('id_'.concat(self.name)))->forAll(type=ATRTYPE::Integer)";

	/**
	 * Validates the id_es_integer constraint of '<em>Entidad</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEntidad_id_es_integer(Entidad entidad, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.ENTIDAD,
				 entidad,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "id_es_integer",
				 ENTIDAD__ID_ES_INTEGER__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the un_atributo_id constraint of '<em>Entidad</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String ENTIDAD__UN_ATRIBUTO_ID__EEXPRESSION = "self.atributos->select(name=('id_'.concat(self.name)))->size()=1";

	/**
	 * Validates the un_atributo_id constraint of '<em>Entidad</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEntidad_un_atributo_id(Entidad entidad, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.ENTIDAD,
				 entidad,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "un_atributo_id",
				 ENTIDAD__UN_ATRIBUTO_ID__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the image_es_string constraint of '<em>Entidad</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String ENTIDAD__IMAGE_ES_STRING__EEXPRESSION = "self.atributos->select(name='image')->forAll(type=ATRTYPE::String)";

	/**
	 * Validates the image_es_string constraint of '<em>Entidad</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEntidad_image_es_string(Entidad entidad, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.ENTIDAD,
				 entidad,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "image_es_string",
				 ENTIDAD__IMAGE_ES_STRING__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the un_atributo_image constraint of '<em>Entidad</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String ENTIDAD__UN_ATRIBUTO_IMAGE__EEXPRESSION = "self.atributos->select(name='image')->size()=1";

	/**
	 * Validates the un_atributo_image constraint of '<em>Entidad</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEntidad_un_atributo_image(Entidad entidad, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.ENTIDAD,
				 entidad,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "un_atributo_image",
				 ENTIDAD__UN_ATRIBUTO_IMAGE__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the nombres_atributos_distintos constraint of '<em>Entidad</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String ENTIDAD__NOMBRES_ATRIBUTOS_DISTINTOS__EEXPRESSION = "self.atributos->forAll(a1, a2: Atributo | a1=a2 or a1.name<>a2.name)";

	/**
	 * Validates the nombres_atributos_distintos constraint of '<em>Entidad</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEntidad_nombres_atributos_distintos(Entidad entidad, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.ENTIDAD,
				 entidad,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "nombres_atributos_distintos",
				 ENTIDAD__NOMBRES_ATRIBUTOS_DISTINTOS__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the nombre_sin_espacios constraint of '<em>Entidad</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String ENTIDAD__NOMBRE_SIN_ESPACIOS__EEXPRESSION = "self.name=self.name.replaceAll(' ','')";

	/**
	 * Validates the nombre_sin_espacios constraint of '<em>Entidad</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEntidad_nombre_sin_espacios(Entidad entidad, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.ENTIDAD,
				 entidad,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "nombre_sin_espacios",
				 ENTIDAD__NOMBRE_SIN_ESPACIOS__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateReferencia(Referencia referencia, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(referencia, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(referencia, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(referencia, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(referencia, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(referencia, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(referencia, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(referencia, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(referencia, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(referencia, diagnostics, context);
		if (result || diagnostics != null) result &= validateReferencia_nombre_sin_espacios(referencia, diagnostics, context);
		if (result || diagnostics != null) result &= validateReferencia_nombre_empieza_minusculas(referencia, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the nombre_sin_espacios constraint of '<em>Referencia</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String REFERENCIA__NOMBRE_SIN_ESPACIOS__EEXPRESSION = "self.name=self.name.replaceAll(' ','')";

	/**
	 * Validates the nombre_sin_espacios constraint of '<em>Referencia</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateReferencia_nombre_sin_espacios(Referencia referencia, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.REFERENCIA,
				 referencia,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "nombre_sin_espacios",
				 REFERENCIA__NOMBRE_SIN_ESPACIOS__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the nombre_empieza_minusculas constraint of '<em>Referencia</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String REFERENCIA__NOMBRE_EMPIEZA_MINUSCULAS__EEXPRESSION = "self.name.substring(1,1).toLower()=self.name.substring(1,1)";

	/**
	 * Validates the nombre_empieza_minusculas constraint of '<em>Referencia</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateReferencia_nombre_empieza_minusculas(Referencia referencia, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.REFERENCIA,
				 referencia,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "nombre_empieza_minusculas",
				 REFERENCIA__NOMBRE_EMPIEZA_MINUSCULAS__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateAtributo(Atributo atributo, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(atributo, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(atributo, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(atributo, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(atributo, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(atributo, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(atributo, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(atributo, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(atributo, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(atributo, diagnostics, context);
		if (result || diagnostics != null) result &= validateAtributo_nombre_sin_espacios(atributo, diagnostics, context);
		if (result || diagnostics != null) result &= validateAtributo_nombre_empieza_minusculas(atributo, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the nombre_sin_espacios constraint of '<em>Atributo</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String ATRIBUTO__NOMBRE_SIN_ESPACIOS__EEXPRESSION = "self.name=self.name.replaceAll(' ','')";

	/**
	 * Validates the nombre_sin_espacios constraint of '<em>Atributo</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateAtributo_nombre_sin_espacios(Atributo atributo, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.ATRIBUTO,
				 atributo,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "nombre_sin_espacios",
				 ATRIBUTO__NOMBRE_SIN_ESPACIOS__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the nombre_empieza_minusculas constraint of '<em>Atributo</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String ATRIBUTO__NOMBRE_EMPIEZA_MINUSCULAS__EEXPRESSION = "self.name.substring(1,1).toLower()=self.name.substring(1,1)";

	/**
	 * Validates the nombre_empieza_minusculas constraint of '<em>Atributo</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateAtributo_nombre_empieza_minusculas(Atributo atributo, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.ATRIBUTO,
				 atributo,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "nombre_empieza_minusculas",
				 ATRIBUTO__NOMBRE_EMPIEZA_MINUSCULAS__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateIndice(Indice indice, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(indice, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(indice, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(indice, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(indice, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(indice, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(indice, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(indice, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(indice, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(indice, diagnostics, context);
		if (result || diagnostics != null) result &= validatePaginaWeb_nombre_sin_espacios(indice, diagnostics, context);
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePaginaCRUD(PaginaCRUD paginaCRUD, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(paginaCRUD, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(paginaCRUD, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(paginaCRUD, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(paginaCRUD, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(paginaCRUD, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(paginaCRUD, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(paginaCRUD, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(paginaCRUD, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(paginaCRUD, diagnostics, context);
		if (result || diagnostics != null) result &= validatePaginaWeb_nombre_sin_espacios(paginaCRUD, diagnostics, context);
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePaginaEncForm(PaginaEncForm paginaEncForm, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(paginaEncForm, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(paginaEncForm, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(paginaEncForm, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(paginaEncForm, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(paginaEncForm, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(paginaEncForm, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(paginaEncForm, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(paginaEncForm, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(paginaEncForm, diagnostics, context);
		if (result || diagnostics != null) result &= validatePaginaWeb_nombre_sin_espacios(paginaEncForm, diagnostics, context);
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePaginaHome(PaginaHome paginaHome, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(paginaHome, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(paginaHome, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(paginaHome, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(paginaHome, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(paginaHome, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(paginaHome, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(paginaHome, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(paginaHome, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(paginaHome, diagnostics, context);
		if (result || diagnostics != null) result &= validatePaginaWeb_nombre_sin_espacios(paginaHome, diagnostics, context);
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateConexionRedSocial(ConexionRedSocial conexionRedSocial, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(conexionRedSocial, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePregunta(Pregunta pregunta, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(pregunta, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePreguntaCorta(PreguntaCorta preguntaCorta, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(preguntaCorta, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePreguntaElegir(PreguntaElegir preguntaElegir, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(preguntaElegir, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(preguntaElegir, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(preguntaElegir, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(preguntaElegir, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(preguntaElegir, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(preguntaElegir, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(preguntaElegir, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(preguntaElegir, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(preguntaElegir, diagnostics, context);
		if (result || diagnostics != null) result &= validatePreguntaElegir_al_menos_dos_opciones(preguntaElegir, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the al_menos_dos_opciones constraint of '<em>Pregunta Elegir</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String PREGUNTA_ELEGIR__AL_MENOS_DOS_OPCIONES__EEXPRESSION = "self.opciones->size()>1";

	/**
	 * Validates the al_menos_dos_opciones constraint of '<em>Pregunta Elegir</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePreguntaElegir_al_menos_dos_opciones(PreguntaElegir preguntaElegir, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.PREGUNTA_ELEGIR,
				 preguntaElegir,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "al_menos_dos_opciones",
				 PREGUNTA_ELEGIR__AL_MENOS_DOS_OPCIONES__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePreguntaVF(PreguntaVF preguntaVF, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(preguntaVF, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEncuesta(Encuesta encuesta, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(encuesta, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(encuesta, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(encuesta, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(encuesta, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(encuesta, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(encuesta, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(encuesta, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(encuesta, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(encuesta, diagnostics, context);
		if (result || diagnostics != null) result &= validatePaginaWeb_nombre_sin_espacios(encuesta, diagnostics, context);
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCuestionario(Cuestionario cuestionario, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(cuestionario, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(cuestionario, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(cuestionario, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(cuestionario, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(cuestionario, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(cuestionario, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(cuestionario, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(cuestionario, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(cuestionario, diagnostics, context);
		if (result || diagnostics != null) result &= validatePaginaWeb_nombre_sin_espacios(cuestionario, diagnostics, context);
		if (result || diagnostics != null) result &= validateCuestionario_respuestas_corta_definidas(cuestionario, diagnostics, context);
		if (result || diagnostics != null) result &= validateCuestionario_respuestas_elegir_definidas(cuestionario, diagnostics, context);
		if (result || diagnostics != null) result &= validateCuestionario_respuestas_vf_definidas(cuestionario, diagnostics, context);
		if (result || diagnostics != null) result &= validateCuestionario_preguntas_elegir_solo_una_opcion_correcta(cuestionario, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the respuestas_corta_definidas constraint of '<em>Cuestionario</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String CUESTIONARIO__RESPUESTAS_CORTA_DEFINIDAS__EEXPRESSION = "self.preguntas->select(oclIsTypeOf(PreguntaCorta)).oclAsType(PreguntaCorta)->\n" +
		"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tforAll(not solucion.oclIsUndefined() and solucion<>'')";

	/**
	 * Validates the respuestas_corta_definidas constraint of '<em>Cuestionario</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCuestionario_respuestas_corta_definidas(Cuestionario cuestionario, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.CUESTIONARIO,
				 cuestionario,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "respuestas_corta_definidas",
				 CUESTIONARIO__RESPUESTAS_CORTA_DEFINIDAS__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the respuestas_elegir_definidas constraint of '<em>Cuestionario</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String CUESTIONARIO__RESPUESTAS_ELEGIR_DEFINIDAS__EEXPRESSION = "self.preguntas->select(oclIsTypeOf(PreguntaElegir)).oclAsType(PreguntaElegir)->\n" +
		"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tforAll(p: PreguntaElegir| p.opciones ->forAll(correcta=false or correcta=true))";

	/**
	 * Validates the respuestas_elegir_definidas constraint of '<em>Cuestionario</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCuestionario_respuestas_elegir_definidas(Cuestionario cuestionario, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.CUESTIONARIO,
				 cuestionario,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "respuestas_elegir_definidas",
				 CUESTIONARIO__RESPUESTAS_ELEGIR_DEFINIDAS__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the respuestas_vf_definidas constraint of '<em>Cuestionario</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String CUESTIONARIO__RESPUESTAS_VF_DEFINIDAS__EEXPRESSION = "self.preguntas->select(oclIsTypeOf(PreguntaVF)).oclAsType(PreguntaVF)->\n" +
		"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tforAll(solucion=false or solucion=true)";

	/**
	 * Validates the respuestas_vf_definidas constraint of '<em>Cuestionario</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCuestionario_respuestas_vf_definidas(Cuestionario cuestionario, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.CUESTIONARIO,
				 cuestionario,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "respuestas_vf_definidas",
				 CUESTIONARIO__RESPUESTAS_VF_DEFINIDAS__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the preguntas_elegir_solo_una_opcion_correcta constraint of '<em>Cuestionario</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String CUESTIONARIO__PREGUNTAS_ELEGIR_SOLO_UNA_OPCION_CORRECTA__EEXPRESSION = "self.preguntas->select(oclIsTypeOf(PreguntaElegir)).\n" +
		"\t\t\t\t\toclAsType(PreguntaElegir)->forAll(opciones->select(correcta=true)->size()=1)";

	/**
	 * Validates the preguntas_elegir_solo_una_opcion_correcta constraint of '<em>Cuestionario</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCuestionario_preguntas_elegir_solo_una_opcion_correcta(Cuestionario cuestionario, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.CUESTIONARIO,
				 cuestionario,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "preguntas_elegir_solo_una_opcion_correcta",
				 CUESTIONARIO__PREGUNTAS_ELEGIR_SOLO_UNA_OPCION_CORRECTA__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEnlace(Enlace enlace, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(enlace, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEnlaceExterno(EnlaceExterno enlaceExterno, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(enlaceExterno, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(enlaceExterno, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(enlaceExterno, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(enlaceExterno, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(enlaceExterno, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(enlaceExterno, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(enlaceExterno, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(enlaceExterno, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(enlaceExterno, diagnostics, context);
		if (result || diagnostics != null) result &= validateEnlaceExterno_deben_comenzar_por_http(enlaceExterno, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the deben_comenzar_por_http constraint of '<em>Enlace Externo</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String ENLACE_EXTERNO__DEBEN_COMENZAR_POR_HTTP__EEXPRESSION = "self.url.startsWith('http')";

	/**
	 * Validates the deben_comenzar_por_http constraint of '<em>Enlace Externo</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEnlaceExterno_deben_comenzar_por_http(EnlaceExterno enlaceExterno, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.ENLACE_EXTERNO,
				 enlaceExterno,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "deben_comenzar_por_http",
				 ENLACE_EXTERNO__DEBEN_COMENZAR_POR_HTTP__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEnlaceInterno(EnlaceInterno enlaceInterno, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(enlaceInterno, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(enlaceInterno, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(enlaceInterno, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(enlaceInterno, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(enlaceInterno, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(enlaceInterno, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(enlaceInterno, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(enlaceInterno, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(enlaceInterno, diagnostics, context);
		if (result || diagnostics != null) result &= validateEnlaceInterno_no_permitidos_a_detalle(enlaceInterno, diagnostics, context);
		if (result || diagnostics != null) result &= validateEnlaceInterno_no_permitidos_a_borrado(enlaceInterno, diagnostics, context);
		if (result || diagnostics != null) result &= validateEnlaceInterno_no_permitidos_a_home(enlaceInterno, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the no_permitidos_a_detalle constraint of '<em>Enlace Interno</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String ENLACE_INTERNO__NO_PERMITIDOS_ADETALLE__EEXPRESSION = "not self.referencia.oclIsTypeOf(Detalle)";

	/**
	 * Validates the no_permitidos_a_detalle constraint of '<em>Enlace Interno</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEnlaceInterno_no_permitidos_a_detalle(EnlaceInterno enlaceInterno, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.ENLACE_INTERNO,
				 enlaceInterno,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "no_permitidos_a_detalle",
				 ENLACE_INTERNO__NO_PERMITIDOS_ADETALLE__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the no_permitidos_a_borrado constraint of '<em>Enlace Interno</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String ENLACE_INTERNO__NO_PERMITIDOS_ABORRADO__EEXPRESSION = "not self.referencia.oclIsTypeOf(Borrado)";

	/**
	 * Validates the no_permitidos_a_borrado constraint of '<em>Enlace Interno</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEnlaceInterno_no_permitidos_a_borrado(EnlaceInterno enlaceInterno, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.ENLACE_INTERNO,
				 enlaceInterno,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "no_permitidos_a_borrado",
				 ENLACE_INTERNO__NO_PERMITIDOS_ABORRADO__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the no_permitidos_a_home constraint of '<em>Enlace Interno</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String ENLACE_INTERNO__NO_PERMITIDOS_AHOME__EEXPRESSION = "not self.referencia.oclIsTypeOf(PaginaHome)";

	/**
	 * Validates the no_permitidos_a_home constraint of '<em>Enlace Interno</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEnlaceInterno_no_permitidos_a_home(EnlaceInterno enlaceInterno, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.ENLACE_INTERNO,
				 enlaceInterno,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "no_permitidos_a_home",
				 ENLACE_INTERNO__NO_PERMITIDOS_AHOME__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateOpcion(Opcion opcion, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(opcion, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDetalle(Detalle detalle, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(detalle, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(detalle, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(detalle, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(detalle, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(detalle, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(detalle, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(detalle, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(detalle, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(detalle, diagnostics, context);
		if (result || diagnostics != null) result &= validatePaginaWeb_nombre_sin_espacios(detalle, diagnostics, context);
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateBorrado(Borrado borrado, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(borrado, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(borrado, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(borrado, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(borrado, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(borrado, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(borrado, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(borrado, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(borrado, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(borrado, diagnostics, context);
		if (result || diagnostics != null) result &= validatePaginaWeb_nombre_sin_espacios(borrado, diagnostics, context);
		if (result || diagnostics != null) result &= validateBorrado_no_permitidos_enlaces(borrado, diagnostics, context);
		if (result || diagnostics != null) result &= validateBorrado_no_permitidas_conexiones_redSocial(borrado, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the no_permitidos_enlaces constraint of '<em>Borrado</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String BORRADO__NO_PERMITIDOS_ENLACES__EEXPRESSION = "self.enlaces->size()=0";

	/**
	 * Validates the no_permitidos_enlaces constraint of '<em>Borrado</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateBorrado_no_permitidos_enlaces(Borrado borrado, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.BORRADO,
				 borrado,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "no_permitidos_enlaces",
				 BORRADO__NO_PERMITIDOS_ENLACES__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the no_permitidas_conexiones_redSocial constraint of '<em>Borrado</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String BORRADO__NO_PERMITIDAS_CONEXIONES_RED_SOCIAL__EEXPRESSION = "self.conexionredsocial->size()=0";

	/**
	 * Validates the no_permitidas_conexiones_redSocial constraint of '<em>Borrado</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateBorrado_no_permitidas_conexiones_redSocial(Borrado borrado, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.BORRADO,
				 borrado,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "no_permitidas_conexiones_redSocial",
				 BORRADO__NO_PERMITIDAS_CONEXIONES_RED_SOCIAL__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCreacion(Creacion creacion, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(creacion, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(creacion, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(creacion, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(creacion, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(creacion, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(creacion, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(creacion, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(creacion, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(creacion, diagnostics, context);
		if (result || diagnostics != null) result &= validatePaginaWeb_nombre_sin_espacios(creacion, diagnostics, context);
		if (result || diagnostics != null) result &= validateCreacion_no_permitidos_enlaces(creacion, diagnostics, context);
		if (result || diagnostics != null) result &= validateCreacion_no_permitidas_conexiones_redSocial(creacion, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the no_permitidos_enlaces constraint of '<em>Creacion</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String CREACION__NO_PERMITIDOS_ENLACES__EEXPRESSION = "self.enlaces->size()=0";

	/**
	 * Validates the no_permitidos_enlaces constraint of '<em>Creacion</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCreacion_no_permitidos_enlaces(Creacion creacion, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.CREACION,
				 creacion,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "no_permitidos_enlaces",
				 CREACION__NO_PERMITIDOS_ENLACES__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the no_permitidas_conexiones_redSocial constraint of '<em>Creacion</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String CREACION__NO_PERMITIDAS_CONEXIONES_RED_SOCIAL__EEXPRESSION = "self.conexionredsocial->size()=0";

	/**
	 * Validates the no_permitidas_conexiones_redSocial constraint of '<em>Creacion</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCreacion_no_permitidas_conexiones_redSocial(Creacion creacion, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(WebGeneratorMMPackage.Literals.CREACION,
				 creacion,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "no_permitidas_conexiones_redSocial",
				 CREACION__NO_PERMITIDAS_CONEXIONES_RED_SOCIAL__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePaginaEntidad(PaginaEntidad paginaEntidad, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(paginaEntidad, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(paginaEntidad, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(paginaEntidad, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(paginaEntidad, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(paginaEntidad, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(paginaEntidad, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(paginaEntidad, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(paginaEntidad, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(paginaEntidad, diagnostics, context);
		if (result || diagnostics != null) result &= validatePaginaWeb_nombre_sin_espacios(paginaEntidad, diagnostics, context);
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateREPTYPE(REPTYPE reptype, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateATRTYPE(ATRTYPE atrtype, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * Returns the resource locator that will be used to fetch messages for this validator's diagnostics.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		// TODO
		// Specialize this to return a resource locator for messages specific to this validator.
		// Ensure that you remove @generated or mark it @generated NOT
		return super.getResourceLocator();
	}

} //WebGeneratorMMValidator
