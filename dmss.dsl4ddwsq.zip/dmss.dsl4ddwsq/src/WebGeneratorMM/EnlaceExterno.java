/**
 */
package WebGeneratorMM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Enlace Externo</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link WebGeneratorMM.EnlaceExterno#getUrl <em>Url</em>}</li>
 * </ul>
 *
 * @see WebGeneratorMM.WebGeneratorMMPackage#getEnlaceExterno()
 * @model annotation="MyDSLDoc Description='Establece una conexi\363n con un elemento externo al sitio web. En la URL se especifica la direcci\363n del elemento.'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore constraints='deben_comenzar_por_http'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot deben_comenzar_por_http='self.url.startsWith(\'http\')'"
 *        annotation="gmf.node label='name' color='229,251,252' border.width='1' border.style='dot'"
 * @generated
 */
public interface EnlaceExterno extends Enlace {
	/**
	 * Returns the value of the '<em><b>Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Url</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Url</em>' attribute.
	 * @see #setUrl(String)
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getEnlaceExterno_Url()
	 * @model
	 * @generated
	 */
	String getUrl();

	/**
	 * Sets the value of the '{@link WebGeneratorMM.EnlaceExterno#getUrl <em>Url</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Url</em>' attribute.
	 * @see #getUrl()
	 * @generated
	 */
	void setUrl(String value);

} // EnlaceExterno
