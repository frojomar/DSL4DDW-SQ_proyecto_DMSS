/**
 */
package WebGeneratorMM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Encuesta</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link WebGeneratorMM.Encuesta#getRepresentacion <em>Representacion</em>}</li>
 * </ul>
 *
 * @see WebGeneratorMM.WebGeneratorMMPackage#getEncuesta()
 * @model annotation="MyDSLDoc Description='Representa un gr\341fico donde se recoge la informaci\363n de los cuestionarios (puntuaciones, edades, etc.)'"
 *        annotation="gmf.node label='name' color='137,223,249'"
 * @generated
 */
public interface Encuesta extends PaginaEncForm {
	/**
	 * Returns the value of the '<em><b>Representacion</b></em>' attribute.
	 * The literals are from the enumeration {@link WebGeneratorMM.REPTYPE}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Representacion</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Representacion</em>' attribute.
	 * @see WebGeneratorMM.REPTYPE
	 * @see #setRepresentacion(REPTYPE)
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getEncuesta_Representacion()
	 * @model
	 * @generated
	 */
	REPTYPE getRepresentacion();

	/**
	 * Sets the value of the '{@link WebGeneratorMM.Encuesta#getRepresentacion <em>Representacion</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Representacion</em>' attribute.
	 * @see WebGeneratorMM.REPTYPE
	 * @see #getRepresentacion()
	 * @generated
	 */
	void setRepresentacion(REPTYPE value);

} // Encuesta
