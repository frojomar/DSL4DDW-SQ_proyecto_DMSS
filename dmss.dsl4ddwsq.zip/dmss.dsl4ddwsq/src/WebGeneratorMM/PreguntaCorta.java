/**
 */
package WebGeneratorMM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pregunta Corta</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link WebGeneratorMM.PreguntaCorta#getSolucion <em>Solucion</em>}</li>
 * </ul>
 *
 * @see WebGeneratorMM.WebGeneratorMMPackage#getPreguntaCorta()
 * @model annotation="MyDSLDoc Description='Se ofrece un texto con una pregunta al usuario y se da la opci\363n de predefinir una soluci\363n a dicha pregunta.'"
 *        annotation="gmf.node label='content' color='197,225,234'"
 * @generated
 */
public interface PreguntaCorta extends Pregunta {
	/**
	 * Returns the value of the '<em><b>Solucion</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Solucion</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Solucion</em>' attribute.
	 * @see #setSolucion(String)
	 * @see WebGeneratorMM.WebGeneratorMMPackage#getPreguntaCorta_Solucion()
	 * @model
	 * @generated
	 */
	String getSolucion();

	/**
	 * Sets the value of the '{@link WebGeneratorMM.PreguntaCorta#getSolucion <em>Solucion</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Solucion</em>' attribute.
	 * @see #getSolucion()
	 * @generated
	 */
	void setSolucion(String value);

} // PreguntaCorta
