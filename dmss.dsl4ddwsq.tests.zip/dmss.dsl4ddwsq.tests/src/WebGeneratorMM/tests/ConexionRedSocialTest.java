/**
 */
package WebGeneratorMM.tests;

import WebGeneratorMM.ConexionRedSocial;
import WebGeneratorMM.WebGeneratorMMFactory;

import junit.framework.TestCase;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Conexion Red Social</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class ConexionRedSocialTest extends TestCase {

	/**
	 * The fixture for this Conexion Red Social test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ConexionRedSocial fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(ConexionRedSocialTest.class);
	}

	/**
	 * Constructs a new Conexion Red Social test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConexionRedSocialTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Conexion Red Social test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(ConexionRedSocial fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Conexion Red Social test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ConexionRedSocial getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(WebGeneratorMMFactory.eINSTANCE.createConexionRedSocial());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //ConexionRedSocialTest
