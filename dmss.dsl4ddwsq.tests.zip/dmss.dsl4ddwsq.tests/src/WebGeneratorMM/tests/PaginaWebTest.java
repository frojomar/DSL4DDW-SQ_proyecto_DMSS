/**
 */
package WebGeneratorMM.tests;

import WebGeneratorMM.PaginaWeb;

import junit.framework.TestCase;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Pagina Web</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class PaginaWebTest extends TestCase {

	/**
	 * The fixture for this Pagina Web test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PaginaWeb fixture = null;

	/**
	 * Constructs a new Pagina Web test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PaginaWebTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Pagina Web test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(PaginaWeb fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Pagina Web test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PaginaWeb getFixture() {
		return fixture;
	}

} //PaginaWebTest
