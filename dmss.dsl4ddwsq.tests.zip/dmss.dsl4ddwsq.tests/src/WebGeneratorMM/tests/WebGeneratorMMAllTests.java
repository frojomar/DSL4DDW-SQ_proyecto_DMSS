/**
 */
package WebGeneratorMM.tests;

import junit.framework.Test;
import junit.framework.TestSuite;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test suite for the '<em><b>WebGeneratorMM</b></em>' model.
 * <!-- end-user-doc -->
 * @generated
 */
public class WebGeneratorMMAllTests extends TestSuite {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(suite());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Test suite() {
		TestSuite suite = new WebGeneratorMMAllTests("WebGeneratorMM Tests");
		return suite;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WebGeneratorMMAllTests(String name) {
		super(name);
	}

} //WebGeneratorMMAllTests
