/**
 */
package WebGeneratorMM.tests;

import WebGeneratorMM.PaginaEntidad;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Pagina Entidad</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class PaginaEntidadTest extends PaginaWebTest {

	/**
	 * Constructs a new Pagina Entidad test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PaginaEntidadTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Pagina Entidad test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected PaginaEntidad getFixture() {
		return (PaginaEntidad)fixture;
	}

} //PaginaEntidadTest
