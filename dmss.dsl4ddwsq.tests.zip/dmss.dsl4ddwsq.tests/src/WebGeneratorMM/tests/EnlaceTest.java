/**
 */
package WebGeneratorMM.tests;

import WebGeneratorMM.Enlace;

import junit.framework.TestCase;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Enlace</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class EnlaceTest extends TestCase {

	/**
	 * The fixture for this Enlace test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Enlace fixture = null;

	/**
	 * Constructs a new Enlace test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EnlaceTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Enlace test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(Enlace fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Enlace test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Enlace getFixture() {
		return fixture;
	}

} //EnlaceTest
