/**
 */
package WebGeneratorMM.tests;

import WebGeneratorMM.Detalle;
import WebGeneratorMM.WebGeneratorMMFactory;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Detalle</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class DetalleTest extends PaginaEntidadTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(DetalleTest.class);
	}

	/**
	 * Constructs a new Detalle test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DetalleTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Detalle test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected Detalle getFixture() {
		return (Detalle)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(WebGeneratorMMFactory.eINSTANCE.createDetalle());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //DetalleTest
