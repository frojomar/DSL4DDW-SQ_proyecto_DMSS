/**
 */
package WebGeneratorMM.tests;

import WebGeneratorMM.PaginaEncForm;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Pagina Enc Form</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class PaginaEncFormTest extends PaginaWebTest {

	/**
	 * Constructs a new Pagina Enc Form test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PaginaEncFormTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Pagina Enc Form test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected PaginaEncForm getFixture() {
		return (PaginaEncForm)fixture;
	}

} //PaginaEncFormTest
