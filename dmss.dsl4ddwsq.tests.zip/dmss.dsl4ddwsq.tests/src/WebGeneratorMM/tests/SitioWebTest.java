/**
 */
package WebGeneratorMM.tests;

import WebGeneratorMM.SitioWeb;
import WebGeneratorMM.WebGeneratorMMFactory;

import junit.framework.TestCase;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Sitio Web</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class SitioWebTest extends TestCase {

	/**
	 * The fixture for this Sitio Web test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SitioWeb fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(SitioWebTest.class);
	}

	/**
	 * Constructs a new Sitio Web test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SitioWebTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Sitio Web test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(SitioWeb fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Sitio Web test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SitioWeb getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(WebGeneratorMMFactory.eINSTANCE.createSitioWeb());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //SitioWebTest
