/**
 */
package WebGeneratorMM.tests;

import WebGeneratorMM.PreguntaCorta;
import WebGeneratorMM.WebGeneratorMMFactory;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Pregunta Corta</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class PreguntaCortaTest extends PreguntaTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(PreguntaCortaTest.class);
	}

	/**
	 * Constructs a new Pregunta Corta test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PreguntaCortaTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Pregunta Corta test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected PreguntaCorta getFixture() {
		return (PreguntaCorta)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(WebGeneratorMMFactory.eINSTANCE.createPreguntaCorta());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //PreguntaCortaTest
